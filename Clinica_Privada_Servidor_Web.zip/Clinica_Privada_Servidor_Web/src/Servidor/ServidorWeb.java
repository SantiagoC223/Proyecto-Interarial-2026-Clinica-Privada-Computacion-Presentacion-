package Servidor;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.security.SecureRandom;
import java.util.concurrent.ConcurrentHashMap;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.SQLIntegrityConstraintViolationException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class ServidorWeb {

    private static final String URL = "jdbc:mysql://localhost:3306/clinica_privada?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root"; 
    private static final String PASSWORD = ""; 

    public static void main(String[] bounds) throws Exception {
        prepararBaseDeDatos();
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        
        server.createContext("/guardarTurno", new GuardarTurnoHandler());
        server.createContext("/", new RecursosWebHandler());
        server.createContext("/api/turnos", new TurnosHandler());
        server.createContext("/api/medicamentos", new MedicamentosHandler());
        server.createContext("/api/historial_medico", new HistorialHandler());
        server.createContext("/registro", new RegistroHandler());
        server.createContext("/api/registro", new RegistroHandler());
        server.createContext("/api/login", new LoginHandler());
        server.createContext("/api/auth/logout", new LogoutHandler());
        server.createContext("/api/pacientes/perfil", new PerfilHandler());
        server.createContext("/api/pacientes/turnos", new TurnosPacienteHandler());
        server.setExecutor(null);
        System.out.println("Servidor iniciado en http://localhost:8080");
        server.start();
    }
    
static class TurnosHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {

        // Solo permitimos solicitudes GET
        if (!exchange.getRequestMethod().equalsIgnoreCase("GET")) {
            exchange.sendResponseHeaders(405, -1);
            return;
        }

        String sql = "SELECT * FROM turnos";

        StringBuilder json = new StringBuilder();
        json.append("[");

        try {
            Class.forName("com.mysql.jdbc.Driver");

            try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                 java.sql.PreparedStatement pstmt = conn.prepareStatement(sql);
                 java.sql.ResultSet resultado = pstmt.executeQuery()) {

                boolean primero = true;

                while (resultado.next()) {

                    if (!primero) {
                        json.append(",");
                    }

                    json.append("{");

                    json.append("\"id_turno\":")
                        .append(resultado.getInt("id_turno")).append(",");

                    json.append("\"codigo_paciente\":")
                        .append(resultado.getInt("codigo_paciente")).append(",");

                    json.append("\"fecha_hora\":\"")
                        .append(resultado.getString("fecha_hora")).append("\",");

                    json.append("\"Especialidad\":\"")
                        .append(resultado.getString("Especialidad")).append("\",");

                    json.append("\"motivoConsulta\":\"")
                        .append(resultado.getString("motivoConsulta")).append("\",");

                    json.append("\"estado\":\"")
                        .append(resultado.getString("estado")).append("\"");

                    json.append("}");

                    primero = false;
                }
            }

            json.append("]");

            String respuesta = json.toString();

            exchange.getResponseHeaders().set(
                "Content-Type", "application/json; charset=UTF-8"
            );

            byte[] bytes = respuesta.getBytes("UTF-8");

            exchange.sendResponseHeaders(200, bytes.length);

            try (OutputStream salida = exchange.getResponseBody()) {
                salida.write(bytes);
            }

        } catch (Exception e) {

            e.printStackTrace();

            String error = "{\"error\":\"No se pudieron obtener los turnos\"}";
            byte[] bytes = error.getBytes("UTF-8");

            exchange.getResponseHeaders().set(
                "Content-Type", "application/json; charset=UTF-8"
            );

            exchange.sendResponseHeaders(500, bytes.length);

            try (OutputStream salida = exchange.getResponseBody()) {
                salida.write(bytes);
            }
        }
    }
}
private static String jsonTexto(String texto) {

        if (texto == null) {
            return "null";
        }

        return "\"" + texto
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t") + "\"";
    }


static class MedicamentosHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {

        // Solo permitimos solicitudes GET
        if (!exchange.getRequestMethod().equalsIgnoreCase("GET")) {
            exchange.sendResponseHeaders(405, -1);
            return;
        }

        String sql = "SELECT * FROM medicamentos";

        StringBuilder json = new StringBuilder();
        json.append("[");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                 java.sql.PreparedStatement pstmt = conn.prepareStatement(sql);
                 java.sql.ResultSet resultado = pstmt.executeQuery()) {

                boolean primero = true;

                while (resultado.next()) {

                    if (!primero) {
                        json.append(",");
                    }

                    
                    json.append("{");

                    json.append("\"id_medicamento\":")
                        .append(resultado.getInt("id_medicamento")).append(",");

                    json.append("\"nombre\":")
                        .append(jsonTexto(resultado.getString("nombre"))).append(",");

                    json.append("\"grupo_anatomico\":")
                        .append(jsonTexto(resultado.getString("grupo_anatomico"))).append(",");

                    json.append("\"tipo\":")
                        .append(jsonTexto(resultado.getString("tipo"))).append(",");

                    json.append("\"condicion_venta\":")
                        .append(jsonTexto(resultado.getString("condicion_venta"))).append(",");

                    json.append("\"forma_farmaceutica\":")
                        .append(jsonTexto(resultado.getString("forma_farmaceutica"))).append(",");

                    json.append("\"Categoria_Subtipo\":")
                        .append(jsonTexto(resultado.getString("Categoria_Subtipo"))).append(",");

                    json.append("\"Via_Administracion\":")
                        .append(jsonTexto(resultado.getString("Via_Administracion"))).append(",");

                    json.append("\"Dosis_Unidad\":")
                        .append(jsonTexto(resultado.getString("Dosis_Unidad"))).append(",");

                    json.append("\"dosis_cantidad\":")
                        .append(resultado.getObject("dosis_cantidad") == null
                            ? "null" : resultado.getInt("dosis_cantidad"));

                    json.append("}");


                    primero = false;
                }
            }

            json.append("]");

            String respuesta = json.toString();

            exchange.getResponseHeaders().set(
                "Content-Type", "application/json; charset=UTF-8"
            );

            byte[] bytes = respuesta.getBytes("UTF-8");

            exchange.sendResponseHeaders(200, bytes.length);

            try (OutputStream salida = exchange.getResponseBody()) {
                salida.write(bytes);
            }

        } catch (Exception e) {

            e.printStackTrace();

            String error = "{\"error\":\"No se pudieron obtener los medicamentos\"}";
            byte[] bytes = error.getBytes("UTF-8");

            exchange.getResponseHeaders().set(
                "Content-Type", "application/json; charset=UTF-8"
            );

            exchange.sendResponseHeaders(500, bytes.length);

            try (OutputStream salida = exchange.getResponseBody()) {
                salida.write(bytes);
            }
        }
    }
}
static class HistorialHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {

        // Solo permitimos solicitudes GET
        if (!exchange.getRequestMethod().equalsIgnoreCase("GET")) {
            exchange.sendResponseHeaders(405, -1);
            return;
        }

        String sql = "SELECT * FROM historial_medico;";

        StringBuilder json = new StringBuilder();
        json.append("[");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                 java.sql.PreparedStatement pstmt = conn.prepareStatement(sql);
                 java.sql.ResultSet resultado = pstmt.executeQuery()) {

                boolean primero = true;

                while (resultado.next()) {

                    if (!primero) {
                        json.append(",");
                    }

                    json.append("{");

                    json.append("\"id_historial\":")
                        .append(resultado.getInt("id_historial")).append(",");

                    json.append("\"DNI_Paciente\":")
                        .append(resultado.getInt("DNI_Paciente")).append(",");

                    json.append("\"id_medico\":\"")
                        .append(resultado.getString("id_medico")).append("\",");

                    json.append("\"nombreDeLaEnfermedad\":\"")
                        .append(resultado.getString("nombreDeLaEnfermedad")).append("\",");

                    json.append("\"nombreMedicamento\":\"")
                        .append(resultado.getString("nombreMedicamento")).append("\",");

                    json.append("\"fecha_cita\":\"")
                        .append(resultado.getString("fecha_cita")).append("\",");

                    json.append("\"peso\":")
                        .append(resultado.getInt("peso")).append(",");

                    json.append("\"altura\":")
                        .append(resultado.getInt("altura")).append(",");

                    json.append("\"razon_cita\":\"")
                        .append(resultado.getString("razon_cita")).append("\",");

                    json.append("\"diagnostico\":\"")
                        .append(resultado.getString("diagnostico")).append("\",");

                    json.append("\"lista_sintomas\":\"")
                        .append(resultado.getString("lista_sintomas")).append("\"");

                    json.append("}");

                    primero = false;
                }
            }

            json.append("]");

            String respuesta = json.toString();

            exchange.getResponseHeaders().set(
                "Content-Type", "application/json; charset=UTF-8"
            );

            byte[] bytes = respuesta.getBytes("UTF-8");

            exchange.sendResponseHeaders(200, bytes.length);

            try (OutputStream salida = exchange.getResponseBody()) {
                salida.write(bytes);
            }

        } catch (Exception e) {

            e.printStackTrace();

            String error = "{\"error\":\"No se pudieron obtener los historiales\"}";
            byte[] bytes = error.getBytes("UTF-8");

            exchange.getResponseHeaders().set(
                "Content-Type", "application/json; charset=UTF-8"
            );

            exchange.sendResponseHeaders(500, bytes.length);

            try (OutputStream salida = exchange.getResponseBody()) {
                salida.write(bytes);
            }
        }
    }
}

    private static void prepararBaseDeDatos() {
        String consulta = "SELECT COUNT(*) FROM information_schema.COLUMNS "
                + "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pacientes' AND COLUMN_NAME = 'Telefono'";
        try (Connection conexion = abrirConexion();
             Statement sentencia = conexion.createStatement();
             ResultSet rs = sentencia.executeQuery(consulta)) {
            rs.next();
            if (rs.getInt(1) == 0) {
                try (Statement alterar = conexion.createStatement()) {
                    alterar.executeUpdate("ALTER TABLE pacientes ADD COLUMN Telefono VARCHAR(30)");
                }
                System.out.println("Se agrego la columna Telefono a la tabla pacientes");
            }
        } catch (SQLException e) {
            System.err.println("No se pudo revisar la tabla pacientes: " + e.getMessage());
        }
    }

    private static final Map<String, Integer> SESIONES = new ConcurrentHashMap<>();
    private static final SecureRandom ALEATORIO = new SecureRandom();
    private static final String COOKIE_SESION = "CLINICA_SESION";

    private static Connection abrirConexion() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("No se encontro el driver de MySQL (Connector/J)", e);
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    private static String leerCuerpo(HttpExchange intercambio) throws IOException {
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(intercambio.getRequestBody(), "UTF-8"))) {
            return br.lines().collect(Collectors.joining());
        }
    }


    private static Map<String, String> leerDatos(HttpExchange intercambio) throws IOException {
        String cuerpo = leerCuerpo(intercambio).trim();
        Map<String, String> datos = new HashMap<>();
        if (cuerpo.isEmpty()) {
            return datos;
        }
        if (cuerpo.startsWith("{")) {
            Matcher m = Pattern.compile("\"([^\"]+)\"\\s*:\\s*(?:\"((?:\\\\.|[^\"\\\\])*)\"|([^,}\\s]+))").matcher(cuerpo);
            while (m.find()) {
                String v = m.group(2) != null ? desescaparJson(m.group(2)) : m.group(3);
                datos.put(m.group(1), v);
            }
        } else {
            for (String par : cuerpo.split("&")) {
                int i = par.indexOf('=');
                String clave = i >= 0 ? par.substring(0, i) : par;
                String valor = i >= 0 ? par.substring(i + 1) : "";
                datos.put(URLDecoder.decode(clave, "UTF-8"), URLDecoder.decode(valor, "UTF-8"));
            }
        }
        return datos;
    }

    private static String desescaparJson(String t) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (c == '\\' && i + 1 < t.length()) {
                char n = t.charAt(++i);
                switch (n) {
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    case 'u':
                        if (i + 4 < t.length()) {
                            sb.append((char) Integer.parseInt(t.substring(i + 1, i + 5), 16));
                            i += 4;
                        }
                        break;
                    default: sb.append(n);
                }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private static void enviarRespuesta(HttpExchange intercambio, int codigo, String json) throws IOException {
        byte[] bytes = json.getBytes("UTF-8");
        intercambio.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        intercambio.sendResponseHeaders(codigo, bytes.length);
        try (OutputStream os = intercambio.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static String escaparJson(String texto) {
        if (texto == null) {
            return "";
        }
        return texto.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r")
                    .replace("\t", "\\t");
    }

    private static String valor(Map<String, String> datos, String clave) {
        String v = datos.get(clave);
        return v == null ? "" : v.trim();
    }

    private static void iniciarSesion(HttpExchange intercambio, int dni) {
        byte[] bytes = new byte[24];
        ALEATORIO.nextBytes(bytes);
        StringBuilder token = new StringBuilder();
        for (byte b : bytes) {
            token.append(String.format("%02x", b));
        }
        SESIONES.put(token.toString(), dni);
        intercambio.getResponseHeaders().add("Set-Cookie",
                COOKIE_SESION + "=" + token + "; Path=/; HttpOnly; SameSite=Lax");
    }

    private static String tokenDeCookie(HttpExchange intercambio) {
        java.util.List<String> cookies = intercambio.getRequestHeaders().get("Cookie");
        if (cookies == null) {
            return null;
        }
        for (String linea : cookies) {
            for (String parte : linea.split(";")) {
                String p = parte.trim();
                if (p.startsWith(COOKIE_SESION + "=")) {
                    return p.substring(COOKIE_SESION.length() + 1);
                }
            }
        }
        return null;
    }

    private static Integer dniDeSesion(HttpExchange intercambio) {
        String token = tokenDeCookie(intercambio);
        return token == null ? null : SESIONES.get(token);
    }

    private static final String COLUMNAS_PERFIL =
            "DNI, Nombre, Apellido, Email, Fecha_Nacimiento, Genero, Telefono, Direccion, Seguro_Medico, Numero_Afiliado";

    private static String jsonPerfil(ResultSet rs) throws SQLException {
        return "{"
                + "\"dni\":\"" + rs.getInt("DNI") + "\","
                + "\"nombre\":\"" + escaparJson(rs.getString("Nombre")) + "\","
                + "\"apellido\":\"" + escaparJson(rs.getString("Apellido")) + "\","
                + "\"fechaNacimiento\":\"" + escaparJson(rs.getString("Fecha_Nacimiento")) + "\","
                + "\"sexo\":\"" + escaparJson(rs.getString("Genero")) + "\","
                + "\"telefono\":\"" + escaparJson(rs.getString("Telefono")) + "\","
                + "\"correo\":\"" + escaparJson(rs.getString("Email")) + "\","
                + "\"direccion\":\"" + escaparJson(rs.getString("Direccion")) + "\","
                + "\"obraSocial\":\"" + escaparJson(rs.getString("Seguro_Medico")) + "\","
                + "\"numeroAfiliado\":\"" + escaparJson(rs.getString("Numero_Afiliado")) + "\""
                + "}";
    }

    private static String perfilPorDni(Connection conexion, int dni) throws SQLException {
        try (PreparedStatement ps = conexion.prepareStatement(
                "SELECT " + COLUMNAS_PERFIL + " FROM pacientes WHERE DNI = ?")) {
            ps.setInt(1, dni);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? jsonPerfil(rs) : null;
            }
        }
    }

    static class RegistroHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange intercambio) throws IOException {

            String ruta = intercambio.getRequestURI().getPath();
            if (!ruta.equals("/registro") && !ruta.equals("/api/registro")) {
                new RecursosWebHandler().handle(intercambio);
                return;
            }

            String tipo = intercambio.getRequestHeaders().getFirst("Content-Type");
            boolean esFormulario = tipo != null && tipo.toLowerCase().startsWith("application/x-www-form-urlencoded");

            if (!intercambio.getRequestMethod().equalsIgnoreCase("POST")) {
                responderRegistro(intercambio, esFormulario, 405, "Metodo no permitido");
                return;
            }

            Map<String, String> datos = leerDatos(intercambio);

            String nombre = valor(datos, "nombre");
            String apellido = valor(datos, "apellido");
            String dniTexto = valor(datos, "dni");
            String correo = valor(datos, "correo").toLowerCase();
            String fecha = valor(datos, "fecha");
            String sexo = valor(datos, "sexo");
            String telefono = valor(datos, "telefono");
            String direccion = valor(datos, "direccion");
            String obraSocial = valor(datos, "obraSocial");
            String numeroAfiliado = valor(datos, "numeroAfiliado");
            String contrasena = datos.get("contrasena") == null ? "" : datos.get("contrasena");

            if (nombre.isEmpty() || apellido.isEmpty() || dniTexto.isEmpty() || correo.isEmpty()
                    || fecha.isEmpty() || sexo.isEmpty() || telefono.isEmpty() || direccion.isEmpty()
                    || obraSocial.isEmpty() || numeroAfiliado.isEmpty() || contrasena.isEmpty()) {
                responderRegistro(intercambio, esFormulario, 400, "Completa todos los campos");
                return;
            }
            if (!dniTexto.matches("\\d{7,8}")) {
                responderRegistro(intercambio, esFormulario, 400, "Revisa el DNI");
                return;
            }
            if (!correo.matches("[^@\\s]+@[^@\\s]+\\.[^@\\s]+")) {
                responderRegistro(intercambio, esFormulario, 400, "Revisa el correo electronico");
                return;
            }
            if (contrasena.length() < 8) {
                responderRegistro(intercambio, esFormulario, 400, "La contrase\u00f1a debe tener 8 caracteres o mas");
                return;
            }
            int dni = Integer.parseInt(dniTexto);

            String sqlPaciente = "INSERT INTO pacientes (Nombre, Apellido, DNI, Email, Fecha_Nacimiento, Direccion, "
                    + "Genero, Telefono, Seguro_Medico, Numero_Afiliado, Contrase\u00f1a) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            String sqlUsuario = "INSERT INTO Usuarios (Email, Contrase\u00f1a) VALUES (?, ?)";

            try (Connection conexion = abrirConexion()) {
                conexion.setAutoCommit(false);
                try {
                    if (existe(conexion, "SELECT 1 FROM pacientes WHERE DNI = ?", String.valueOf(dni))) {
                        conexion.rollback();
                        responderRegistro(intercambio, esFormulario, 409, "Ese DNI ya esta registrado");
                        return;
                    }
                    if (existe(conexion, "SELECT 1 FROM Usuarios WHERE Email = ?", correo)
                            || existe(conexion, "SELECT 1 FROM pacientes WHERE Email = ?", correo)) {
                        conexion.rollback();
                        responderRegistro(intercambio, esFormulario, 409, "Ese correo ya esta registrado");
                        return;
                    }

                    try (PreparedStatement ps = conexion.prepareStatement(sqlPaciente)) {
                        ps.setString(1, nombre);
                        ps.setString(2, apellido);
                        ps.setInt(3, dni);
                        ps.setString(4, correo);
                        ps.setString(5, fecha);
                        ps.setString(6, direccion);
                        ps.setString(7, sexo);
                        ps.setString(8, telefono);
                        ps.setString(9, obraSocial);
                        ps.setString(10, numeroAfiliado);
                        ps.setString(11, contrasena);
                        ps.executeUpdate();
                    }
                    try (PreparedStatement ps = conexion.prepareStatement(sqlUsuario)) {
                        ps.setString(1, correo);
                        ps.setString(2, contrasena);
                        ps.executeUpdate();
                    }
                    conexion.commit();
                } catch (SQLIntegrityConstraintViolationException e) {
                    conexion.rollback();
                    responderRegistro(intercambio, esFormulario, 409, "Ese DNI o correo ya estan registrados");
                    return;
                } catch (SQLException e) {
                    conexion.rollback();
                    throw e;
                }

                if (esFormulario) {

                    intercambio.getResponseHeaders().set("Location", "InicioSesion.html");
                    intercambio.sendResponseHeaders(303, -1);
                    intercambio.close();
                } else {
                    iniciarSesion(intercambio, dni);
                    enviarRespuesta(intercambio, 201, perfilPorDni(conexion, dni));
                }
            } catch (SQLException e) {
                e.printStackTrace();
                String detalle = e.getMessage() == null ? "" : e.getMessage();
                responderRegistro(intercambio, esFormulario, 500, "Error en la base de datos: "
                        + detalle.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"));
            }
        }

        private boolean existe(Connection conexion, String sql, String parametro) throws SQLException {
            try (PreparedStatement ps = conexion.prepareStatement(sql)) {
                ps.setString(1, parametro);
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next();
                }
            }
        }

        private void responderRegistro(HttpExchange intercambio, boolean esFormulario, int codigo, String mensaje)
                throws IOException {
            if (!esFormulario) {
                enviarRespuesta(intercambio, codigo, "{\"error\":\"" + escaparJson(mensaje) + "\"}");
                return;
            }
            String html = "<!DOCTYPE html><html lang=\"es\"><head><meta charset=\"UTF-8\">"
                    + "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
                    + "<title>Cl\u00ednica Privada</title></head>"
                    + "<body style=\"font-family:sans-serif;text-align:center;margin-top:80px\">"
                    + "<h2>No se pudo crear la cuenta</h2><p>" + mensaje + "</p>"
                    + "<p><a href=\"registro.html\">Volver al registro</a></p></body></html>";
            byte[] bytes = html.getBytes("UTF-8");
            intercambio.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            intercambio.sendResponseHeaders(codigo, bytes.length);
            try (OutputStream os = intercambio.getResponseBody()) {
                os.write(bytes);
            }
        }
    }

    static class LoginHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange intercambio) throws IOException {
            if (!intercambio.getRequestMethod().equalsIgnoreCase("POST")) {
                enviarRespuesta(intercambio, 405, "{\"error\":\"Metodo no permitido\"}");
                return;
            }

            Map<String, String> datos = leerDatos(intercambio);
            String dniTexto = valor(datos, "dni");
            String contrasena = datos.get("contrasena") == null ? "" : datos.get("contrasena");

            if (dniTexto.isEmpty() || contrasena.isEmpty()) {
                enviarRespuesta(intercambio, 400, "{\"error\":\"Faltan datos\"}");
                return;
            }
            if (!dniTexto.matches("\\d{7,8}")) {
                enviarRespuesta(intercambio, 401, "{\"error\":\"El DNI o la contrase\u00f1a no coinciden\"}");
                return;
            }
            int dni = Integer.parseInt(dniTexto);

            try (Connection conexion = abrirConexion();
                 PreparedStatement ps = conexion.prepareStatement(
                         "SELECT 1 FROM pacientes WHERE DNI = ? AND Contrase\u00f1a = ?")) {
                ps.setInt(1, dni);
                ps.setString(2, contrasena);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        enviarRespuesta(intercambio, 401, "{\"error\":\"El DNI o la contrase\u00f1a no coinciden\"}");
                        return;
                    }
                }
                iniciarSesion(intercambio, dni);
                enviarRespuesta(intercambio, 200, perfilPorDni(conexion, dni));
            } catch (SQLException e) {
                e.printStackTrace();
                enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
            }
        }
    }

    static class LogoutHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange intercambio) throws IOException {
            if (!intercambio.getRequestMethod().equalsIgnoreCase("POST")) {
                enviarRespuesta(intercambio, 405, "{\"error\":\"Metodo no permitido\"}");
                return;
            }
            String token = tokenDeCookie(intercambio);
            if (token != null) {
                SESIONES.remove(token);
            }
            intercambio.getResponseHeaders().add("Set-Cookie",
                    COOKIE_SESION + "=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax");
            enviarRespuesta(intercambio, 200, "{\"mensaje\":\"Sesion cerrada\"}");
        }
    }

    static class PerfilHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange intercambio) throws IOException {
            String metodo = intercambio.getRequestMethod();
            if (!metodo.equalsIgnoreCase("GET") && !metodo.equalsIgnoreCase("PUT")) {
                enviarRespuesta(intercambio, 405, "{\"error\":\"Metodo no permitido\"}");
                return;
            }

            Integer dni = dniDeSesion(intercambio);
            if (dni == null) {
                enviarRespuesta(intercambio, 401, "{\"error\":\"Sesion no iniciada\"}");
                return;
            }

            try (Connection conexion = abrirConexion()) {
                if (metodo.equalsIgnoreCase("PUT")) {
                    Map<String, String> datos = leerDatos(intercambio);
                    String nombre = valor(datos, "nombre");
                    String apellido = valor(datos, "apellido");
                    String fecha = valor(datos, "fechaNacimiento");
                    String telefono = valor(datos, "telefono");
                    String correo = valor(datos, "correo").toLowerCase();
                    String direccion = valor(datos, "direccion");
                    String obraSocial = valor(datos, "obraSocial");
                    String numeroAfiliado = valor(datos, "numeroAfiliado");
                    String contrasenaNueva = datos.get("contrasenaNueva") == null ? "" : datos.get("contrasenaNueva");

                    if (nombre.isEmpty() || apellido.isEmpty() || fecha.isEmpty() || telefono.isEmpty()
                            || correo.isEmpty() || direccion.isEmpty()
                            || obraSocial.isEmpty() || numeroAfiliado.isEmpty()) {
                        enviarRespuesta(intercambio, 400, "{\"error\":\"Completa todos los campos\"}");
                        return;
                    }
                    if (!correo.matches("[^@\\s]+@[^@\\s]+\\.[^@\\s]+")) {
                        enviarRespuesta(intercambio, 400, "{\"error\":\"Revisa el correo electronico\"}");
                        return;
                    }
                    if (!contrasenaNueva.isEmpty() && contrasenaNueva.length() < 8) {
                        enviarRespuesta(intercambio, 400, "{\"error\":\"La contrase\u00f1a debe tener 8 caracteres o mas\"}");
                        return;
                    }

                    conexion.setAutoCommit(false);
                    try {

                        String correoAnterior = null;
                        try (PreparedStatement ps = conexion.prepareStatement(
                                "SELECT Email FROM pacientes WHERE DNI = ?")) {
                            ps.setInt(1, dni);
                            try (ResultSet rs = ps.executeQuery()) {
                                if (rs.next()) {
                                    correoAnterior = rs.getString("Email");
                                }
                            }
                        }


                        if (!correo.equalsIgnoreCase(correoAnterior == null ? "" : correoAnterior)) {
                            try (PreparedStatement ps = conexion.prepareStatement(
                                    "SELECT 1 FROM pacientes WHERE Email = ? AND DNI <> ? "
                                    + "UNION SELECT 1 FROM Usuarios WHERE Email = ?")) {
                                ps.setString(1, correo);
                                ps.setInt(2, dni);
                                ps.setString(3, correo);
                                try (ResultSet rs = ps.executeQuery()) {
                                    if (rs.next()) {
                                        conexion.rollback();
                                        enviarRespuesta(intercambio, 409, "{\"error\":\"Ese correo ya esta registrado\"}");
                                        return;
                                    }
                                }
                            }
                        }

                        String sql = "UPDATE pacientes SET Nombre = ?, Apellido = ?, Fecha_Nacimiento = ?, "
                                + "Telefono = ?, Email = ?, Direccion = ?, Seguro_Medico = ?, Numero_Afiliado = ?"
                                + (contrasenaNueva.isEmpty() ? "" : ", Contrase\u00f1a = ?")
                                + " WHERE DNI = ?";
                        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
                            int i = 1;
                            ps.setString(i++, nombre);
                            ps.setString(i++, apellido);
                            ps.setString(i++, fecha);
                            ps.setString(i++, telefono);
                            ps.setString(i++, correo);
                            ps.setString(i++, direccion);
                            ps.setString(i++, obraSocial);
                            ps.setString(i++, numeroAfiliado);
                            if (!contrasenaNueva.isEmpty()) {
                                ps.setString(i++, contrasenaNueva);
                            }
                            ps.setInt(i, dni);
                            ps.executeUpdate();
                        }


                        if (correoAnterior != null) {
                            String sqlUsuario = "UPDATE Usuarios SET Email = ?"
                                    + (contrasenaNueva.isEmpty() ? "" : ", Contrase\u00f1a = ?")
                                    + " WHERE Email = ?";
                            try (PreparedStatement ps = conexion.prepareStatement(sqlUsuario)) {
                                int i = 1;
                                ps.setString(i++, correo);
                                if (!contrasenaNueva.isEmpty()) {
                                    ps.setString(i++, contrasenaNueva);
                                }
                                ps.setString(i, correoAnterior);
                                ps.executeUpdate();
                            }
                        }
                        conexion.commit();
                    } catch (SQLException e) {
                        conexion.rollback();
                        throw e;
                    }
                }

                String perfil = perfilPorDni(conexion, dni);
                if (perfil == null) {
                    enviarRespuesta(intercambio, 404, "{\"error\":\"No se encontro el paciente\"}");
                } else {
                    enviarRespuesta(intercambio, 200, perfil);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                enviarRespuesta(intercambio, 500, "{\"error\":\"Error en la base de datos\"}");
            }
        }
    }

    static class TurnosPacienteHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange intercambio) throws IOException {
            String metodo = intercambio.getRequestMethod();
            if (!metodo.equalsIgnoreCase("GET") && !metodo.equalsIgnoreCase("POST")) {
                enviarRespuesta(intercambio, 405, "{\"error\":\"Metodo no permitido\"}");
                return;
            }

            Integer dni = dniDeSesion(intercambio);
            if (dni == null) {
                enviarRespuesta(intercambio, 401, "{\"error\":\"Sesion no iniciada\"}");
                return;
            }

            if (metodo.equalsIgnoreCase("POST")) {
                guardarTurno(intercambio, dni);
                return;
            }

            String sql = "SELECT id_turno, nombre_completoMedico, fecha_hora, Especialidad, sala, estado, motivoConsulta "
                    + "FROM turnos WHERE codigo_paciente = ?";

            java.util.List<String[]> proximos = new java.util.ArrayList<>();
            java.util.List<String[]> anteriores = new java.util.ArrayList<>();
            String ahora = java.time.LocalDateTime.now()
                    .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));

            try (Connection conexion = abrirConexion();
                 PreparedStatement ps = conexion.prepareStatement(sql)) {
                ps.setInt(1, dni);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        String fecha = rs.getString("fecha_hora") == null ? "" : rs.getString("fecha_hora").replace('T', ' ');
                        String estado = rs.getString("estado") == null ? "" : rs.getString("estado");
                        String[] fila = {
                            String.valueOf(rs.getInt("id_turno")),
                            fecha,
                            rs.getString("Especialidad"),
                            rs.getString("nombre_completoMedico"),
                            rs.getString("motivoConsulta"),
                            String.valueOf(rs.getInt("sala")),
                            estado
                        };

                        String comparable = fecha.length() >= 16 ? fecha.substring(0, 16) : fecha;
                        boolean futuro = !comparable.isEmpty() && comparable.compareTo(ahora) >= 0;
                        if (futuro && !estado.equalsIgnoreCase("Cancelado")) {
                            proximos.add(fila);
                        } else {
                            anteriores.add(fila);
                        }
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                enviarRespuesta(intercambio, 500, "{\"error\":\"No se pudieron obtener los turnos\"}");
                return;
            }

            proximos.sort((a, b) -> a[1].compareTo(b[1]));
            anteriores.sort((a, b) -> b[1].compareTo(a[1]));

            enviarRespuesta(intercambio, 200,
                    "{\"proximos\":" + jsonTurnos(proximos) + ",\"anteriores\":" + jsonTurnos(anteriores) + "}");
        }

        private void guardarTurno(HttpExchange intercambio, int dni) throws IOException {
            Map<String, String> datos = leerDatos(intercambio);
            String fechaHora = valor(datos, "fechaHora").replace('T', ' ');
            String especialidad = valor(datos, "especialidad");
            String motivo = valor(datos, "motivo");

            if (fechaHora.isEmpty() || especialidad.isEmpty() || motivo.isEmpty()) {
                enviarRespuesta(intercambio, 400, "{\"error\":\"Completa todos los campos\"}");
                return;
            }
            if (!fechaHora.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}(:\\d{2})?")) {
                enviarRespuesta(intercambio, 400, "{\"error\":\"Fecha y hora no validas\"}");
                return;
            }
            String ahora = java.time.LocalDateTime.now()
                    .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
            if (fechaHora.substring(0, 16).compareTo(ahora) < 0) {
                enviarRespuesta(intercambio, 400, "{\"error\":\"La fecha y hora ya pasaron\"}");
                return;
            }

            String sql = "INSERT INTO turnos (codigo_paciente, nombre_completoMedico, fecha_hora, "
                    + "matricula_medico, Especialidad, sala, estado, motivoConsulta, tipoTurno) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (Connection conexion = abrirConexion();
                 PreparedStatement ps = conexion.prepareStatement(sql)) {
                ps.setInt(1, dni);
                ps.setString(2, "A Asignar");
                ps.setString(3, fechaHora);
                ps.setString(4, null);
                ps.setString(5, especialidad);
                ps.setInt(6, 0);
                ps.setString(7, "Pendiente");
                ps.setString(8, motivo);
                ps.setString(9, "A Asignar");
                ps.executeUpdate();
                enviarRespuesta(intercambio, 201, "{\"mensaje\":\"Turno solicitado correctamente\"}");
            } catch (SQLException e) {
                e.printStackTrace();
                enviarRespuesta(intercambio, 500, "{\"error\":\"No se pudo guardar el turno\"}");
            }
        }

        private String jsonTurnos(java.util.List<String[]> filas) {
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < filas.size(); i++) {
                String[] f = filas.get(i);
                if (i > 0) {
                    sb.append(",");
                }
                sb.append("{\"id\":").append(f[0])
                  .append(",\"fecha\":\"").append(escaparJson(f[1]))
                  .append("\",\"especialidad\":\"").append(escaparJson(f[2]))
                  .append("\",\"medico\":\"").append(escaparJson(f[3]))
                  .append("\",\"motivo\":\"").append(escaparJson(f[4]))
                  .append("\",\"sala\":").append(f[5])
                  .append(",\"estado\":\"").append(escaparJson(f[6])).append("\"}");
            }
            return sb.append("]").toString();
        }
    }

    static class RecursosWebHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            if (path.equals("/")) {
                path = "/index.html";
            }

            File archivo = new File("src/Web" + path);

            if (archivo.exists() && !archivo.isDirectory()) {
                String contentType = Files.probeContentType(archivo.toPath());
                if (path.endsWith(".css")) contentType = "text/css";
                
                if (contentType != null) {
                    exchange.getResponseHeaders().set("Content-Type", contentType);
                }

                exchange.sendResponseHeaders(200, archivo.length());
                OutputStream os = exchange.getResponseBody();
                FileInputStream fis = new FileInputStream(archivo);
                
                byte[] buffer = new byte[1024];
                int count;
                while ((count = fis.read(buffer)) >= 0) {
                    os.write(buffer, 0, count);
                }
                
                fis.close();
                os.close();
            } else {
                String respuesta404 = "404 - Archivo no encontrado en la carpeta Web";
                exchange.sendResponseHeaders(404, respuesta404.length());
                OutputStream os = exchange.getResponseBody();
                os.write(respuesta404.getBytes());
                os.close();
            }
        }
    }

    static class GuardarTurnoHandler implements HttpHandler {
        @Override
public void handle(HttpExchange exchange) throws IOException {

    exchange.getResponseHeaders().set("Content-Type", "application/json");

    if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
        exchange.sendResponseHeaders(204, -1);
        exchange.close();
        return;
    }

    if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
        exchange.sendResponseHeaders(405, -1);
        exchange.close();
        return;
    }

    BufferedReader br = new BufferedReader(
        new InputStreamReader(exchange.getRequestBody(), "UTF-8")
    );

    String json = br.lines().collect(Collectors.joining());

    System.out.println("JSON recibido: " + json);

    String dni = buscarPropiedadRegex(json, "codigo_paciente");
    String fechaHora = buscarPropiedadRegex(json, "fecha_hora");
    String especialidad = buscarPropiedadRegex(json, "Especialidad");
    String motivo = buscarPropiedadRegex(json, "motivoConsulta");

    if (dni.isEmpty() || fechaHora.isEmpty() ||
        especialidad.isEmpty() || motivo.isEmpty()) {

        exchange.sendResponseHeaders(400, -1);
        exchange.close();
        return;
    }

    fechaHora = fechaHora.replace("T", " ");

    boolean insertExitoso = insertarTurnoDirecto(
        dni, fechaHora, especialidad, motivo
    );

    if (insertExitoso) {
        String respuesta = "{\"status\":\"success\"}";
        byte[] datos = respuesta.getBytes("UTF-8");

        exchange.sendResponseHeaders(200, datos.length);

        try (OutputStream os = exchange.getResponseBody()) {
            os.write(datos);
        }

    } else {
        exchange.sendResponseHeaders(400, -1);
        exchange.close();
    }
}

         private boolean insertarTurnoDirecto(String dni, String fecha, String especialidad, String motivo) {
            String query = "INSERT INTO turnos (codigo_paciente, nombre_completoMedico, fecha_hora, "
                         + "matricula_medico, Especialidad, sala, estado, motivoConsulta, tipoTurno) "
                         + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try {
                Class.forName("com.mysql.jdbc.Driver");
                try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                     PreparedStatement pstmt = conn.prepareStatement(query)) {
                    
                    pstmt.setInt(1, Integer.parseInt(dni));
                    pstmt.setString(2, "A Asignar");
                    pstmt.setString(3, fecha);
                    pstmt.setString(4, null); 
                    pstmt.setString(5, especialidad);
                    pstmt.setInt(6, 0);
                    pstmt.setString(7, "Pendiente");
                    pstmt.setString(8, motivo);
                    pstmt.setString(9, "A Asignar");
                    
                    int rows = pstmt.executeUpdate();
                    System.out.println("\u00a1Filas insertadas con \u00e9xito!: " + rows);
                    return rows > 0;
                }
            } catch (Exception e) {

                System.err.println("\u274c ERROR CR\u00cdTICO AL INSERTAR EN MYSQL:");
                System.err.println("Mensaje del error: " + e.getMessage());
                e.printStackTrace(); 
                return false;
            }
        }

        private String buscarPropiedadRegex(String json, String propiedad) {
            Pattern pattern = Pattern.compile("\"" + propiedad + "\"\\s*:\\s*\"([^\"]*)\"");
            Matcher matcher = pattern.matcher(json);
            if (matcher.find()) {
                return matcher.group(1);
            }
            pattern = Pattern.compile("\"" + propiedad + "\"\\s*:\\s*([^,}]*)");
            matcher = pattern.matcher(json);
            if (matcher.find()) {
                return matcher.group(1).trim().replace("\"", "");
            }
            return "";
        }
    }
}
