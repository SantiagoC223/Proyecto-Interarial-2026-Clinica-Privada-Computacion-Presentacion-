package Servidor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PruebaConexion {

    public static void main(String[] args) {
        
        
        String url = "jdbc:mysql://localhost:3306/clinica_privada";
        String usuario = "root";
        String contrasena = "";

        String sql = "SELECT * FROM pacientes";

        try {
            Connection conexion = DriverManager.getConnection(
                    url, usuario, contrasena
            );

            System.out.println("¡Conexión exitosa a MySQL!");

            PreparedStatement sentencia = conexion.prepareStatement(sql);

            ResultSet resultado = sentencia.executeQuery();

            while (resultado.next()) {

                int id = resultado.getInt("id_paciente");
                String Nombre = resultado.getString("Nombre");
                String Apellido = resultado.getString("Apellido");
                int DNI = resultado.getInt("DNI");
                String Email = resultado.getString("Email");
                String Fecha_Nacimiento = resultado.getString("Fecha_Nacimiento");
                
                String Direccion = resultado.getString("Direccion");
                String Genero = resultado.getString("Genero");
                String Seguro_Medico = resultado.getString("Seguro_Medico");
                String Numero_Afiliado = resultado.getString("Numero_Afiliado");
                String Grupo_Sanguineo = resultado.getString("Grupo_Sanguineo");
                String Lista_Historial = resultado.getString("Lista_Historial");

                System.out.println("ID: " + id);  
                System.out.println("Nombre: " + Nombre);
                System.out.println("Apellido: " + Apellido);
                System.out.println("DNI: " + DNI);
                System.out.println("Edad: " + Email);
                System.out.println("Correo: " + Fecha_Nacimiento);
                
                System.out.println("Direccion: " + Direccion);
                System.out.println("Genero: " + Genero);
                System.out.println("Seguro_Medico: " + Seguro_Medico);
                System.out.println("Numero_Afiliado: " + Numero_Afiliado);
                System.out.println("Grupo_Sanguineo: " + Grupo_Sanguineo);
                System.out.println("Lista_Historial: " + Lista_Historial);
                
                
                
                System.out.println("--------------------------");
            }

            resultado.close();
            sentencia.close();
            conexion.close();

        } catch (SQLException e) {
            System.out.println("Error al consultar la base de datos:");
            e.printStackTrace();
        }
    }
}

