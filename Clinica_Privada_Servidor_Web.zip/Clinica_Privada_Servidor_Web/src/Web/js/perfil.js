document.addEventListener('DOMContentLoaded', () => {
    const API_BASE_URL = 'http://localhost:8080/api';
    const formulario = document.getElementById('formulario-perfil');
    const botonGuardar = document.getElementById('guardar-perfil');
    const botonMenu = document.getElementById('btn-paciente');
    const menu = document.getElementById('menu-opciones');
    const enlaceCerrarSesion = document.getElementById('cerrar-sesion');

    function mostrarMensaje(texto) {
        alert(texto);
    }

    // Validación propia: los avisos salen como alert en vez del cartel del navegador.
    function validarFormulario() {
        const obligatorios = [
            ['fechaNacimiento', 'Fecha de nacimiento'],
            ['nombre', 'Nombre'],
            ['apellido', 'Apellido'],
            ['telefono', 'Teléfono'],
            ['correo', 'Correo electrónico'],
            ['direccion', 'Dirección'],
            ['obraSocial', 'Obra social'],
            ['numeroAfiliado', 'Número de afiliado']
        ];

        for (const [id, etiqueta] of obligatorios) {
            const campo = document.getElementById(id);
            if (!campo.value.trim()) {
                alert(`Completá el campo "${etiqueta}".`);
                campo.focus();
                return false;
            }
        }

        const correo = document.getElementById('correo');
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo.value.trim())) {
            alert('Ingresá un correo electrónico válido (por ejemplo: nombre@gmail.com).');
            correo.focus();
            return false;
        }

        const contrasena = document.getElementById('contrasenaNueva');
        if (contrasena.value && contrasena.value.length < 8) {
            alert('La nueva contraseña debe tener al menos 8 caracteres.');
            contrasena.focus();
            return false;
        }

        return true;
    }

    async function solicitarPerfil(opciones = {}) {
        const respuesta = await fetch(`${API_BASE_URL}/pacientes/perfil`, {
            credentials: 'include',
            headers: opciones.body ? { 'Content-Type': 'application/json' } : {},
            ...opciones
        });

        if (respuesta.status === 401) {
            window.location.href = 'InicioSesion.html';
            throw new Error('Tu sesión venció. Iniciá sesión nuevamente.');
        }

        const texto = await respuesta.text();
        let contenido = {};
        if (texto.trim()) {
            try {
                contenido = JSON.parse(texto);
            } catch {
                throw new Error('El servidor respondió con un formato no válido.');
            }
        }
        if (!respuesta.ok) {
            throw new Error(contenido.mensaje || contenido.message || contenido.error || 'No se pudo completar la operación.');
        }
        return contenido;
    }

    function cargarCampos(perfil) {
        document.getElementById('dni').value = perfil.dni || '';
        document.getElementById('fechaNacimiento').value = perfil.fechaNacimiento || '';
        document.getElementById('nombre').value = perfil.nombre || '';
        document.getElementById('apellido').value = perfil.apellido || '';
        document.getElementById('telefono').value = perfil.telefono || '';
        document.getElementById('correo').value = perfil.correo || '';
        document.getElementById('direccion').value = perfil.direccion || '';
        document.getElementById('obraSocial').value = perfil.obraSocial || '';
        document.getElementById('numeroAfiliado').value = perfil.numeroAfiliado || '';
    }

    // Mantiene al día los datos que muestran las otras pantallas.
    function actualizarCopiaLocal(perfil) {
        try {
            const usuarios = JSON.parse(localStorage.getItem('clinicaUsuarios') || '[]');
            const indice = usuarios.findIndex((u) => u.dni === perfil.dni);
            if (indice >= 0) {
                usuarios[indice] = { ...usuarios[indice], ...perfil, fecha: perfil.fechaNacimiento };
                localStorage.setItem('clinicaUsuarios', JSON.stringify(usuarios));
            }
        } catch {
            // si el navegador no deja guardar, no pasa nada: los datos ya están en la base
        }
    }

    async function cargarPerfil() {
        botonGuardar.disabled = true;
        try {
            const perfil = await solicitarPerfil();
            cargarCampos(perfil);
        } catch (error) {
            mostrarMensaje(error.message || 'No se pudieron cargar tus datos.');
        } finally {
            botonGuardar.disabled = false;
        }
    }

    if (botonMenu && menu) {
        botonMenu.addEventListener('click', () => {
            const abierto = menu.classList.toggle('show');
            botonMenu.setAttribute('aria-expanded', String(abierto));
        });

        document.addEventListener('click', (evento) => {
            if (!menu.contains(evento.target) && !botonMenu.contains(evento.target)) {
                menu.classList.remove('show');
                botonMenu.setAttribute('aria-expanded', 'false');
            }
        });
    }

    if (enlaceCerrarSesion) {
        enlaceCerrarSesion.addEventListener('click', async (evento) => {
            evento.preventDefault();
            try {
                const respuesta = await fetch(`${API_BASE_URL}/auth/logout`, {
                    method: 'POST',
                    credentials: 'include'
                });
                if (!respuesta.ok) throw new Error('No se pudo cerrar la sesión.');
                localStorage.removeItem('clinicaPacienteActual');
                window.location.href = 'InicioSesion.html';
            } catch (error) {
                mostrarMensaje(error.message || 'No se pudo cerrar la sesión.');
            }
        });
    }

    formulario.addEventListener('submit', async (evento) => {
        evento.preventDefault();
        if (!validarFormulario()) return;

        const datos = {
            fechaNacimiento: document.getElementById('fechaNacimiento').value,
            nombre: document.getElementById('nombre').value.trim(),
            apellido: document.getElementById('apellido').value.trim(),
            telefono: document.getElementById('telefono').value.trim(),
            correo: document.getElementById('correo').value.trim().toLowerCase(),
            direccion: document.getElementById('direccion').value.trim(),
            obraSocial: document.getElementById('obraSocial').value.trim(),
            numeroAfiliado: document.getElementById('numeroAfiliado').value.trim()
        };
        const contrasenaNueva = document.getElementById('contrasenaNueva').value;
        if (contrasenaNueva) datos.contrasenaNueva = contrasenaNueva;

        botonGuardar.disabled = true;
        try {
            const perfilActualizado = await solicitarPerfil({
                method: 'PUT',
                body: JSON.stringify(datos)
            });
            if (perfilActualizado.dni) {
                cargarCampos(perfilActualizado);
                actualizarCopiaLocal(perfilActualizado);
            }
            document.getElementById('contrasenaNueva').value = '';
            mostrarMensaje('Los cambios se guardaron correctamente.');
        } catch (error) {
            mostrarMensaje(error.message || 'No se pudieron guardar los cambios.');
        } finally {
            botonGuardar.disabled = false;
        }
    });

    cargarPerfil();
});
