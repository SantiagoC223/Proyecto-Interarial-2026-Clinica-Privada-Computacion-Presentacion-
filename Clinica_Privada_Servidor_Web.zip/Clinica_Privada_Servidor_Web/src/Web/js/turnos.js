document.addEventListener('DOMContentLoaded', () => {
    const tablaProximos = document.getElementById('tabla-proximos');
    const tablaAnteriores = document.getElementById('tabla-anteriores');
    if (!tablaProximos || !tablaAnteriores) return;

    function formatearFecha(texto) {

        const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}:\d{2})/.exec(texto || '');
        return m ? `${m[3]}/${m[2]}/${m[1]} ${m[4]}` : (texto || '—');
    }

    function celda(texto) {
        const td = document.createElement('td');
        td.textContent = texto;
        return td;
    }

    function llenar(tbody, turnos, mensajeVacio) {
        tbody.innerHTML = '';
        if (!turnos.length) {
            const fila = document.createElement('tr');
            const td = celda(mensajeVacio);
            td.colSpan = 4;
            fila.appendChild(td);
            tbody.appendChild(fila);
            return;
        }
        turnos.forEach((turno) => {
            const profesional = turno.medico && turno.medico !== 'A Asignar'
                ? `${turno.especialidad} - ${turno.medico}`
                : `${turno.especialidad} (profesional a asignar)`;
            const estado = turno.estado ? ` [${turno.estado}]` : '';
            const fila = document.createElement('tr');
            fila.appendChild(celda(formatearFecha(turno.fecha)));
            fila.appendChild(celda(profesional));
            fila.appendChild(celda(turno.motivo + estado));
            fila.appendChild(celda(turno.sala ? String(turno.sala) : 'A asignar'));
            tbody.appendChild(fila);
        });
    }

    fetch('/api/pacientes/turnos', { credentials: 'include' })
        .then((respuesta) => {
            if (respuesta.status === 401) {
                window.location.href = 'InicioSesion.html';
                throw new Error('sesion');
            }
            if (!respuesta.ok) throw new Error('error');
            return respuesta.json();
        })
        .then((datos) => {
            llenar(tablaProximos, datos.proximos || [], 'No tenés turnos próximos.');
            llenar(tablaAnteriores, datos.anteriores || [], 'No tenés turnos anteriores.');
        })
        .catch((error) => {
            if (error.message === 'sesion') return;
            llenar(tablaProximos, [], 'No se pudieron cargar los turnos.');
            llenar(tablaAnteriores, [], 'No se pudieron cargar los turnos.');
        });
});
