document.addEventListener('DOMContentLoaded', () => {
    const turnoForm = document.getElementById('turnoForm');
    if (!turnoForm) {
        return;
    }

    const campoDni = document.getElementById('dni');
    try {
        const paciente = ClinicaSesion.obtenerPacienteActual();
        if (campoDni && paciente) {
            campoDni.value = paciente.dni;
            campoDni.readOnly = true;
        }
    } catch (error) {

    }

    turnoForm.addEventListener('submit', (evento) => {
        evento.preventDefault();

        const dni = document.getElementById('dni')?.value.trim() || '';
        const fechaHora = document.getElementById('fechaHora')?.value.trim() || '';
        const especialidad = document.getElementById('especialidad')?.value.trim() || '';
        const motivo = document.getElementById('motivo')?.value.trim() || '';

        const faltantes = [
            ['dni', dni, 'DNI'],
            ['fechaHora', fechaHora, 'Fecha y Hora Estimada'],
            ['especialidad', especialidad, 'Especialidad'],
            ['motivo', motivo, 'Motivo De La Consulta']
        ];
        for (const [id, valor, etiqueta] of faltantes) {
            if (!valor) {
                alert('Completá el campo "' + etiqueta + '".');
                const campo = document.getElementById(id);
                if (campo) campo.focus();
                return;
            }
        }

        fetch('/api/pacientes/turnos', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fechaHora, especialidad, motivo })
        })
            .then((respuesta) => {
                if (respuesta.status === 401) {
                    window.location.href = 'InicioSesion.html';
                    return null;
                }
                return respuesta.json().then((datos) => ({ ok: respuesta.ok, datos }));
            })
            .then((resultado) => {
                if (!resultado) return;
                if (resultado.ok) {
                    alert('Turno solicitado correctamente.');
                    window.location.href = 'Turnos.html';
                } else {
                    alert(resultado.datos.error || 'Hubo un error, inténtalo de nuevo.');
                }
            })
            .catch(() => alert('No se pudo conectar con el servidor.'));
    });
});
