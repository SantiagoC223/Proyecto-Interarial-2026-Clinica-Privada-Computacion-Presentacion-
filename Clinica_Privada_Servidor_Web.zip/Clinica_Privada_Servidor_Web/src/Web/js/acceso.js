function respuestaJson(respuesta) {
    return respuesta.text().then((texto) => {
        let datos = {};
        try {
            datos = texto ? JSON.parse(texto) : {};
        } catch (error) {
            datos = {};
        }
        return { ok: respuesta.ok, datos };
    });
}

// Deja los datos del paciente en el navegador para que el resto de las pantallas los muestren.
function guardarSesionLocal(paciente) {
    const usuario = {
        dni: paciente.dni,
        nombre: paciente.nombre,
        apellido: paciente.apellido,
        fecha: paciente.fechaNacimiento,
        sexo: paciente.sexo,
        telefono: paciente.telefono,
        correo: paciente.correo,
        direccion: paciente.direccion,
        obraSocial: paciente.obraSocial,
        numeroAfiliado: paciente.numeroAfiliado
    };
    const usuarios = ClinicaSesion.obtenerUsuarios().filter((cuenta) => cuenta.dni !== usuario.dni);
    usuarios.push(usuario);
    ClinicaSesion.guardarUsuarios(usuarios);
    ClinicaSesion.iniciarSesion(usuario.dni);
}

function Atras() {
    window.location.href = 'index.html';
}

function IniciarSesion(event) {
    event.preventDefault();

    const dni = document.getElementById('documento').value.trim();
    const contrasena = document.getElementById('contrasena').value;
    if (!dni || !contrasena) {
        alert('Completá el DNI y la contraseña.');
        return;
    }
    if (!/^\d{7,8}$/.test(dni)) {
        alert('Revisá el DNI.');
        document.getElementById('documento').focus();
        return;
    }

    fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dni, contrasena })
    })
        .then(respuestaJson)
        .then(({ ok, datos }) => {
            if (!ok) {
                alert(datos.error || 'El DNI o la contraseña no coinciden.');
                return;
            }
            guardarSesionLocal(datos);
            window.location.href = 'Gestion.html';
        })
        .catch(() => alert('No se pudo conectar con el servidor.'));
}

function Registrar(event) {
    event.preventDefault();

    const obligatorios = [
        ['dni', 'Nro. Documento'],
        ['fecha', 'Fecha de nacimiento'],
        ['apellido', 'Apellido'],
        ['nombre', 'Nombre'],
        ['sexo', 'Sexo'],
        ['telefono', 'Teléfono'],
        ['correo', 'Correo electrónico'],
        ['direccion', 'Dirección'],
        ['obraSocial', 'Obra social'],
        ['numeroAfiliado', 'Número de afiliado'],
        ['contrasena', 'Contraseña']
    ];

    for (const [id, etiqueta] of obligatorios) {
        const campo = document.getElementById(id);
        const valor = id === 'contrasena' ? campo.value : campo.value.trim();
        if (!valor) {
            alert('Completá el campo "' + etiqueta + '".');
            campo.focus();
            return;
        }
    }

    const dni = document.getElementById('dni');
    if (!/^\d{7,8}$/.test(dni.value.trim())) {
        alert('Revisá el DNI: debe tener 7 u 8 números.');
        dni.focus();
        return;
    }

    const correo = document.getElementById('correo');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo.value.trim())) {
        alert('Ingresá un correo electrónico válido (por ejemplo: nombre@gmail.com).');
        correo.focus();
        return;
    }

    const contrasena = document.getElementById('contrasena');
    if (contrasena.value.length < 8) {
        alert('La contraseña debe tener al menos 8 caracteres.');
        contrasena.focus();
        return;
    }

    const datos = {};
    for (const [id] of obligatorios) {
        const campo = document.getElementById(id);
        datos[id] = id === 'contrasena' ? campo.value : campo.value.trim();
    }

    fetch('/api/registro', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(datos)
    })
        .then(respuestaJson)
        .then(({ ok, datos: respuesta }) => {
            if (!ok) {
                alert(respuesta.error || 'No se pudo crear la cuenta.');
                return;
            }
            alert('Cuenta creada correctamente. Ahora podés iniciar sesión.');
            window.location.href = 'InicioSesion.html';
        })
        .catch(() => alert('No se pudo conectar con el servidor.'));
}
