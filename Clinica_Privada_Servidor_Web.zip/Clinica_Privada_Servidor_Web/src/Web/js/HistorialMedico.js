
const tabla = document.getElementById("tabla-historial");

fetch("/api/historial_medico")
    .then(respuesta => {
        if (!respuesta.ok) {
            throw new Error("Error al obtener los historiales");
        }

        return respuesta.json();
    })
    .then(historiales => {

        tabla.innerHTML = "";

        if (historiales.length === 0) {
            tabla.innerHTML = `
                <tr>
                    <td colspan="11">No hay historiales registrados.</td>
                </tr>
            `;
            return;
        }

        historiales.forEach(historial => {

            const fila = document.createElement("tr");

            const datos = [
                historial.id_historial,
                historial.DNI_Paciente,
                historial.id_medico,
                historial.nombreDeLaEnfermedad,
                historial.nombreMedicamento,
                historial.fecha_cita,
                historial.peso,
                historial.altura,
                historial.razon_cita,
                historial.diagnostico,
                historial.lista_sintomas
            ];

            datos.forEach(dato => {
                const celda = document.createElement("td");
                celda.textContent = dato ?? "";
                fila.appendChild(celda);
            });

            tabla.appendChild(fila);
        });

    })
    .catch(error => {
        console.error("Error:", error);

        tabla.innerHTML = `
            <tr>
                <td colspan="11">No se pudieron cargar los historiales.</td>
            </tr>
        `;
    });
