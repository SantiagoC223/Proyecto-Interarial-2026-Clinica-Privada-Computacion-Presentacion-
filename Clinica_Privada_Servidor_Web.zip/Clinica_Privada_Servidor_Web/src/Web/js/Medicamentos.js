
const tabla = document.getElementById("tabla-medicamentos");

fetch("/api/medicamentos")
    .then(respuesta => {
        if (!respuesta.ok) {
            throw new Error("Error al obtener los medicamentos");
        }

        return respuesta.json();
    })
    .then(medicamentos => {

        tabla.innerHTML = "";

        if (medicamentos.length === 0) {
            tabla.innerHTML = `
                <tr>
                    <td colspan="10">No hay medicamentos registrados.</td>
                </tr>
            `;
            return;
        }

        medicamentos.forEach(medicamento => {

            const fila = document.createElement("tr");

            const datos = [
                medicamento.id_medicamento,
                medicamento.nombre,
                medicamento.grupo_anatomico,
                medicamento.tipo,
                medicamento.condicion_venta,
                medicamento.forma_farmaceutica,
                medicamento.Categoria_Subtipo,
                medicamento.Via_Administracion,
                medicamento.Dosis_Unidad,
                medicamento.dosis_cantidad
            ];

            datos.forEach(dato => {
                const celda = document.createElement("td");
                celda.textContent = dato ?? "";
                fila.appendChild(celda);
            });

            tabla.appendChild(fila);
        });

    })
    .catch(error => {
        console.error("Error:", error);
    });
