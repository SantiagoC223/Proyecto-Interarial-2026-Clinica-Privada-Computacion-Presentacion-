package clinica_privada_poo_2026;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.CallableStatement;

public class Historial_MedicoDAO {
    
    public void insertar(Historial_Medico hm) {
        String consulta_sql = "call historial_registrar(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, hm.getDNI_Paciente());
            sentencia_sql.setString(2, hm.getId_medico());
            sentencia_sql.setString(3, hm.getNombreDeLaEnfermedad());
            sentencia_sql.setString(4, hm.getNombreMedicamento());
            sentencia_sql.setString(5, hm.getFecha_Cita());
            sentencia_sql.setInt(6, hm.getPeso());
            sentencia_sql.setInt(7, hm.getAltura());
            sentencia_sql.setString(8, hm.getRazon_Cita());
            sentencia_sql.setString(9, hm.getDiagnostico());
            sentencia_sql.setString(10, hm.getLista_Sintomas());

            sentencia_sql.executeUpdate();
            System.out.println("Historial médico guardado exitosamente");

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
    
    /*public void insertar(Historial_Medico hm){
        String consulta_sql = "INSERT INTO historial_medico(DNI_Paciente, id_medico, nombreDeLaEnfermedad, nombreMedicamento, fecha_cita, peso, altura, razon_cita, diagnostico, lista_sintomas) Values(?,?,?,?,?,?,?,?,?,?) ";
        
 
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setInt(1,hm.getDNI_Paciente());
            sentencia_sql.setString(2,hm.getId_medico());
            sentencia_sql.setString(3,hm.getNombreDeLaEnfermedad());
            sentencia_sql.setString(4,hm.getNombreMedicamento());
            sentencia_sql.setString(5,hm.getFecha_Cita());
            sentencia_sql.setInt(6,hm.getPeso());
            sentencia_sql.setInt(7,hm.getAltura());
            sentencia_sql.setString(8,hm.getRazon_Cita());
            sentencia_sql.setString(9,hm.getDiagnostico());
            sentencia_sql.setString(10,hm.getLista_Sintomas());
            
            sentencia_sql.executeUpdate();
            
            System.out.println("Historial medico guardado exitosamente");
            
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }   */
    
    public ArrayList<Historial_Medico> listar() {
        ArrayList<Historial_Medico> lista_hm = new ArrayList<>();
        String consulta_sql = "call historial_mostrartodos()";

        try {            
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while(resultado.next()) {
                Historial_Medico hm = new Historial_Medico();

                hm.setId_historial(resultado.getInt("id_historial"));
                hm.setDNI_Paciente(resultado.getInt("DNI_Paciente"));
                hm.setId_medico(resultado.getString("id_medico"));
                hm.setNombreDeLaEnfermedad(resultado.getString("nombreDeLaEnfermedad"));
                hm.setNombreMedicamento(resultado.getString("nombreMedicamento"));
                hm.setFecha_Cita(resultado.getString("fecha_cita"));
                hm.setPeso(resultado.getInt("peso"));
                hm.setAltura(resultado.getInt("altura"));
                hm.setRazon_Cita(resultado.getString("razon_cita"));
                hm.setDiagnostico(resultado.getString("diagnostico"));
                hm.setLista_Sintomas(resultado.getString("lista_sintomas"));

                lista_hm.add(hm);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
        return lista_hm;
    }
    
    
   /* public ArrayList <Historial_Medico> listar(){
        ArrayList <Historial_Medico> lista_hm = new ArrayList<>();
        
        String consulta_sql = "SELECT * FROM historial_medico";
        
        try {            
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            ResultSet resultado = sentencia_sql.executeQuery();
            
            while(resultado.next()){
                Historial_Medico hm = new Historial_Medico();
                
                hm.setId_historial(resultado.getInt("id_historial"));
                hm.setDNI_Paciente(resultado.getInt("DNI_Paciente"));
                hm.setId_medico(resultado.getString("id_medico"));
                hm.setNombreDeLaEnfermedad(resultado.getString("nombreDeLaEnfermedad"));
                hm.setNombreMedicamento(resultado.getString("nombreMedicamento"));
                hm.setFecha_Cita(resultado.getString("fecha_cita"));
                hm.setPeso(resultado.getInt("peso"));
                hm.setAltura(resultado.getInt("altura"));
                hm.setRazon_Cita(resultado.getString("razon_cita"));
                hm.setDiagnostico(resultado.getString("diagnostico"));
                hm.setLista_Sintomas(resultado.getString("lista_sintomas"));
                
                lista_hm.add(hm);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR "+ ex.getMessage());
        }
        return lista_hm;
    }*/
    
    public void actualizar(Historial_Medico hm) {
        String consulta_sql = "call historial_actualizar(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, hm.getId_historial());
            sentencia_sql.setInt(2, hm.getDNI_Paciente());
            sentencia_sql.setString(3, hm.getId_medico());
            sentencia_sql.setString(4, hm.getNombreDeLaEnfermedad());
            sentencia_sql.setString(5, hm.getNombreMedicamento());
            sentencia_sql.setString(6, hm.getFecha_Cita());
            sentencia_sql.setInt(7, hm.getPeso());
            sentencia_sql.setInt(8, hm.getAltura());
            sentencia_sql.setString(9, hm.getRazon_Cita());
            sentencia_sql.setString(10, hm.getDiagnostico());
            sentencia_sql.setString(11, hm.getLista_Sintomas());

            sentencia_sql.executeUpdate();
            System.out.println("Datos actualizados exitosamente");
        } catch(SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }

    /*public void actualizar(Historial_Medico hm){
        String consulta_sql = "UPDATE historial_medico SET DNI_Paciente = ?, id_medico = ?, nombreDeLaEnfermedad = ?, nombreMedicamento = ?, fecha_cita = ?, peso = ?, altura = ?, razon_cita = ?, diagnostico = ?, lista_sintomas = ? WHERE id_historial = ?";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setInt(1,hm.getDNI_Paciente());
            sentencia_sql.setString(2,hm.getId_medico());
            sentencia_sql.setString(3,hm.getNombreDeLaEnfermedad());
            sentencia_sql.setString(4,hm.getNombreMedicamento());
            sentencia_sql.setString(5,hm.getFecha_Cita());
            sentencia_sql.setInt(6,hm.getPeso());
            sentencia_sql.setInt(7,hm.getAltura());
            sentencia_sql.setString(8,hm.getRazon_Cita());
            sentencia_sql.setString(9,hm.getDiagnostico());
            sentencia_sql.setString(10,hm.getLista_Sintomas());
            sentencia_sql.setInt(11, hm.getId_historial()); 
            
            
            sentencia_sql.executeUpdate();
            
            System.out.println("Datos actualizados exitosamente");
        }catch(SQLException ex){
            System.out.println("ERROR "+ ex.getMessage());
        }
    }*/
    
    public void eliminar(int id) {
        String consulta_sql = "call historial_eliminar(?)";
        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro eliminado exitosamente");
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
    
   /* public void eliminar(int id){
        String consulta_sql = "DELETE FROM historial_medico where id_historial = ?";
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro eliminado exitosamente");
        }catch (SQLException ex){
            System.out.println("ERROR: "+ ex.getMessage());
        }
    }*/
    
    public ArrayList<Historial_Medico> buscarPorDNIPaciente(String DNI_Buscado) {
        ArrayList<Historial_Medico> historial = new ArrayList<>();
        String consulta_sql = "call historial_buscarpordni(?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            sentencia_sql.setInt(1, Integer.parseInt(DNI_Buscado));
            ResultSet resultado_sql = sentencia_sql.executeQuery();

            while(resultado_sql.next()) {
                Historial_Medico hist_med = new Historial_Medico();

                hist_med.setId_historial(resultado_sql.getInt("id_historial"));
                hist_med.setDNI_Paciente(resultado_sql.getInt("DNI_Paciente"));
                hist_med.setId_medico(resultado_sql.getString("id_medico"));
                hist_med.setNombreDeLaEnfermedad(resultado_sql.getString("nombreDeLaEnfermedad"));
                hist_med.setNombreMedicamento(resultado_sql.getString("nombreMedicamento"));
                hist_med.setFecha_Cita(resultado_sql.getString("fecha_cita"));
                hist_med.setPeso(resultado_sql.getInt("peso"));
                hist_med.setAltura(resultado_sql.getInt("altura"));
                hist_med.setRazon_Cita(resultado_sql.getString("razon_cita"));
                hist_med.setDiagnostico(resultado_sql.getString("diagnostico"));
                hist_med.setLista_Sintomas(resultado_sql.getString("lista_sintomas"));

                historial.add(hist_med);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR al buscar el historial medico: " + ex.getMessage());
        } catch (NumberFormatException ex) {
            System.out.println("ERROR: El DNI debe ser un valor numérico.");
        }   

        return historial;
    }
    
    
   /* public ArrayList<Historial_Medico> buscarPorDNIPaciente (String DNI_Buscado){
        ArrayList<Historial_Medico> historial = new ArrayList<>();
        String consulta_sql = "Select * from historial_medico where DNI_Paciente = ?";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setString(1,DNI_Buscado );
            ResultSet resultado_sql = sentencia_sql.executeQuery();
            
            while(resultado_sql.next()){
                Historial_Medico Hist_Med = new Historial_Medico();
                
                Hist_Med.setId_historial(resultado_sql.getInt("id_historial"));
                Hist_Med.setDNI_Paciente(resultado_sql.getInt("DNI_Paciente"));
                Hist_Med.setId_medico(resultado_sql.getString("id_medico"));
                Hist_Med.setNombreDeLaEnfermedad(resultado_sql.getString("nombreDeLaEnfermedad"));
                Hist_Med.setNombreMedicamento(resultado_sql.getString("nombreMedicamento"));
                Hist_Med.setFecha_Cita(resultado_sql.getString("fecha_cita"));
                Hist_Med.setPeso(resultado_sql.getInt("peso"));
                
                Hist_Med.setAltura(resultado_sql.getInt("altura"));
                Hist_Med.setRazon_Cita(resultado_sql.getString("razon_cita"));
                Hist_Med.setDiagnostico(resultado_sql.getString("diagnostico"));
                Hist_Med.setLista_Sintomas(resultado_sql.getString("lista_sintomas"));
                
                historial.add(Hist_Med);
                
            }
            
            
        }catch (SQLException ex){
            System.out.println("ERROR al eliminar el historial medico : " + ex.getMessage());
        }  
    
    
        return historial;
    }*/
}
