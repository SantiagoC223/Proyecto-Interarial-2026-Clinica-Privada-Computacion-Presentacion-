
package clinica_privada_poo_2026;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.CallableStatement;

public class SintomaDAO {
   
    public void insertar(Sintoma s) {
        String consulta_sql = "call sintomas_registrar(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setString(1, s.getNombre());
            sentencia_sql.setString(2, s.getDescripcion());
            sentencia_sql.setString(3, s.getDurabilidad());
            sentencia_sql.setString(4, s.getCaracteristicas_Tratamiento());
            sentencia_sql.setString(5, s.getCirujia());
            sentencia_sql.setString(6, s.getTratable());
            sentencia_sql.setString(7, s.getNivel_Severidad());
            sentencia_sql.setInt(8, s.getEscala_Dolor());
            sentencia_sql.setString(9, s.getRequiere_Monitoreo());
            sentencia_sql.setString(10, s.getAltera_Consciencia());
            sentencia_sql.setString(11, s.getRiesgo_Secuela());
            sentencia_sql.setString(12, s.getTipo_Intervencion());

            sentencia_sql.executeUpdate();

            System.out.println("Sintoma guardado exitosamente");

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }

    
    
/*public void insertar(Sintoma s) {
    String consulta_sql = "insert into Sintoma (Nombre, Descripcion, Durabilidad, Caracteristicas_Tratamiento, Cirujia, Tratable, Nivel_Severidad, Escala_Dolor, Requiere_Monitoreo, Altera_Consciencia, Riesgo_Secuela, Tipo_Intervencion) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

        sentencia_sql.setString(1, s.getNombre());
        sentencia_sql.setString(2, s.getDescripcion());
        sentencia_sql.setString(3, s.getDurabilidad());
        sentencia_sql.setString(4, s.getCaracteristicas_Tratamiento());
        sentencia_sql.setString(5, s.getCirujia());
        sentencia_sql.setString(6, s.getTratable());
        sentencia_sql.setString(7, s.getNivel_Severidad());
        sentencia_sql.setInt(8, s.getEscala_Dolor());
        sentencia_sql.setString(9, s.getRequiere_Monitoreo());
        sentencia_sql.setString(10, s.getAltera_Consciencia());
        sentencia_sql.setString(11, s.getRiesgo_Secuela());
        sentencia_sql.setString(12, s.getTipo_Intervencion());

        sentencia_sql.executeUpdate();

        System.out.println("Sintoma guardado exitosamente");

    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}*/

public ArrayList<Sintoma> listar() {
        ArrayList<Sintoma> lista_sintomas = new ArrayList<>();
        String consulta_sql = "call sintomas_mostrartodos()";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Sintoma s = new Sintoma();

                s.setId_sintoma(resultado.getInt("Id_sintoma"));
                s.setNombre(resultado.getString("Nombre"));
                s.setDescripcion(resultado.getString("Descripcion"));
                s.setDurabilidad(resultado.getString("Durabilidad"));
                s.setCaracteristicas_Tratamiento(resultado.getString("Caracteristicas_Tratamiento"));
                s.setCirujia(resultado.getString("Cirujia"));
                s.setTratable(resultado.getString("Tratable"));
                s.setNivel_Severidad(resultado.getString("Nivel_Severidad"));
                s.setEscala_Dolor(resultado.getInt("Escala_Dolor"));
                s.setRequiere_Monitoreo(resultado.getString("Requiere_Monitoreo"));
                s.setAltera_Consciencia(resultado.getString("Altera_Consciencia"));
                s.setRiesgo_Secuela(resultado.getString("Riesgo_Secuela"));
                s.setTipo_Intervencion(resultado.getString("Tipo_Intervencion"));

                lista_sintomas.add(s);
            }

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }

        return lista_sintomas;
    }
    
    
/*public ArrayList<Sintoma> listar() {
    ArrayList<Sintoma> lista_sintomas = new ArrayList<>();

    String consulta_sql = "select * from Sintoma";

    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

        ResultSet resultado = sentencia_sql.executeQuery();

        while (resultado.next()) {
            Sintoma s = new Sintoma();

            s.setId_sintoma(resultado.getInt("Id_sintoma"));
            s.setNombre(resultado.getString("Nombre"));
            s.setDescripcion(resultado.getString("Descripcion"));
            s.setDurabilidad(resultado.getString("Durabilidad"));
            s.setCaracteristicas_Tratamiento(resultado.getString("Caracteristicas_Tratamiento"));
            s.setCirujia(resultado.getString("Cirujia"));
            s.setTratable(resultado.getString("Tratable"));
            s.setNivel_Severidad(resultado.getString("Nivel_Severidad"));
            s.setEscala_Dolor(resultado.getInt("Escala_Dolor"));
            s.setRequiere_Monitoreo(resultado.getString("Requiere_Monitoreo"));
            s.setAltera_Consciencia(resultado.getString("Altera_Consciencia"));
            s.setRiesgo_Secuela(resultado.getString("Riesgo_Secuela"));
            s.setTipo_Intervencion(resultado.getString("Tipo_Intervencion"));

            lista_sintomas.add(s);
        }

    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }

    return lista_sintomas;
}*/

    public void actualizar(Sintoma s) {
        String consulta_sql = "call sintomas_actualizar(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, s.getId_sintoma());
            sentencia_sql.setString(2, s.getNombre());
            sentencia_sql.setString(3, s.getDescripcion());
            sentencia_sql.setString(4, s.getDurabilidad());
            sentencia_sql.setString(5, s.getCaracteristicas_Tratamiento());
            sentencia_sql.setString(6, s.getCirujia());
            sentencia_sql.setString(7, s.getTratable());
            sentencia_sql.setString(8, s.getNivel_Severidad());
            sentencia_sql.setInt(9, s.getEscala_Dolor());
            sentencia_sql.setString(10, s.getRequiere_Monitoreo());
            sentencia_sql.setString(11, s.getAltera_Consciencia());
            sentencia_sql.setString(12, s.getRiesgo_Secuela());
            sentencia_sql.setString(13, s.getTipo_Intervencion());

            sentencia_sql.executeUpdate();

            System.out.println("Datos actualizados exitosamente");

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }


/*public void actualizar(Sintoma s) {
    String consulta_sql = "update Sintoma set Nombre = ?, Descripcion = ?, Durabilidad = ?, Caracteristicas_Tratamiento = ?, Cirujia = ?, Tratable = ?, Nivel_Severidad = ?, Escala_Dolor = ?, Requiere_Monitoreo = ?, Altera_Consciencia = ?, Riesgo_Secuela = ?, Tipo_Intervencion = ? where Id_sintoma = ?";

    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

        sentencia_sql.setString(1, s.getNombre());
        sentencia_sql.setString(2, s.getDescripcion());
        sentencia_sql.setString(3, s.getDurabilidad());
        sentencia_sql.setString(4, s.getCaracteristicas_Tratamiento());
        sentencia_sql.setString(5, s.getCirujia());
        sentencia_sql.setString(6, s.getTratable());
        sentencia_sql.setString(7, s.getNivel_Severidad());
        sentencia_sql.setInt(8, s.getEscala_Dolor());
        sentencia_sql.setString(9, s.getRequiere_Monitoreo());
        sentencia_sql.setString(10, s.getAltera_Consciencia());
        sentencia_sql.setString(11, s.getRiesgo_Secuela());
        sentencia_sql.setString(12, s.getTipo_Intervencion());
        sentencia_sql.setInt(13, s.getId_sintoma());

        sentencia_sql.executeUpdate();

        System.out.println("Datos actualizados exitosamente");

    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}*/

    public void eliminar(int id) {
        String consulta_sql = "call sintomas_eliminar(?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();

            System.out.println("Sintoma eliminado exitosamente");

        } catch (SQLException ex) {
            System.out.println("error: " + ex.getMessage());
        }
    }
    
  /*public void eliminar(int id) {
    String consulta_sql = "delete from Sintoma where Id_sintoma = ?";

    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

        sentencia_sql.setInt(1, id);
        sentencia_sql.executeUpdate();

        System.out.println("Sintoma eliminado exitosamente");

    } catch (SQLException ex) {
        System.out.println("error: " + ex.getMessage());
    }
}^*/
    
    public ArrayList<Sintoma> buscarSintoma(String Nombre) {
        ArrayList<Sintoma> sintomas = new ArrayList<>();
        String consulta_sql = "call sintomas_buscarpornombre(?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            sentencia_sql.setString(1, Nombre);
            ResultSet resultado_sql = sentencia_sql.executeQuery();

            while (resultado_sql.next()) {
                Sintoma sin = new Sintoma();
                sin.setId_sintoma(resultado_sql.getInt("Id_sintoma"));
                sin.setNombre(resultado_sql.getString("Nombre"));
                sin.setDescripcion(resultado_sql.getString("Descripcion"));
                sin.setDurabilidad(resultado_sql.getString("Durabilidad"));
                sin.setCaracteristicas_Tratamiento(resultado_sql.getString("Caracteristicas_Tratamiento"));
                sin.setCirujia(resultado_sql.getString("Cirujia"));
                sin.setTratable(resultado_sql.getString("Tratable"));
                sin.setNivel_Severidad(resultado_sql.getString("Nivel_Severidad"));
                sin.setEscala_Dolor(resultado_sql.getInt("Escala_Dolor"));
                sin.setRequiere_Monitoreo(resultado_sql.getString("Requiere_Monitoreo"));
                sin.setAltera_Consciencia(resultado_sql.getString("Altera_Consciencia"));
                sin.setRiesgo_Secuela(resultado_sql.getString("Riesgo_Secuela"));
                sin.setTipo_Intervencion(resultado_sql.getString("Tipo_Intervencion"));

                sintomas.add(sin);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
        return sintomas;
    }
    
    
    /*public ArrayList<Sintoma> buscarSintoma(String Nombre) {
        ArrayList<Sintoma> sintomas = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Sintoma WHERE Nombre = ?";
        
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setString(1, Nombre);
            ResultSet resultado_sql = sentencia_sql.executeQuery();

            while (resultado_sql.next()) {
                Sintoma sin = new Sintoma();
                sin.setId_sintoma(resultado_sql.getInt("Id_sintoma"));
                sin.setNombre(resultado_sql.getString("Nombre"));
                sin.setDescripcion(resultado_sql.getString("Descripcion"));
                sin.setDurabilidad(resultado_sql.getString("Durabilidad"));
                sin.setCaracteristicas_Tratamiento(resultado_sql.getString("Caracteristicas_Tratamiento"));
                sin.setCirujia(resultado_sql.getString("Cirujia"));
                sin.setTratable(resultado_sql.getString("Tratable"));
                sin.setNivel_Severidad(resultado_sql.getString("Nivel_Severidad"));
                sin.setEscala_Dolor(resultado_sql.getInt("Escala_Dolor"));
                sin.setRequiere_Monitoreo(resultado_sql.getString("Requiere_Monitoreo"));
                sin.setAltera_Consciencia(resultado_sql.getString("Altera_Consciencia"));
                sin.setRiesgo_Secuela(resultado_sql.getString("Riesgo_Secuela"));
                sin.setTipo_Intervencion(resultado_sql.getString("Tipo_Intervencion"));

                sintomas.add(sin);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
        return sintomas;
    }*/
}
