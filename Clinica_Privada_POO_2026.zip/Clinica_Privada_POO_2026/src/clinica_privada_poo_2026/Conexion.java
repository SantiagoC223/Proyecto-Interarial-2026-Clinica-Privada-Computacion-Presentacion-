//Conexion clase
package clinica_privada_poo_2026;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexion {
    private static final String URL = "jdbc:mysql://localhost:3306/clinica_privada";
    private static final String USUARIO = "root";
     private static final String PASSWORD = "";
     
    public static Connection conectar(){
        try{
            Connection conexion = DriverManager.getConnection(URL,USUARIO,PASSWORD);
            return conexion;
        }catch (SQLException ex){
            System.out.println("ERROR : " + ex.getMessage());
            return null;
        }
    
    }
    
}
