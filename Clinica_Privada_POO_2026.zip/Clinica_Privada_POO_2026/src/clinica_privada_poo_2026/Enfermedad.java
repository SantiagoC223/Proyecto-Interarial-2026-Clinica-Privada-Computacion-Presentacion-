//Enfermedad
package clinica_privada_poo_2026;

import javax.swing.JOptionPane;

public class Enfermedad{
    private int idEnfermedad;
    private String nombre;
    private String descripcion;
    private String categoria;
    private String Lista_Sintomas;
    private String Lista_Tratamientos;
    private String observaciones;

    public Enfermedad(String nombre, String descripcion, String categoria, String Lista_Sintomas, String Lista_Tratamientos, String observaciones) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.categoria = categoria;
        this.Lista_Sintomas = Lista_Sintomas;
        this.Lista_Tratamientos = Lista_Tratamientos;
        this.observaciones = observaciones;
    }
    //catch this
    public int getIdEnfermedad() {
        return idEnfermedad;
    }

    public void setIdEnfermedad(int idEnfermedad) {
        this.idEnfermedad = idEnfermedad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getLista_Sintomas() {
        return Lista_Sintomas;
    }

    public void setLista_Sintomas(String Lista_Sintomas) {
        this.Lista_Sintomas = Lista_Sintomas;
    }

    public String getLista_Tratamientos() {
        return Lista_Tratamientos;
    }

    public void setLista_Tratamientos(String Lista_Tratamientos) {
        this.Lista_Tratamientos = Lista_Tratamientos;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    
    public void Mostrar_Enfermedad() {
    JOptionPane.showMessageDialog(null, "------- Enfermedad -------\n" +
                                        "Id : " + idEnfermedad + "\n" +
                                        "Nombre : " + nombre + "\n" +
                                        "Descripcion : " + descripcion + "\n" +
                                        "Categoria : " + categoria + "\n" +
                                        "Observaciones : " + observaciones + "\n" +
                                        "Lista_Sintomas : " + Lista_Sintomas + "\n" +
                                        "Lista_Tratamientos : " + Lista_Tratamientos);

    }                                   
    
}