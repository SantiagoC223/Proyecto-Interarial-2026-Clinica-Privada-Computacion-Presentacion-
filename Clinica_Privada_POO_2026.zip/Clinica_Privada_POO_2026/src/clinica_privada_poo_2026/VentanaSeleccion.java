//Ventana seleccion
package clinica_privada_poo_2026;

import java.awt.Color;
import javax.swing.JOptionPane;

public class VentanaSeleccion extends javax.swing.JFrame {

    public VentanaSeleccion() {
        initComponents();
        getContentPane().setBackground(new Color(58, 130, 196));
        repaint();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator3 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        jEditorPane1 = new javax.swing.JEditorPane();
        btnPacientes = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        btnMedicos = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        btnMedicamentos = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        btnSintomas = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        btnHistorialesMedicos = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        btnEnfermedades = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        btnTratamientos = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtTurnos = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        btnEspecialidades = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnInicio1 = new javax.swing.JButton();

        jScrollPane1.setViewportView(jEditorPane1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnPacientes.setBackground(new java.awt.Color(0, 71, 138));
        btnPacientes.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        btnPacientes.setText("Pacientes");
        btnPacientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPacientesActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Book Antiqua", 0, 18)); // NOI18N
        jLabel2.setText("Registro de personas que ingresan a la clínica para recibir atención médica y seguimiento.");

        btnMedicos.setBackground(new java.awt.Color(0, 71, 138));
        btnMedicos.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        btnMedicos.setText("Medicos");
        btnMedicos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMedicosActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Book Antiqua", 0, 18)); // NOI18N
        jLabel4.setText("Personal especializado en salud que trabaja en la clínica brindando consultas y tratamientos.");

        btnMedicamentos.setBackground(new java.awt.Color(0, 71, 138));
        btnMedicamentos.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        btnMedicamentos.setText("Medicamentos");
        btnMedicamentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMedicamentosActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Book Antiqua", 0, 18)); // NOI18N
        jLabel6.setText("Catálogo de fármacos y suplementos disponibles para recetar y administrar a los pacientes.");

        btnSintomas.setBackground(new java.awt.Color(0, 71, 138));
        btnSintomas.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        btnSintomas.setText("Sintomas");
        btnSintomas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSintomasActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Book Antiqua", 0, 18)); // NOI18N
        jLabel8.setText(" Indicadores o molestias físicas y mentales que reportan los pacientes durante su evaluación.");

        btnHistorialesMedicos.setBackground(new java.awt.Color(0, 71, 138));
        btnHistorialesMedicos.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        btnHistorialesMedicos.setText("H. Medicos");
        btnHistorialesMedicos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHistorialesMedicosActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Book Antiqua", 0, 18)); // NOI18N
        jLabel10.setText("Historiales clínicos que recopilan los antecedentes de salud y la evolución de cada paciente.");

        btnEnfermedades.setBackground(new java.awt.Color(0, 71, 138));
        btnEnfermedades.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        btnEnfermedades.setText("Enfermedades");
        btnEnfermedades.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnfermedadesActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Book Antiqua", 0, 18)); // NOI18N
        jLabel12.setText(" Listado de patologías y afecciones diagnosticadas dentro del centro médico.");

        jLabel13.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N

        btnTratamientos.setBackground(new java.awt.Color(0, 71, 138));
        btnTratamientos.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        btnTratamientos.setText("Tratamietos");
        btnTratamientos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTratamientosActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Book Antiqua", 0, 18)); // NOI18N
        jLabel14.setText("Procedimientos y terapias indicadas para curar o aliviar las enfermedades de los pacientes.");

        jLabel15.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N

        txtTurnos.setBackground(new java.awt.Color(0, 71, 138));
        txtTurnos.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        txtTurnos.setText("Turnos");
        txtTurnos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTurnosActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Book Antiqua", 0, 18)); // NOI18N
        jLabel16.setText("Agenda para programar, reservar y controlar las citas médicas de la clínica.");

        jLabel17.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N

        btnEspecialidades.setBackground(new java.awt.Color(0, 71, 138));
        btnEspecialidades.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        btnEspecialidades.setText("Especialidades");
        btnEspecialidades.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEspecialidadesActionPerformed(evt);
            }
        });

        btnSalir.setBackground(new java.awt.Color(0, 71, 138));
        btnSalir.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        btnSalir.setText("SALIR");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Book Antiqua", 0, 18)); // NOI18N
        jLabel18.setText("Listado de especialidades medicas que hay en esta clinica privada.");

        jLabel19.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N

        jPanel1.setBackground(new java.awt.Color(0, 71, 138));

        jLabel1.setFont(new java.awt.Font("Book Antiqua", 0, 36)); // NOI18N
        jLabel1.setText("¿Que le gustaria Gestionar?");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(324, 324, 324)
                .addComponent(jLabel1)
                .addContainerGap(325, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        btnInicio1.setBackground(new java.awt.Color(0, 71, 138));
        btnInicio1.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        btnInicio1.setText("INICIO");
        btnInicio1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicio1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnEspecialidades, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnPacientes, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel2))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnMedicos, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel4))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnMedicamentos, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel6))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSintomas, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel8))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnHistorialesMedicos, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel10))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnEnfermedades)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel12))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnTratamientos, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtTurnos, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 583, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(13, 13, 13))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(335, 335, 335)
                        .addComponent(btnInicio1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(95, 95, 95)
                        .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPacientes)
                    .addComponent(jLabel2))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnMedicos)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnMedicamentos)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSintomas)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnHistorialesMedicos)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEnfermedades)
                    .addComponent(jLabel13)
                    .addComponent(jLabel12))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnTratamientos)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel15)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtTurnos, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel16))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel17)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel19))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEspecialidades, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel18)))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnInicio1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(43, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPacientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPacientesActionPerformed
        GestionPaciente ventanaPaciente = new GestionPaciente();
        ventanaPaciente.setVisible(true);
        ventanaPaciente.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnPacientesActionPerformed

    private void btnMedicosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMedicosActionPerformed
        GestionMedico ventanaMedico = new GestionMedico();
        ventanaMedico.setVisible(true);
        ventanaMedico.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnMedicosActionPerformed

    private void btnMedicamentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMedicamentosActionPerformed
        GestionMedicamento ventanaMedicamento = new GestionMedicamento();
        ventanaMedicamento.setVisible(true);
        ventanaMedicamento.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnMedicamentosActionPerformed

    private void btnSintomasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSintomasActionPerformed
        GestionSintoma ventataSintoma = new GestionSintoma();
        ventataSintoma.setVisible(true);
        ventataSintoma.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnSintomasActionPerformed

    private void btnHistorialesMedicosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHistorialesMedicosActionPerformed
        GestionHistorialMedico ventanaHM = new GestionHistorialMedico();
        ventanaHM.setVisible(true);
        ventanaHM.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnHistorialesMedicosActionPerformed

    private void btnEnfermedadesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnfermedadesActionPerformed
    GestionEnfermedad ventanaEnfermedad = new GestionEnfermedad();
    ventanaEnfermedad.setVisible(true);
    ventanaEnfermedad.setLocationRelativeTo(null);
    this.setVisible(false);
    }//GEN-LAST:event_btnEnfermedadesActionPerformed

    private void btnTratamientosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTratamientosActionPerformed
        GestionTratamiento ventanaTratamiento = new GestionTratamiento();
        ventanaTratamiento.setVisible(true);
        ventanaTratamiento.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnTratamientosActionPerformed

    private void txtTurnosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTurnosActionPerformed
        GestionTurno ventanaTurno = new GestionTurno();
        ventanaTurno.setVisible(true);
        ventanaTurno.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_txtTurnosActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
    int respuesta = JOptionPane.showConfirmDialog(
        this,
        "¿Está seguro de que desea salir del sistema?",
        "Cerrar sistema",
        JOptionPane.YES_NO_OPTION
    );

    if (respuesta == JOptionPane.YES_OPTION) {
        System.exit(0);
    }
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnEspecialidadesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEspecialidadesActionPerformed
        GestionEspecialidades ventanaEspecialidades = new GestionEspecialidades();
        ventanaEspecialidades.setVisible(true);
        ventanaEspecialidades.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnEspecialidadesActionPerformed

    private void btnInicio1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicio1ActionPerformed
        VentanaBienvenida ventanabienvenida = new VentanaBienvenida();
        ventanabienvenida.setVisible(true);
        ventanabienvenida.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnInicio1ActionPerformed

 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEnfermedades;
    private javax.swing.JButton btnEspecialidades;
    private javax.swing.JButton btnHistorialesMedicos;
    private javax.swing.JButton btnInicio1;
    private javax.swing.JButton btnMedicamentos;
    private javax.swing.JButton btnMedicos;
    private javax.swing.JButton btnPacientes;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnSintomas;
    private javax.swing.JButton btnTratamientos;
    private javax.swing.JEditorPane jEditorPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JButton txtTurnos;
    // End of variables declaration//GEN-END:variables
}
