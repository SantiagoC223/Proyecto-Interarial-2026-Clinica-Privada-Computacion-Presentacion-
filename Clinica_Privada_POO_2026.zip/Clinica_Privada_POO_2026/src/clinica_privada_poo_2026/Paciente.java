//Paciente
package clinica_privada_poo_2026;

import javax.swing.JOptionPane;

public class Paciente extends Persona {
    private int id_paciente ; 
    private String Seguro_Medico ;
    private String Numero_Afiliado  ;
    private String Grupo_Sanguineo  ;
    private String Lista_Historial ;
    
    
    public Paciente(String Seguro_Medico, String Numero_Afiliado, String Grupo_Sanguineo, String Lista_Historial, String Nombre, String Apellido, int DNI, String Email, String Fecha_Nacimiento, String Direccion, String Genero) {
        super(Nombre, Apellido, DNI, Email, Fecha_Nacimiento, Direccion, Genero);
        this.Seguro_Medico = Seguro_Medico;
        this.Numero_Afiliado = Numero_Afiliado;
        this.Grupo_Sanguineo = Grupo_Sanguineo;
        this.Lista_Historial = Lista_Historial;
    }
    

    public int getId_paciente() {
        return id_paciente;
    }

    public void setId_paciente(int id_paciente) {
        this.id_paciente = id_paciente;
    }

    
    public String getSeguro_Medico() {
        return Seguro_Medico;
    }

    public void setSeguro_Medico(String Seguro_Medico) {
        this.Seguro_Medico = Seguro_Medico;
    }

    public String getNumero_Afiliado() {
        return Numero_Afiliado;
    }

    public void setNumero_Afiliado(String Numero_Afiliado) {
        this.Numero_Afiliado = Numero_Afiliado;
    }

    public String getGrupo_Sanguineo() {
        return Grupo_Sanguineo;
    }

    public void setGrupo_Sanguineo(String Grupo_Sanguineo) {
        this.Grupo_Sanguineo = Grupo_Sanguineo;
    }

    public String getLista_Historial() {
        return Lista_Historial;
    }

    public void setLista_Historial(String Lista_Historial) {
        this.Lista_Historial = Lista_Historial;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getFecha_Nacimiento() {
        return Fecha_Nacimiento;
    }

    public void setFecha_Nacimiento(String Fecha_Nacimiento) {
        this.Fecha_Nacimiento = Fecha_Nacimiento;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getGenero() {
        return Genero;
    }

    public void setGenero(String Genero) {
        this.Genero = Genero;
    }

    
    
    @Override
    public void Mostrar_Persona(){
        JOptionPane.showMessageDialog(null, "------- Paciente -------\n" +
                                            "Nombre : " + Nombre + "\n" +
                                            "Apellido : " + Apellido + "\n" +
                                            "DNI : " + DNI + "\n" +
                                            "Email : " + Email + "\n" + 
                                            "Fecha_Nacimiento : " + Fecha_Nacimiento + "\n" + 
                                            "Direccion : " + Direccion + "\n" + 
                                            "Genero : " + Genero + "\n" + 
                                            "Seguro Medico : " + Seguro_Medico + "\n" + 
                                            "Numero Afiliado : " + Numero_Afiliado + "\n" + 
                                            "Grupo Sanguineo : " + Grupo_Sanguineo + "\n" + 
                                            " Lista Historial : " + Lista_Historial );
    
    
    
    
    }
    
} 