//Efermedadda
package clinica_privada_poo_2026;

import java.sql.CallableStatement;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EnfermedadDAO {
    
    public void insertarEnfermedad(Enfermedad enfermedad) {
        String consulta_sql = "call Enfermedades_Registrar(?, ?, ?, ?, ?, ?)";
        
        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            
            sentencia_sql.setString(1, enfermedad.getNombre());
            sentencia_sql.setString(2, enfermedad.getDescripcion());
            sentencia_sql.setString(3, enfermedad.getCategoria());  
            sentencia_sql.setString(4, enfermedad.getLista_Sintomas());
            sentencia_sql.setString(5, enfermedad.getLista_Tratamientos());
            sentencia_sql.setString(6, enfermedad.getObservaciones());
            
            sentencia_sql.executeUpdate();
            System.out.println("Enfermedad Guardada Exitosamente !");
            
        } catch (SQLException ex) {
            System.out.println("Error Al Insertar La Enfermedad : " + ex.getMessage());
        }
    }
/*    public void insertarEnfermedad(Enfermedad enfermedad){
        String consulta_sql = "INSERT INTO enfermedades (nombre, descripcion, categoria, Lista_Sintomas, Lista_Tratamientos, observaciones) VALUES (?,?,?,?,?,?)";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setString(1, enfermedad.getNombre());
            sentencia_sql.setString(2, enfermedad.getDescripcion());
            sentencia_sql.setString(3, enfermedad.getCategoria());  
            sentencia_sql.setString(4, enfermedad.getLista_Sintomas());
            sentencia_sql.setString(5, enfermedad.getLista_Tratamientos());
            sentencia_sql.setString(6, enfermedad.getObservaciones());
            
                    
            sentencia_sql.executeUpdate();
            
            System.out.println("Enfermedad Guardado Exitosamente !");
            
        } catch (SQLException ex) {
            System.out.println("Error Al Insertar La Enfermedad : " + ex.getMessage());
        }

    }*/
    
    public ArrayList<Enfermedad> listarEnfermedad() {
        ArrayList<Enfermedad> ListaEnfermedades = new ArrayList<>();
        String consulta_sql = "call Enfermedades_MostrarTodas()";
        
        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            
            ResultSet resultado = sentencia_sql.executeQuery();
            
            while (resultado.next()) {
                Enfermedad enfermedad = new Enfermedad("2","3","4","5","6","7");
                
                enfermedad.setIdEnfermedad(resultado.getInt("id_enfermedad"));
                enfermedad.setNombre(resultado.getString("nombre"));
                enfermedad.setDescripcion(resultado.getString("descripcion"));
                enfermedad.setCategoria(resultado.getString("categoria"));
                enfermedad.setLista_Sintomas(resultado.getString("Lista_Sintomas"));
                enfermedad.setLista_Tratamientos(resultado.getString("Lista_Tratamientos"));
                enfermedad.setObservaciones(resultado.getString("observaciones"));
                
                ListaEnfermedades.add(enfermedad);
            }
        } catch (SQLException ex) {
            System.out.println("Error : " + ex.getMessage());
        }
        return ListaEnfermedades;
    }
    
   /* public ArrayList<Enfermedad> listarEnfermedad(){
        ArrayList<Enfermedad> ListaEnfermedades = new ArrayList<>();
        
        String consulta_sql = "select * from enfermedades";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            ResultSet resultado = sentencia_sql.executeQuery();
            
            while (resultado.next()){
                Enfermedad enfermedad = new Enfermedad("2","3","4","5","6","7");
                
                enfermedad.setIdEnfermedad(resultado.getInt("id_enfermedad"));
                enfermedad.setNombre(resultado.getString("nombre"));
                enfermedad.setDescripcion(resultado.getString("descripcion"));
                enfermedad.setCategoria(resultado.getString("categoria"));
                
                enfermedad.setLista_Sintomas(resultado.getString("Lista_Sintomas"));
                enfermedad.setLista_Tratamientos(resultado.getString("Lista_Tratamientos"));
                enfermedad.setObservaciones(resultado.getString("observaciones"));
                
                
                ListaEnfermedades.add(enfermedad);
                System.out.println("------------------------------");
            
            }
        
        
        } catch (SQLException ex) {
            System.out.println("Error : " + ex.getMessage());
        }
        return ListaEnfermedades;
    }*/
    
    
    public void actualizarEnfermedad(Enfermedad enfermedad) {
        String consulta_sql = "call Enfermedades_Actualizar(?, ?, ?, ?, ?, ?, ?)";
       
        try {    
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            
            sentencia_sql.setInt(1, enfermedad.getIdEnfermedad());
            sentencia_sql.setString(2, enfermedad.getNombre());
            sentencia_sql.setString(3, enfermedad.getDescripcion());
            sentencia_sql.setString(4, enfermedad.getCategoria());  
            sentencia_sql.setString(5, enfermedad.getLista_Sintomas());
            sentencia_sql.setString(6, enfermedad.getLista_Tratamientos());
            sentencia_sql.setString(7, enfermedad.getObservaciones());
            
            sentencia_sql.executeUpdate();
            System.out.println("Datos Actualizados Exitosamente.");
        } catch (SQLException ex) {
            System.out.println("ERROR al actualizar La Enfermedad : " + ex.getMessage());
        }
    }
    
    /*public void actualizarEnfermedad(Enfermedad enfermedad){
        String consulta_sql = "Update enfermedades set nombre = ?, descripcion = ?, categoria = ?, Lista_Sintomas = ?, Lista_Tratamientos = ?, observaciones = ? where id_enfermedad = ? ";
     
        try {   
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setString(1, enfermedad.getNombre());
            sentencia_sql.setString(2, enfermedad.getDescripcion());
            sentencia_sql.setString(3, enfermedad.getCategoria());  
            sentencia_sql.setString(4, enfermedad.getLista_Sintomas());
            sentencia_sql.setString(5, enfermedad.getLista_Tratamientos());
            sentencia_sql.setString(6, enfermedad.getObservaciones());
            
            sentencia_sql.setInt(7, enfermedad.getIdEnfermedad());
            
            sentencia_sql.executeUpdate();
            
            System.out.println("Datos Actualizados Exitosamente.");
        }catch (SQLException ex){
            System.out.println("ERROR al actualizar La Enfermedad : " + ex.getMessage());
        }
    }*/
    
    public void eliminarEnfermedad(int idEnfermedad) {
        String consulta_sql = "call Enfermedades_Eliminar(?)";
        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            
            sentencia_sql.setInt(1, idEnfermedad);
            sentencia_sql.executeUpdate();
            System.out.println("Registro Eliminado Correctamente");
            
        } catch (SQLException ex) {
            System.out.println("ERROR al eliminar la enfermedad : " + ex.getMessage());
        }   
    }
    
   /* public void eliminarEnfermedad(int idEnfermedad){
        String consulta_sql = "DELETE FROM enfermedades  Where id_enfermedad = ?";
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setInt(1,idEnfermedad);
            sentencia_sql.executeUpdate();
            System.out.println("Registro Eliminado Correctamente");
            
        }catch (SQLException ex){
            System.out.println("ERROR al eliminar la enfermedad : " + ex.getMessage());
        }  
    }*/
    
    public ArrayList<Enfermedad> buscarEnfermedadPorNombre(String nombreEnfermedad) {
            ArrayList<Enfermedad> listaEnfermedades = new ArrayList<>();
            String consulta_sql = "call Enfermedades_BuscarPorNombre(?)";

            try {
                Connection conexion = Conexion.conectar();
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

                sentencia_sql.setString(1, nombreEnfermedad);
                ResultSet resultado_sql = sentencia_sql.executeQuery();

                while(resultado_sql.next()) {
                    Enfermedad enfermedad = new Enfermedad("2","3","4","5","6","7");

                    enfermedad.setIdEnfermedad(resultado_sql.getInt("id_enfermedad"));
                    enfermedad.setNombre(resultado_sql.getString("nombre"));
                    enfermedad.setDescripcion(resultado_sql.getString("descripcion"));
                    enfermedad.setCategoria(resultado_sql.getString("categoria"));
                    enfermedad.setLista_Sintomas(resultado_sql.getString("Lista_Sintomas"));
                    enfermedad.setLista_Tratamientos(resultado_sql.getString("Lista_Tratamientos"));
                    enfermedad.setObservaciones(resultado_sql.getString("observaciones"));

                    listaEnfermedades.add(enfermedad);
                }
            } catch (SQLException ex) {
                System.out.println("ERROR al Buscar la enfermedad : " + ex.getMessage());
            }   

            return listaEnfermedades;
        }
    
    /*public ArrayList<Enfermedad> buscarEnfermedadPorNombre (String nombreEnfermedad){
        ArrayList<Enfermedad> listaEnfermedades = new ArrayList<>();
        String consulta_sql = "Select * from enfermedades where nombre = ?";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setString(1,nombreEnfermedad );
            ResultSet resultado_sql = sentencia_sql.executeQuery();
            
            while(resultado_sql.next()){
                Enfermedad enfermedad = new Enfermedad("2","3","4","5","6","7");
                
                enfermedad.setIdEnfermedad(resultado_sql.getInt("id_enfermedad"));
                enfermedad.setNombre(resultado_sql.getString("nombre"));
                enfermedad.setDescripcion(resultado_sql.getString("descripcion"));
                enfermedad.setCategoria(resultado_sql.getString("categoria"));
                
                enfermedad.setLista_Sintomas(resultado_sql.getString("Lista_Sintomas"));
                enfermedad.setLista_Tratamientos(resultado_sql.getString("Lista_Tratamientos"));
                enfermedad.setObservaciones(resultado_sql.getString("observaciones"));
                
                listaEnfermedades.add(enfermedad);
                
            }
            
            
        }catch (SQLException ex){
            System.out.println("ERROR al Buscar la enfermedad : " + ex.getMessage());
        }  
    
    
        return listaEnfermedades;
    }*/
    
    

    
    
}