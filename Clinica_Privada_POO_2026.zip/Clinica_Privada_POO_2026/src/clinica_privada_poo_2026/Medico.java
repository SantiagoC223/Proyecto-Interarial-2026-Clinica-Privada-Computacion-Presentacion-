//Medico
package clinica_privada_poo_2026;

import javax.swing.JOptionPane;

public class Medico extends Persona{
    private int id_medico ;
    private String Especialidad  ;
    private String Numero_Matricula  ;
    private int Años_Experiencia ;

    public Medico(String Especialidad, String Numero_Matricula, int Años_Experiencia, String Nombre, String Apellido, int DNI, String Email, String Fecha_Nacimiento, String Direccion, String Genero) {
        super(Nombre, Apellido, DNI, Email, Fecha_Nacimiento, Direccion, Genero);
        this.Especialidad = Especialidad;
        this.Numero_Matricula = Numero_Matricula;
        this.Años_Experiencia = Años_Experiencia;
    }

    public Medico() {
        
    }

    
    
    public int getId_medico() {
        return id_medico;
    }

    public void setId_medico(int id_medico) {
        this.id_medico = id_medico;
    }
    
    
    
    public String getEspecialidad() {
        return Especialidad;
    }

    public void setEspecialidad(String Especialidad) {
        this.Especialidad = Especialidad;
    }

    public String getNumero_Matricula() {
        return Numero_Matricula;
    }

    public void setNumero_Matricula(String Numero_Matricula) {
        this.Numero_Matricula = Numero_Matricula;
    }

    public int getAños_Experiencia() {
        return Años_Experiencia;
    }

    public void setAños_Experiencia(int Años_Experiencia) {
        this.Años_Experiencia = Años_Experiencia;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getFecha_Nacimiento() {
        return Fecha_Nacimiento;
    }

    public void setFecha_Nacimiento(String Fecha_Nacimiento) {
        this.Fecha_Nacimiento = Fecha_Nacimiento;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getGenero() {
        return Genero;
    }

    public void setGenero(String Genero) {
        this.Genero = Genero;
    }

    
    
    @Override
    public void Mostrar_Persona(){
        JOptionPane.showMessageDialog(null, "------- Medico -------\n" +
                                            "Nombre : " + Nombre + "\n" +
                                            "Apellido : " + Apellido + "\n" +
                                            "DNI : " + DNI + "\n" +
                                            "Email : " + Email + "\n" + 
                                            "Fecha_Nacimiento : " + Fecha_Nacimiento + "\n" + 
                                            "Direccion : " + Direccion + "\n" + 
                                            "Genero : " + Genero + "\n" + 
                                            "Numero Matricula : " + Numero_Matricula + "\n" + 
                                            "Especialidad : " + Especialidad + "\n" + 
                                            "Años de Experiencia : " + Años_Experiencia );
    
    
    
    
    }
    
}