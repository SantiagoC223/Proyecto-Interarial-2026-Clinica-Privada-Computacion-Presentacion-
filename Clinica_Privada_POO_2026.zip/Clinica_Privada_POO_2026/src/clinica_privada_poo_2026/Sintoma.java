//Sintoma
package clinica_privada_poo_2026;

import javax.swing.JOptionPane;

public class Sintoma {
    private int Id_sintoma;
    private String Nombre;
    private String Descripcion;
    private String Durabilidad;
    private String Caracteristicas_Tratamiento;
    private String Cirujia;
    private String Tratable;
    private String Nivel_Severidad;
    private int Escala_Dolor;
    private String Requiere_Monitoreo;
    private String Altera_Consciencia;
    private String Riesgo_Secuela;
    private String Tipo_Intervencion;

    public Sintoma() {
    }
    
    public Sintoma(String Nombre, String Descripcion, String Durabilidad, String Caracteristicas_Tratamiento, String Cirujia, String Tratable, String Nivel_Severidad, int Escala_Dolor, String Requiere_Monitoreo, String Altera_Consciencia, String Riesgo_Secuela, String Tipo_Intervencion) {
        
        this.Nombre = Nombre;
        this.Descripcion = Descripcion;
        this.Durabilidad = Durabilidad;
        this.Caracteristicas_Tratamiento = Caracteristicas_Tratamiento;
        this.Cirujia = Cirujia;
        this.Tratable = Tratable;
        this.Nivel_Severidad = Nivel_Severidad;
        this.Escala_Dolor = Escala_Dolor;
        this.Requiere_Monitoreo = Requiere_Monitoreo;
        this.Altera_Consciencia = Altera_Consciencia;
        this.Riesgo_Secuela = Riesgo_Secuela;
        this.Tipo_Intervencion = Tipo_Intervencion;
    }

    public int getId_sintoma() {
        return Id_sintoma;
    }

    public void setId_sintoma(int Id_sintoma) {
        this.Id_sintoma = Id_sintoma;
    }
    
    

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public String getDurabilidad() {
        return Durabilidad;
    }

    public void setDurabilidad(String Durabilidad) {
        this.Durabilidad = Durabilidad;
    }

    public String getCaracteristicas_Tratamiento() {
        return Caracteristicas_Tratamiento;
    }

    public void setCaracteristicas_Tratamiento(String Caracteristicas_Tratamiento) {
        this.Caracteristicas_Tratamiento = Caracteristicas_Tratamiento;
    }

    public String getCirujia() {
        return Cirujia;
    }

    public void setCirujia(String Cirujia) {
        this.Cirujia = Cirujia;
    }

    public String getTratable() {
        return Tratable;
    }

    public void setTratable(String Tratable) {
        this.Tratable = Tratable;
    }

    public String getRequiere_Monitoreo() {
        return Requiere_Monitoreo;
    }

    public void setRequiere_Monitoreo(String Requiere_Monitoreo) {
        this.Requiere_Monitoreo = Requiere_Monitoreo;
    }

    public String getAltera_Consciencia() {
        return Altera_Consciencia;
    }

    public void setAltera_Consciencia(String Altera_Consciencia) {
        this.Altera_Consciencia = Altera_Consciencia;
    }

    public String getRiesgo_Secuela() {
        return Riesgo_Secuela;
    }

    public void setRiesgo_Secuela(String Riesgo_Secuela) {
        this.Riesgo_Secuela = Riesgo_Secuela;
    }

    
    public String getNivel_Severidad() {
        return Nivel_Severidad;
    }

    public void setNivel_Severidad(String Nivel_Severidad) {
        this.Nivel_Severidad = Nivel_Severidad;
    }

    public int getEscala_Dolor() {
        return Escala_Dolor;
    }

    public void setEscala_Dolor(int Escala_Dolor) {
        this.Escala_Dolor = Escala_Dolor;
    }




    public String getTipo_Intervencion() {
        return Tipo_Intervencion;
    }

    public void setTipo_Intervencion(String Tipo_Intervencion) {
        this.Tipo_Intervencion = Tipo_Intervencion;
    }

    public void Mostrar_Sintoma() {
        JOptionPane.showMessageDialog(null, "------- Síntoma -------\n" +
                                        "Nombre : " + Nombre + "\n" +
                                        "Descripción : " + Descripcion + "\n" +
                                        "Durabilidad : " + Durabilidad + "\n" +
                                        "Características Tratamiento : " + Caracteristicas_Tratamiento + "\n" +
                                        "Cirugía : " + Cirujia + "\n" +
                                        "Tratable : " + Tratable + "\n" +
                                        "Nivel Severidad : " + Nivel_Severidad + "\n" +
                                        "Escala Dolor : " + Escala_Dolor + "\n" +
                                        "Requiere Monitoreo : " + Requiere_Monitoreo + "\n" +
                                        "Altera Consciencia : " + Altera_Consciencia + "\n" +
                                        "Riesgo Secuela : " + Riesgo_Secuela + "\n" +
                                        "Tipo Intervención : " + Tipo_Intervencion);
    }
}
