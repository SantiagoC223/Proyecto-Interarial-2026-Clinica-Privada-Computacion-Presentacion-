//Medicamento
package clinica_privada_poo_2026;

import javax.swing.JOptionPane;

public class Medicamento {
    private int id_medicamento;
    protected String Nombre;
    protected String Grupo_Anatomico;
    protected String Tipo ;
    protected String Condicion_Venta;
    private String Forma_Farmaceutica;
    private String Categoria_Subtipo;
    private String Via_Administracion;
    private String Dosis_Unidad;
    private int Dosis_Cantidad;

    public Medicamento(String Nombre, String Grupo_Anatomico, String Tipo, String Condicion_Venta, String Forma_Farmaceutica, String Categoria_Subtipo, String Via_Administracion, String Dosis_Unidad, int Dosis_Cantidad) {
        this.Nombre = Nombre;
        this.Grupo_Anatomico = Grupo_Anatomico;
        this.Tipo = Tipo;
        this.Condicion_Venta = Condicion_Venta;
        this.Forma_Farmaceutica = Forma_Farmaceutica;
        this.Categoria_Subtipo = Categoria_Subtipo;
        this.Via_Administracion = Via_Administracion;
        this.Dosis_Unidad = Dosis_Unidad;
        this.Dosis_Cantidad = Dosis_Cantidad;
    }

    Medicamento() {
       
    }

    public int getId_medicamento() {
        return id_medicamento;
    }

    public void setId_medicamento(int id_medicamento) {
        this.id_medicamento = id_medicamento;
    }
    
    
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getGrupo_Anatomico() {
        return Grupo_Anatomico;
    }

    public void setGrupo_Anatomico(String Grupo_Anatomico) {
        this.Grupo_Anatomico = Grupo_Anatomico;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public String getCondicion_Venta() {
        return Condicion_Venta;
    }

    public void setCondicion_Venta(String Condicion_Venta) {
        this.Condicion_Venta = Condicion_Venta;
    }

    public String getForma_Farmaceutica() {
        return Forma_Farmaceutica;
    }

    public void setForma_Farmaceutica(String Forma_Farmaceutica) {
        this.Forma_Farmaceutica = Forma_Farmaceutica;
    }

    public String getCategoria_Subtipo() {
        return Categoria_Subtipo;
    }

    public void setCategoria_Subtipo(String Categoria_Subtipo) {
        this.Categoria_Subtipo = Categoria_Subtipo;
    }

    public String getVia_Administracion() {
        return Via_Administracion;
    }

    public void setVia_Administracion(String Via_Administracion) {
        this.Via_Administracion = Via_Administracion;
    }

    public String getDosis_Unidad() {
        return Dosis_Unidad;
    }

    public void setDosis_Unidad(String Dosis_Unidad) {
        this.Dosis_Unidad = Dosis_Unidad;
    }

    public int getDosis_Cantidad() {
        return Dosis_Cantidad;
    }

    public void setDosis_Cantidad(int Dosis_Cantidad) {
        this.Dosis_Cantidad = Dosis_Cantidad;
    }
    
    public void Mostrar_Medicamento() {
        JOptionPane.showMessageDialog(null, "------- Medicamento -------\n" +
                                            "Nombre : " + Nombre + "\n" +
                                            "Grupo Anatómico : " + Grupo_Anatomico + "\n" +
                                            "Tipo : " + Tipo + "\n" +
                                            "Condición de Venta : " + Condicion_Venta + "\n" +
                                            "Forma Farmacéutica : " + Forma_Farmaceutica + "\n" +
                                            "Categoría/Subtipo : " + Categoria_Subtipo + "\n" +
                                            "Vía de Administración : " + Via_Administracion + "\n" +
                                            "Dosis Unidad : " + Dosis_Unidad + "\n" +
                                            "Dosis Cantidad : " + Dosis_Cantidad);
    }
    
    
}