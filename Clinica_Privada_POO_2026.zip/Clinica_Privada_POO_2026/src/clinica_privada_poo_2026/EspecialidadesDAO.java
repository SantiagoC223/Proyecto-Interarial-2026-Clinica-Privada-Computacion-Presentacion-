
package clinica_privada_poo_2026;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.CallableStatement;

public class EspecialidadesDAO {
    
   public void insertar(Especialidades e) {
        String consulta_sql = "call especialidades_registrar(?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setString(1, e.getNombre());
            sentencia_sql.setString(2, e.getDescripcion());

            sentencia_sql.executeUpdate();
            System.out.println("Especialidad guardada exitosamente");

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
   
   public ArrayList<Especialidades> listar() {
            ArrayList<Especialidades> lista_e = new ArrayList<>();
            String consulta_sql = "call especialidades_mostrartodos()";

            try {
                Connection conexion = Conexion.conectar();
                CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

                ResultSet resultado = sentencia_sql.executeQuery();

                while(resultado.next()) {
                    Especialidades e = new Especialidades();

                    e.setId_especialidad(resultado.getInt("id_especialidad"));
                    e.setNombre(resultado.getString("nombre"));
                    e.setDescripcion(resultado.getString("descripcion"));

                    lista_e.add(e);
                }
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex.getMessage());
            }
            return lista_e;
        }

   public void actualizar(Especialidades e) {
        String consulta_sql = "call especialidades_actualizar(?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, e.getId_especialidad());
            sentencia_sql.setString(2, e.getNombre());
            sentencia_sql.setString(3, e.getDescripcion());

            sentencia_sql.executeUpdate();
            System.out.println("Datos actualizados exitosamente");
        } catch(SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
   
   public void eliminar(int id) {
        String consulta_sql = "call especialidades_eliminar(?)";
        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro eliminado exitosamente");
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
   
   public ArrayList<Especialidades> buscarPorNombre(String nombre_buscado) {
        ArrayList<Especialidades> lista_especialidades = new ArrayList<>();
        String consulta_sql = "call especialidades_buscarpornombre(?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            sentencia_sql.setString(1, nombre_buscado);
            ResultSet resultado_sql = sentencia_sql.executeQuery();

            while(resultado_sql.next()) {
                Especialidades esp = new Especialidades();

                esp.setId_especialidad(resultado_sql.getInt("id_especialidad"));
                esp.setNombre(resultado_sql.getString("nombre"));
                esp.setDescripcion(resultado_sql.getString("descripcion"));

                lista_especialidades.add(esp);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR al buscar la especialidad: " + ex.getMessage());
        }

        return lista_especialidades;
    }
   
}

