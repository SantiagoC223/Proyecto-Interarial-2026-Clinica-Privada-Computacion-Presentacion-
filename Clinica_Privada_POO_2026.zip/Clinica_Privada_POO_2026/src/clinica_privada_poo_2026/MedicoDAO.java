package clinica_privada_poo_2026;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.CallableStatement;




public class MedicoDAO {
    
    public void insertar(Medico m) {
        String consulta_sql = "call Medicos_Registrar(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
             CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setString(1, m.getNombre());
            sentencia_sql.setString(2, m.getApellido());
            sentencia_sql.setInt(3, m.getDNI());
            sentencia_sql.setString(4, m.getEmail());
            sentencia_sql.setString(5, m.getFecha_Nacimiento());
            sentencia_sql.setString(6, m.getDireccion());
            sentencia_sql.setString(7, m.getGenero());
            sentencia_sql.setString(8, m.getEspecialidad());
            sentencia_sql.setString(9, m.getNumero_Matricula());
            sentencia_sql.setInt(10, m.getAños_Experiencia());

            sentencia_sql.executeUpdate();

            System.out.println("Médico guardado exitosamente");

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
    
    
    
    
   /* public void insertar(Medico m){
        String consulta_sql = "INSERT INTO Medicos(Nombre, Apellido, DNI, Email, Fecha_Nacimiento, Direccion, Genero, Especialidad, Numero_Matricula, Años_Experiencia) Values(?,?,?,?,?,?,?,?,?,?) ";
        
 
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setString(1,m.getNombre());
            sentencia_sql.setString(2,m.getApellido());
            sentencia_sql.setInt(3,m.getDNI());
            sentencia_sql.setString(4,m.getEmail());
            sentencia_sql.setString(5,m.getFecha_Nacimiento());
            sentencia_sql.setString(6,m.getDireccion());
            sentencia_sql.setString(7,m.getGenero());
            sentencia_sql.setString(8,m.getEspecialidad());
            sentencia_sql.setString(9,m.getNumero_Matricula());
            sentencia_sql.setInt(10,m.getAños_Experiencia());
            
            sentencia_sql.executeUpdate();
            
            System.out.println("Medico guardada exitosamente");
            
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }   
    */
    public ArrayList<Medico> listar() {
        ArrayList<Medico> lista_medicos = new ArrayList<>();

        String consulta_sql = "call Medicos_MostrarTodos()";

        try {            
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while(resultado.next()) {
                Medico m = new Medico();

                m.setId_medico(resultado.getInt("id_medico"));
                m.setNombre(resultado.getString("Nombre"));
                m.setApellido(resultado.getString("Apellido"));
                m.setDNI(resultado.getInt("DNI"));
                m.setEmail(resultado.getString("Email"));
                m.setFecha_Nacimiento(resultado.getString("Fecha_Nacimiento"));
                m.setDireccion(resultado.getString("Direccion"));
                m.setGenero(resultado.getString("Genero"));
                m.setEspecialidad(resultado.getString("Especialidad"));
                m.setNumero_Matricula(resultado.getString("Numero_Matricula"));
                m.setAños_Experiencia(resultado.getInt("Años_Experiencia"));

                lista_medicos.add(m);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }

        return lista_medicos;
    }
    
    
    /*
    public ArrayList <Medico> listar(){
        ArrayList <Medico> lista_medicos = new ArrayList<>();
        
        String consulta_sql = "SELECT * FROM Medicos";
        
        try {            
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            ResultSet resultado = sentencia_sql.executeQuery();
            
            while(resultado.next()){
                Medico m = new Medico();
                
                m.setId_medico(resultado.getInt("id_medico"));
                m.setNombre(resultado.getString("Nombre"));
                m.setApellido(resultado.getString("Apellido"));
                m.setDNI(resultado.getInt("DNI"));
                m.setEmail(resultado.getString("Email"));
                m.setFecha_Nacimiento(resultado.getString("Fecha_Nacimiento"));
                m.setDireccion(resultado.getString("Direccion"));
                m.setGenero(resultado.getString("Genero"));
                m.setEspecialidad(resultado.getString("Especialidad"));
                m.setNumero_Matricula(resultado.getString("Numero_Matricula"));
                m.setAños_Experiencia(resultado.getInt("Años_Experiencia"));
                
                lista_medicos.add(m);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR "+ ex.getMessage());
        }
        return lista_medicos;
    }
    */
    
    public void actualizar(Medico m) {
        String consulta_sql = "call Medicos_ActualizarDatos(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, m.getId_medico());
            sentencia_sql.setString(2, m.getNombre());
            sentencia_sql.setString(3, m.getApellido());
            sentencia_sql.setInt(4, m.getDNI());
            sentencia_sql.setString(5, m.getEmail());
            sentencia_sql.setString(6, m.getFecha_Nacimiento());
            sentencia_sql.setString(7, m.getDireccion());
            sentencia_sql.setString(8, m.getGenero());
            sentencia_sql.setString(9, m.getEspecialidad());
            sentencia_sql.setString(10, m.getNumero_Matricula());
            sentencia_sql.setInt(11, m.getAños_Experiencia());

            sentencia_sql.executeUpdate();

            System.out.println("Datos actualizados exitosamente");

        } catch(SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }
    
    /*
    public void actualizar(Medico m){
        String consulta_sql = "UPDATE Medicos SET Nombre = ?, Apellido = ?, DNI = ?, Email = ?, Fecha_Nacimiento = ?, Direccion = ?, Genero = ?, Especialidad = ?, Numero_Matricula = ?, Años_Experiencia = ? WHERE id_medico = ?";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setString(1,m.getNombre());
            sentencia_sql.setString(2,m.getApellido());
            sentencia_sql.setInt(3,m.getDNI());
            sentencia_sql.setString(4,m.getEmail());
            sentencia_sql.setString(5,m.getFecha_Nacimiento());
            sentencia_sql.setString(6,m.getDireccion());
            sentencia_sql.setString(7,m.getGenero());
            sentencia_sql.setString(8,m.getEspecialidad());
            sentencia_sql.setString(9,m.getNumero_Matricula());
            sentencia_sql.setInt(10,m.getAños_Experiencia());
            sentencia_sql.setInt(11,m.getId_medico());
            
            sentencia_sql.executeUpdate();
            
            System.out.println("Datos actualizados exitosamente");
        }catch(SQLException ex){
            System.out.println("ERROR "+ ex.getMessage());
        }
    }
    */
    
    public void eliminar(int id) {
        String consulta_sql = "call Medicos_Eliminar(?)";

        try {
            Connection conexion = Conexion.conectar();
            // Usamos CallableStatement como indicó el profesor
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();

            System.out.println("Registro eliminado exitosamente");

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
    
    /*
    public void eliminar(int id){
        String consulta_sql = "DELETE FROM Medicos where id_medico = ?";
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro eliminado exitosamente");
        }catch (SQLException ex){
            System.out.println("ERROR: "+ ex.getMessage());
        }
    }
    */
    
    public ArrayList<Medico> buscarPorDni(int dni_buscado) {
        ArrayList<Medico> medicos = new ArrayList<>();
        String consulta_sql = "call Medicos_BuscarPorDni(?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, dni_buscado);
            ResultSet resultado_sql = sentencia_sql.executeQuery();

            while (resultado_sql.next()) {
                int id_medico = resultado_sql.getInt("id_medico");
                String nombre = resultado_sql.getString("Nombre");
                String apellido = resultado_sql.getString("Apellido");
                int dni = resultado_sql.getInt("DNI");
                String email = resultado_sql.getString("Email");
                String fecha_nacimiento = resultado_sql.getString("Fecha_Nacimiento");
                String direccion = resultado_sql.getString("Direccion");
                String genero = resultado_sql.getString("Genero");
                String especialidad = resultado_sql.getString("Especialidad");
                int años_experiencia = resultado_sql.getInt("Años_Experiencia");
                String numero_matricula = resultado_sql.getString("Numero_Matricula");

                Medico medico = new Medico(especialidad, numero_matricula, años_experiencia, nombre, apellido, dni, email, fecha_nacimiento, direccion, genero);

                medico.setId_medico(id_medico);

                medicos.add(medico);
            }

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }

        return medicos;
    }

    
    
   /* public ArrayList<Medico> buscarPorDni(int dni_buscado) {
    ArrayList<Medico> medicos = new ArrayList<>();
    String consulta_sql = "SELECT * FROM Medicos WHERE dni = ?";
    
    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
        sentencia_sql.setInt(1, dni_buscado);
        ResultSet resultado_sql = sentencia_sql.executeQuery();
        
        while (resultado_sql.next()) {
            int id_medico = resultado_sql.getInt("id_medico");
            String nombre = resultado_sql.getString("Nombre");
            String apellido = resultado_sql.getString("Apellido");
            int dni = resultado_sql.getInt("DNI");
            String email = resultado_sql.getString("Email");
            String fecha_nacimiento = resultado_sql.getString("Fecha_Nacimiento");
            String direccion = resultado_sql.getString("Direccion");
            String genero = resultado_sql.getString("Genero");
            String especialidad = resultado_sql.getString("Especialidad");
            int años_experiencia = resultado_sql.getInt("Años_Experiencia");
            String numero_matricula = resultado_sql.getString("Numero_Matricula");
            
            Medico medico = new Medico(especialidad, numero_matricula, años_experiencia, nombre, apellido, dni, email, fecha_nacimiento, direccion, genero);
            
            medico.setId_medico(id_medico);
            
            medicos.add(medico);
        }
        
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
    
    return medicos;
}
    */
    
}