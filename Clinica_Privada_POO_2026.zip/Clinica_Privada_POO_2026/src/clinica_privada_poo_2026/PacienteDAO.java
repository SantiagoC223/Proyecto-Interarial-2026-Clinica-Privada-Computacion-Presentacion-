//Paciente DAO
package clinica_privada_poo_2026;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.CallableStatement;


public class PacienteDAO {
    public void insertarPaciente(Paciente paciente){
        String consulta_sql = "call Pacientes_Registrar(?,?,?,?,?,?,?,?,?,?,?)";
        
        try{
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            
            sentencia_sql.setString(1, paciente.getNombre());
            sentencia_sql.setString(2, paciente.getApellido());
            sentencia_sql.setInt(3, paciente.getDNI());  
            sentencia_sql.setString(4, paciente.getEmail());
            sentencia_sql.setString(5, paciente.getFecha_Nacimiento());
            sentencia_sql.setString(6, paciente.getDireccion());
            sentencia_sql.setString(7, paciente.getGenero());
            sentencia_sql.setString(8, paciente.getSeguro_Medico());        
            sentencia_sql.setString(9, paciente.getNumero_Afiliado());
            sentencia_sql.setString(10, paciente.getGrupo_Sanguineo());   
            sentencia_sql.setString(11, paciente.getLista_Historial());   
                    
            sentencia_sql.executeUpdate();
            
            System.out.println("Paciente Guardado Exitosamente !");
            
        } catch (SQLException ex) {
            System.out.println("Error : " + ex.getMessage());
        }

    }
    
    
    
   /* public void insertarPaciente(Paciente paciente){
        String consulta_sql = "insert into pacientes (Nombre, Apellido, DNI, Email, Fecha_Nacimiento, Direccion, Genero, Seguro_Medico, Numero_Afiliado, Grupo_Sanguineo, Lista_Historial) values (?,?,?,?,?,?,?,?,?,?,?)";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setString(1, paciente.getNombre());
            sentencia_sql.setString(2, paciente.getApellido());
            sentencia_sql.setInt(3, paciente.getDNI());  
            sentencia_sql.setString(4, paciente.getEmail());
            sentencia_sql.setString(5, paciente.getFecha_Nacimiento());
            sentencia_sql.setString(6, paciente.getDireccion());
            sentencia_sql.setString(7, paciente.getGenero());
            sentencia_sql.setString(8, paciente.getSeguro_Medico());        
            sentencia_sql.setString(9, paciente.getNumero_Afiliado());
            sentencia_sql.setString(10, paciente.getGrupo_Sanguineo());   
            sentencia_sql.setString(11, paciente.getLista_Historial());   
                    
            sentencia_sql.executeUpdate();
            
            System.out.println("Paciente Guardado Exitosamente !");
            
        } catch (SQLException ex) {
            System.out.println("Error : " + ex.getMessage());
        }

    }
    */
    
    public ArrayList<Paciente> listarPaciente() {
        ArrayList<Paciente> ListaPacientes = new ArrayList<>();

        String consulta_sql = "call Pacientes_MostrarTodos()";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Paciente paciente = new Paciente("1","2","3","4","5","6",7,"8","9","10","11");

                paciente.setId_paciente(resultado.getInt("id_paciente"));
                paciente.setNombre(resultado.getString("Nombre"));
                paciente.setApellido(resultado.getString("Apellido"));
                paciente.setDNI(resultado.getInt("DNI"));

                paciente.setEmail(resultado.getString("Email"));
                paciente.setFecha_Nacimiento(resultado.getString("Fecha_Nacimiento"));
                paciente.setDireccion(resultado.getString("Direccion"));
                paciente.setGenero(resultado.getString("Genero"));

                paciente.setSeguro_Medico(resultado.getString("Seguro_Medico"));
                paciente.setNumero_Afiliado(resultado.getString("Numero_Afiliado"));
                paciente.setGrupo_Sanguineo(resultado.getString("Grupo_Sanguineo"));
                paciente.setLista_Historial(resultado.getString("Lista_Historial"));

                ListaPacientes.add(paciente);
                System.out.println("------------------------------");
            }

        } catch (SQLException ex) {
            System.out.println("Error : " + ex.getMessage());
        }

        return ListaPacientes;
    }

    
    
    /*
    public ArrayList<Paciente> listarPaciente(){
        ArrayList<Paciente> ListaPacientes = new ArrayList<>();
        
        String consulta_sql = "select * from pacientes";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            ResultSet resultado = sentencia_sql.executeQuery();
            
            while (resultado.next()){
                Paciente paciente = new Paciente("1","2","3","4","5","6",7,"8","9","10","11");
                
                paciente.setId_paciente(resultado.getInt("id_paciente"));
                paciente.setNombre(resultado.getString("Nombre"));
                paciente.setApellido(resultado.getString("Apellido"));
                paciente.setDNI(resultado.getInt("DNI"));
                
                paciente.setEmail(resultado.getString("Email"));
                paciente.setFecha_Nacimiento(resultado.getString("Fecha_Nacimiento"));
                paciente.setDireccion(resultado.getString("Direccion"));
                paciente.setGenero(resultado.getString("Genero"));

                paciente.setSeguro_Medico(resultado.getString("Seguro_Medico"));
                paciente.setNumero_Afiliado(resultado.getString("Numero_Afiliado"));
                paciente.setGrupo_Sanguineo(resultado.getString("Grupo_Sanguineo"));
                paciente.setLista_Historial(resultado.getString("Lista_Historial"));
                
                ListaPacientes.add(paciente);
                System.out.println("------------------------------");
            
            }
        
        
        } catch (SQLException ex) {
            System.out.println("Error : " + ex.getMessage());
        }
        return ListaPacientes;
    }
   */ 
   
    public void actualizarPaciente(Paciente paciente) {
        String consulta_sql = "call Pacientes_ActualizarDatos(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {    
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);


            sentencia_sql.setInt(1, paciente.getId_paciente());
            sentencia_sql.setString(2, paciente.getNombre());
            sentencia_sql.setString(3, paciente.getApellido());
            sentencia_sql.setInt(4, paciente.getDNI());  
            sentencia_sql.setString(5, paciente.getEmail());
            sentencia_sql.setString(6, paciente.getFecha_Nacimiento());
            sentencia_sql.setString(7, paciente.getDireccion());
            sentencia_sql.setString(8, paciente.getGenero());
            sentencia_sql.setString(9, paciente.getSeguro_Medico());        
            sentencia_sql.setString(10, paciente.getNumero_Afiliado());
            sentencia_sql.setString(11, paciente.getGrupo_Sanguineo());   
            sentencia_sql.setString(12, paciente.getLista_Historial());

            sentencia_sql.executeUpdate();

            System.out.println("Datos Actualizados Exitosamente.");
        } catch (SQLException ex) {
            System.out.println("ERROR al actualizar el paciente : " + ex.getMessage());
        }
    }
    
    
    
    /*
    public void actualizarPaciente(Paciente paciente){
        String consulta_sql = "Update pacientes set Nombre = ?, Apellido = ?, DNI = ?, Email = ?, Fecha_Nacimiento = ?, Direccion = ?, Genero = ?, Seguro_Medico = ?,Numero_Afiliado = ?, Grupo_Sanguineo = ?, Lista_Historial = ? where id_paciente = ? ";
     
        try {   
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setString(1, paciente.getNombre());
            sentencia_sql.setString(2, paciente.getApellido());
            sentencia_sql.setInt(3, paciente.getDNI());  
            sentencia_sql.setString(4, paciente.getEmail());
            sentencia_sql.setString(5, paciente.getFecha_Nacimiento());
            sentencia_sql.setString(6, paciente.getDireccion());
            sentencia_sql.setString(7, paciente.getGenero());
            sentencia_sql.setString(8, paciente.getSeguro_Medico());        
            sentencia_sql.setString(9, paciente.getNumero_Afiliado());
            sentencia_sql.setString(10, paciente.getGrupo_Sanguineo());   
            sentencia_sql.setString(11, paciente.getLista_Historial());
            
            sentencia_sql.setInt(12, paciente.getId_paciente());
            
            sentencia_sql.executeUpdate();
            
            System.out.println("Datos Actualizados Exitosamente.");
        }catch (SQLException ex){
            System.out.println("ERROR al actualizar el paciente : " + ex.getMessage());
        }
    }*/
    
    public void eliminarPaciente(int id) {
        String consulta_sql = "call Pacientes_Eliminar(?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();

            System.out.println("Registro Eliminado Correctamente");

        } catch (SQLException ex) {
            System.out.println("ERROR al eliminar el paciente : " + ex.getMessage());
        }
}
   
    
    /*public void eliminarPaciente(int id){
        String consulta_sql = "DELETE FROM pacientes  Where id_paciente = ?";
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setInt(1,id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro Eliminado Correctamente");
            
        }catch (SQLException ex){
            System.out.println("ERROR al eliminar el paciente : " + ex.getMessage());
        }  
    }
    */

    
    public ArrayList<Paciente> buscarPorNumeroAfiliado (String Numero_Buscado){
        ArrayList<Paciente> listaPacientes = new ArrayList<>();
        String consulta_sql = "call Pacientes_BuscarPorNumeroAfiliado(?) ";
        
        try{
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            sentencia_sql.setString(1,Numero_Buscado );
            ResultSet resultado_sql = sentencia_sql.executeQuery();
            
            while(resultado_sql.next()){
                Paciente paciente = new Paciente("1", "2", "3", "4", "5", "6", 7, "8", "9", "10", "11");
                
                paciente.setId_paciente(resultado_sql.getInt("id_paciente"));
                paciente.setNombre(resultado_sql.getString("Nombre"));
                paciente.setApellido(resultado_sql.getString("Apellido"));
                paciente.setDNI(resultado_sql.getInt("DNI"));
                
                paciente.setEmail(resultado_sql.getString("Email"));
                paciente.setFecha_Nacimiento(resultado_sql.getString("Fecha_Nacimiento"));
                paciente.setDireccion(resultado_sql.getString("Direccion"));
                paciente.setGenero(resultado_sql.getString("Genero"));

                paciente.setSeguro_Medico(resultado_sql.getString("Seguro_Medico"));
                paciente.setNumero_Afiliado(resultado_sql.getString("Numero_Afiliado"));
                paciente.setGrupo_Sanguineo(resultado_sql.getString("Grupo_Sanguineo"));
                paciente.setLista_Historial(resultado_sql.getString("Lista_Historial"));
                
                listaPacientes.add(paciente);
                
            }
            
            
        }catch (SQLException ex){
            System.out.println("ERROR al eliminar el paciente : " + ex.getMessage());
        }  
    
    
        return listaPacientes;
    }
    
    
    
    /*public ArrayList<Paciente> buscarPorNumeroAfiliado (String Numero_Buscado){
        ArrayList<Paciente> listaPacientes = new ArrayList<>();
        String consulta_sql = "Select * from pacientes where Numero_Afiliado = ?";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setString(1,Numero_Buscado );
            ResultSet resultado_sql = sentencia_sql.executeQuery();
            
            while(resultado_sql.next()){
                Paciente paciente = new Paciente("1", "2", "3", "4", "5", "6", 7, "8", "9", "10", "11");
                
                paciente.setId_paciente(resultado_sql.getInt("id_paciente"));
                paciente.setNombre(resultado_sql.getString("Nombre"));
                paciente.setApellido(resultado_sql.getString("Apellido"));
                paciente.setDNI(resultado_sql.getInt("DNI"));
                
                paciente.setEmail(resultado_sql.getString("Email"));
                paciente.setFecha_Nacimiento(resultado_sql.getString("Fecha_Nacimiento"));
                paciente.setDireccion(resultado_sql.getString("Direccion"));
                paciente.setGenero(resultado_sql.getString("Genero"));

                paciente.setSeguro_Medico(resultado_sql.getString("Seguro_Medico"));
                paciente.setNumero_Afiliado(resultado_sql.getString("Numero_Afiliado"));
                paciente.setGrupo_Sanguineo(resultado_sql.getString("Grupo_Sanguineo"));
                paciente.setLista_Historial(resultado_sql.getString("Lista_Historial"));
                
                listaPacientes.add(paciente);
                
            }
            
            
        }catch (SQLException ex){
            System.out.println("ERROR al eliminar el paciente : " + ex.getMessage());
        }  
    
    
        return listaPacientes;
    }
    */
    
}
