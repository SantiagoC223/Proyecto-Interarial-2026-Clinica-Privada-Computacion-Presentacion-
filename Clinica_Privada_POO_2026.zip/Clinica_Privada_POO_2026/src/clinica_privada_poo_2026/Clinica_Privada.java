//Clinica Privada
package clinica_privada_poo_2026;
//V14/9/2026 14:23
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Clinica_Privada {
    private String Nombre;
    private ArrayList<Persona> Lista_Personas;
    private ArrayList<Medicamento> Lista_Medicamentos;
    private ArrayList<Sintoma> Lista_Sintomas;
    private ArrayList<Historial_Medico> historial;
    private ArrayList<Enfermedad> Lista_Enfermedad;
    private ArrayList<Tratamiento> Lista_Tratamiento;
    private ArrayList<Turno> Lista_Turno;

    public Clinica_Privada(){}
    
    public Clinica_Privada(String Nombre) {
        this.Nombre = Nombre;
        this.Lista_Personas = new ArrayList<>();
        this.Lista_Medicamentos = new ArrayList<>();
        this.Lista_Sintomas = new ArrayList<>();
        this.Lista_Enfermedad = new ArrayList<>();
        this.Lista_Tratamiento = new ArrayList<>();
        this.Lista_Turno = new ArrayList<>();
        this.historial = new ArrayList<>();
    }

    public ArrayList<Historial_Medico> getHistorial() {
        return historial;
    }

    public void setHistorial(ArrayList<Historial_Medico> historial) {
        this.historial = historial;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public ArrayList<Persona> getLista_Personas() {
        return Lista_Personas;
    }

    public void setLista_Personas(ArrayList<Persona> Lista_Personas) {
        this.Lista_Personas = Lista_Personas;
    }

    public ArrayList<Medicamento> getLista_Medicamentos() {
        return Lista_Medicamentos;
    }

    public void setLista_Medicamentos(ArrayList<Medicamento> Lista_Medicamentos) {
        this.Lista_Medicamentos = Lista_Medicamentos;
    }

    public ArrayList<Sintoma> getLista_Sintomas() {
        return Lista_Sintomas;
    }

    public void setLista_Sintomas(ArrayList<Sintoma> Lista_Sintomas) {
        this.Lista_Sintomas = Lista_Sintomas;
    }

    public ArrayList<Enfermedad> getLista_Enfermedad() {
        return Lista_Enfermedad;
    }

    public void setLista_Enfermedad(ArrayList<Enfermedad> Lista_Enfermedad) {
        this.Lista_Enfermedad = Lista_Enfermedad;
    }

    public ArrayList<Tratamiento> getLista_Tratamiento() {
        return Lista_Tratamiento;
    }

    public void setLista_Tratamiento(ArrayList<Tratamiento> Lista_Tratamiento) {
        this.Lista_Tratamiento = Lista_Tratamiento;
    }

    public ArrayList<Turno> getLista_Turno() {
        return Lista_Turno;
    }

    public void setLista_Turno(ArrayList<Turno> Lista_Turno) {
        this.Lista_Turno = Lista_Turno;
    }


    //++++++++++++++++++++++++{ PERSONA }+++++++++++++++++++++++++++++++++++++++//
    
    
    //Agregar
    public void Agregar_Persona(Persona P) {
        Lista_Personas.add(P);
    }

    //Buscar
    public Persona Buscar_Persona(int DNI){
        for(Persona P: Lista_Personas){
            if(P.getDNI() == DNI){
                return P;
            }
        }
        return null;
    }
    

    

    //Eliminar
    public void Eliminar_Persona(int DNI){
        Persona P_Eliminar = Buscar_Persona(DNI);
        
        if(P_Eliminar != null){
            Lista_Personas.remove(P_Eliminar);
            JOptionPane.showMessageDialog(null, "PerSONa Eliminada.");
        }else{
            JOptionPane.showMessageDialog(null, "PerSONa no encontrada, intentelo de nuevo.");
        }
        
        
    }
    
    //Editar_Persona
    
    public void Editar_Persona(int DNI){
        
        Persona P = Buscar_Persona(DNI);
        
        if(P == null){
            JOptionPane.showMessageDialog(null, "No se encontro una persona con ese DNI");
            return;
        }
            //EDITAR ATRIBUTOS DE PERSONA
            
            String Nuevo_Nombre = JOptionPane.showInputDialog("Ingrese el nuevo nombre : ");
            
            String Nuevo_Apellido = JOptionPane.showInputDialog("Ingrese el nuevo apellido : ");
            
            int Nuevo_DNI = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El DNI : "));
            
            String Nuevo_Email = JOptionPane.showInputDialog("Ingrese el Email : ") ;
            
            String Nuevo_Fecha_Nacimiento = JOptionPane.showInputDialog("Ingrese la Fecha de Nacimiento : ");
            
            String Nuevo_Direccion = JOptionPane.showInputDialog("Ingrese la Direccion : ");
            
            String Nuevo_Genero = JOptionPane.showInputDialog("Ingrese El Genero : ");
            //___//
            P.setNombre(Nuevo_Nombre);
            
            P.setApellido(Nuevo_Apellido);     
            
            P.setDNI(Nuevo_DNI);
            
            P.setEmail(Nuevo_Email);
            
            P.setFecha_Nacimiento(Nuevo_Fecha_Nacimiento);
            
            P.setDireccion(Nuevo_Direccion);
            
            P.setGenero(Nuevo_Genero); 
            
            //EDITAR DATOS SI ES Paciente
            if(P instanceof Paciente){
                
                Paciente paciente = (Paciente)P;

                String Nuevo_Seguro_Medico = JOptionPane.showInputDialog("Ingrese el Seguro Medico : ");
                
                String Nuevo_Numero_Afiliado = JOptionPane.showInputDialog("Ingrese el Numero Afiliado : ");
                
                String  Nuevo_Grupo_Sanguineo  = JOptionPane.showInputDialog("Ingrese el grupo Sanguineo : ");
                
                String  Nueva_Lista_Historiales  = JOptionPane.showInputDialog("Ingrese la lista de hitoriales medicos.  : ");
                
                paciente.setSeguro_Medico( Nuevo_Seguro_Medico);
                
                paciente.setNumero_Afiliado( Nuevo_Numero_Afiliado);
                
                paciente.setGrupo_Sanguineo( Nuevo_Grupo_Sanguineo);
                
                paciente.setLista_Historial(Nueva_Lista_Historiales);   
            }   
            //EDITAR DATOS SI ES MEdico
            if(P instanceof Medico){
                Medico medico = (Medico) P;
                
                String Nueva_Especialidad = JOptionPane.showInputDialog("Ingrese la Especialidad: ");
                
                String Nuevo_Numero_Matricula = JOptionPane.showInputDialog("Ingrese el nuevo Numero de Matricula : ");
                
                int Nuevo_Años_Experiencia = Integer.parseInt(JOptionPane.showInputDialog("Ingrese los Años de Experiencia: "));
                
                medico.setEspecialidad(Nueva_Especialidad);

                medico.setNumero_Matricula(Nuevo_Numero_Matricula);
               
                medico.setAños_Experiencia(Nuevo_Años_Experiencia);
                

            }         
        JOptionPane.showMessageDialog(null, "Persona modificada exitosamente.");
    }


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    
    //++++++++++++++++++++++++{ Sintoma }+++++++++++++++++++++++++++++++++++++++//
    
        //agregar Sintoma
    public void Agregar_Sintoma(Sintoma s) {
        Lista_Sintomas.add(s);
    }
    
    
        //BUSCAR SINTOMA
    public Sintoma Buscar_Sintoma (String Nombre) {
    for (Sintoma s : Lista_Sintomas) {
        if (s.getNombre().equalsIgnoreCase(Nombre)) {
            return s; 
        }
    }
    return null;
}
    
    //ELIMINAR SINTOMA
    
    public void Eliminar_sintoma (String Nombre){
        Sintoma s = Buscar_Sintoma(Nombre);
        if(s != null){
            Lista_Sintomas.remove(s);
            JOptionPane.showMessageDialog(null, "Sintoma Eliminado.");
        }else{
            JOptionPane.showMessageDialog(null, "Sintoma no encontrado, intentelo de nuevo.");
        }
        
    }
    //EDITAR SINTOMA
        
    public void Editar_Sintoma(String nombre) {
        Sintoma s = Buscar_Sintoma(nombre);

    if (s == null) {
        JOptionPane.showMessageDialog(null, "No se encontró ningún síntoma con el nombre: " + nombre);
        return;
    }

    String nuevoNombre = JOptionPane.showInputDialog("Ingrese el nuevo nombre del síntoma:");
    String nuevaDescripcion = JOptionPane.showInputDialog("Descripción o detalle breve:");
    String nuevaDurabilidad = JOptionPane.showInputDialog("Duración o durabilidad estimada:");
    String nuevasCaracTrat = JOptionPane.showInputDialog("Características del tratamiento:");
    String nuevaCirujia = JOptionPane.showInputDialog("Requiere cirugía obligatoria?");
    String nuevoTratable = JOptionPane.showInputDialog("Es tratable actualmente?");
    String nuevoNivelSeveridad = JOptionPane.showInputDialog("Nivel de severidad:");
    int nuevaEscalaDolor = Integer.parseInt(JOptionPane.showInputDialog("Escala de dolor (1-10):"));
    String nuevoMonitoreo = JOptionPane.showInputDialog("¿Requiere monitoreo constante?");
    String nuevaAlteraConsciencia = JOptionPane.showInputDialog("¿Altera la consciencia del paciente?");
    String nuevoRiesgoSecuela = JOptionPane.showInputDialog("¿Deja algún riesgo de secuela?");
    String nuevoTipoIntervencion = JOptionPane.showInputDialog("Tipo de intervención requerida:");

        s.setNombre(nuevoNombre);
        s.setDescripcion(nuevaDescripcion);
        s.setDurabilidad(nuevaDurabilidad);
        s.setCaracteristicas_Tratamiento(nuevasCaracTrat);
        s.setCirujia(nuevaCirujia);
        s.setTratable(nuevoTratable);
        s.setNivel_Severidad(nuevoNivelSeveridad);
        s.setEscala_Dolor(nuevaEscalaDolor);
        s.setRequiere_Monitoreo(nuevoMonitoreo);
        s.setAltera_Consciencia(nuevaAlteraConsciencia);
        s.setRiesgo_Secuela(nuevoRiesgoSecuela);
        s.setTipo_Intervencion(nuevoTipoIntervencion);

    JOptionPane.showMessageDialog(null, "Síntoma actualizado correctamente");
}
    
    
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    
    //++++++++++++++++++++++++{ Medicamento }+++++++++++++++++++++++++++++++++++++++//
        //Agregar Medicamento
    public void AgregarMedicamento (Medicamento m){
        Lista_Medicamentos.add(m);
    }
    
        //Buscar Medicamento
    public Medicamento Buscar_Medicamento (String Nombre) {
        for (Medicamento m : Lista_Medicamentos) {
            if (m.getNombre().equalsIgnoreCase(Nombre)) {
                return m; 
            }
        }
        return null;
    }
    
    public void EliminarMedicamento(String Nombre){
        Medicamento m = Buscar_Medicamento(Nombre);
        if(m != null){
            Lista_Medicamentos.remove(m);
            JOptionPane.showMessageDialog(null, "Medicamento Eliminado.");
        }else{
            JOptionPane.showMessageDialog(null, "Medicamento no encontrado, intentelo de nuevo.");
        }   
    }
    
        //Editar Medicamento
    public void Editar_Medicamento(String Nombre) {
        Medicamento m = Buscar_Medicamento(Nombre);

    if (m == null) {
        JOptionPane.showMessageDialog(null, "No se encontró ningún medicamento con el nombre: " + Nombre);
        return;
    }

    String nuevoNombre = JOptionPane.showInputDialog("Ingrese el nuevo nombre del medicamento:");
    String nuevoGrupo_Anatomico = JOptionPane.showInputDialog("Ingrese el nuevo grupo anatomico del medicamento:");
    String nuevoTipo = JOptionPane.showInputDialog("Ingrese el nuevo tipo del medicamento:");
    String nuevaCondicion_Venta = JOptionPane.showInputDialog("Ingrese la nueva condicion de venta del medicamento:");
    String nuevaForma_Farmaceutica = JOptionPane.showInputDialog("Ingrese la nueva forma Farmaceutica del medicamento:");
    String nuevaCategoria_Subtipo = JOptionPane.showInputDialog("Ingrese la nueva categoria Subtipo del medicamento:");
    String nuevaVia_Administracion = JOptionPane.showInputDialog("Ingrese la nueva via de Administracion del medicamento:");
    String nuevaDosis_Unidad = JOptionPane.showInputDialog("Ingrese la nueva dosis por Unidad del medicamento:");
    int nuevaDosis_Cantidad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la nueva dosis por cantidad del mediamento : "));
    
    m.setNombre(nuevoNombre);
    m.setGrupo_Anatomico(nuevoGrupo_Anatomico);
    m.setTipo(nuevoTipo);
    m.setCondicion_Venta(nuevaCondicion_Venta);
    m.setForma_Farmaceutica(nuevaForma_Farmaceutica);
    m.setCategoria_Subtipo(nuevaCategoria_Subtipo);
    m.setVia_Administracion(nuevaVia_Administracion);
    m.setDosis_Unidad(nuevaDosis_Unidad);
    m.setDosis_Cantidad(nuevaDosis_Cantidad);
    
    JOptionPane.showMessageDialog(null, "Medicamento actualizado correctamente");
    }

     //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    
    //++++++++++++++++++++++++{ HISTORIAL MEDICO }+++++++++++++++++++++++++++++++++++++++//
    
    //AGREGAR HISTORIAL
    
      public void AgregarHistorial(Historial_Medico Hm) {
        historial.add(Hm);
    }

    //BUSCAR HISTORIAL
      
     public Historial_Medico BuscarHistorial (int DNI_Paciente) {
    for (Historial_Medico Hm : historial) {
        if (Hm.getDNI_Paciente() == (DNI_Paciente)) {
            return Hm; 
        }
    }
    return null;
}  
      
    //ELIMINAR HISTORIAL
    
    public void EliminarHistorial (int DNI_Paciente){
        Historial_Medico Hm = BuscarHistorial(DNI_Paciente);
        if(Hm != null){
            historial.remove(Hm);
            JOptionPane.showMessageDialog(null, "Historial Eliminado.");
        }else{
            JOptionPane.showMessageDialog(null, "Historial Medico no encontrado, intentelo de nuevo.");
        }    
    } 
     
    //EDITAR HISTORIAL
    
    public void EditarHistorial(int DNI_Paciente) {
    Historial_Medico Hm = BuscarHistorial(DNI_Paciente);
    
    if (Hm == null) {
        JOptionPane.showMessageDialog(null, "No se encontró ningún Historial Medico con ese DNI.");
        return; 
    }
    
    int nuevo_peso = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El nuevo peso:"));
    int nueva_Altura = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la nueva Altura:"));
    String nueva_Fecha_Cita = JOptionPane.showInputDialog("Ingrese la nueva fecha de la cita:");
    String nuevo_Diagnostico = JOptionPane.showInputDialog("Ingrese el nuevo diagnostico");
    String nueva_Razon_Cita = JOptionPane.showInputDialog("Ingrese la nueva razon de la cita:");
    String nueva_Lista_Sintomas = JOptionPane.showInputDialog("Ingrese la nueva lista de sintomas del paciente:");
    
    
    Hm.setPeso(nuevo_peso);
    Hm.setAltura(nueva_Altura);
    Hm.setFecha_Cita(nueva_Fecha_Cita);
    Hm.setDiagnostico(nuevo_Diagnostico);
    Hm.setRazon_Cita(nueva_Razon_Cita);
    Hm.setLista_Sintomas(nueva_Lista_Sintomas);
}
      
    
     //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    
    //++++++++++++++++++++++++{ Emfermedad }+++++++++++++++++++++++++++++++++++++++//
          //Agregar Enfermedad
    public void AgregarEnfermedad (Enfermedad e){
        Lista_Enfermedad.add(e);
    }
    
    //Buscar
    public Enfermedad Buscar_Enfermedad(String nombre){
        for(Enfermedad e: Lista_Enfermedad){
            if(e.getNombre().equalsIgnoreCase(Nombre)){
                return e;
            }else{
                JOptionPane.showMessageDialog(null , "No hay ninguna Enfermedad asignada a ese Nombre.");
            }
        }
        return null;
    }
    
    //Eliminar
    public void Eliminar_Enfermedad (String nombre){
        Enfermedad e = Buscar_Enfermedad(nombre);
        if(e != null){
            Lista_Enfermedad.remove(e);
            JOptionPane.showMessageDialog(null, "Enfermedad Eliminada.");
        }else{
            JOptionPane.showMessageDialog(null, "Enfermedad no encontrada, intentelo de nuevo.");
        }    
    }
    
    //Editar
    public void editarEnfermedad(String nombre) {
    Enfermedad e = Buscar_Enfermedad(nombre);
    
    if (e == null) {
        JOptionPane.showMessageDialog(null, "No se encontró ninguna Enfermedad  con ese Nombre.");
        return; 
    }
    String nuevo_Nombre = JOptionPane.showInputDialog("Ingrese el nuevo nombre de la enfermead");
    String nueva_Descripcion = JOptionPane.showInputDialog("Ingrese la nueva descripcion de la enfermead");
    String nueva_Categoria = JOptionPane.showInputDialog("Ingrese la nueva categoria de la enfermead");
    String nueva_Lista_Sintomas = JOptionPane.showInputDialog("Ingrese la nueva Lista de Sintomas de la enfermead");
    String nuevo_Lista_Tratamientos = JOptionPane.showInputDialog("Ingrese la nueva Lista de Tratamientos de la enfermead");
    String nueva_Observacion = JOptionPane.showInputDialog("Ingrese la nueva observacion de la enfermead");
    
    e.setNombre(nuevo_Nombre);
    e.setDescripcion(nueva_Descripcion);
    e.setCategoria(nueva_Categoria);
    e.setLista_Sintomas(nueva_Lista_Sintomas);
    e.setLista_Tratamientos(nuevo_Lista_Tratamientos);
    e.setObservaciones(nueva_Observacion);
    
    JOptionPane.showMessageDialog(null, "Enfermedad actualizada correctamente");
    }
     //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    
    //++++++++++++++++++++++++{ Tratamiento }+++++++++++++++++++++++++++++++++++++++//
    
    
    public Tratamiento Buscar_Tratamiento(String Nombre) {
    for (Tratamiento t : Lista_Tratamiento) {
        if (t.getNombre().equalsIgnoreCase(Nombre)) {
            return t; 
        }
    }
    return null;
}

    public void agregarTratamiento(Tratamiento t){
        Lista_Tratamiento.add(t);
    }
    


    public void Eliminar_Tratamiento(String Nombre) {
        Tratamiento t = Buscar_Tratamiento(Nombre);
    if (t != null) {
        Lista_Tratamiento.remove(t);
        JOptionPane.showMessageDialog(null, "Tratamiento con el nombre " + Nombre + " Eliminado con éxito.");
    } else {
        JOptionPane.showMessageDialog(null, "Tratamiento con el nombre " + Nombre + " No encontrado.");
    }  
}
    
    
     //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    
    //++++++++++++++++++++++++{ TURNO }+++++++++++++++++++++++++++++++++++++++//
    
    //agregar TURNO
    public void Agregar_Turno(Turno t) {
        Lista_Turno.add(t);
    }
    
    //editar TURNO

    
public void editarTurno(int IdTurno) {
    Turno tu = buscar_Turno(IdTurno);
    
    if (tu == null) {
        JOptionPane.showMessageDialog(null, "No se encontró ningún Turno con ese id.");
        return; 
    }
    
    String Nuevo_Codigo_Paciente = JOptionPane.showInputDialog("Ingrese el nuevo código del paciente:", tu.getCodigo_Paciente());
    String Nuevo_nombre_completoMedico = JOptionPane.showInputDialog("Ingrese el nuevo código del médico:", tu.getNombre_completoMedico());
    String Nuevo_Fecha_Hora = JOptionPane.showInputDialog("Ingrese la nueva fecha y hora del turno", tu.getFecha_Hora());
    String Nuevo_Especialidad = JOptionPane.showInputDialog("Ingrese la nueva especialidad:", tu.getEspecialidad());
    int Nueva_sala = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la sala de consultorio:", tu.getSala()));
    String Nuevo_Estado = JOptionPane.showInputDialog("Ingrese el estado del turno (Pendiente/Confirmado/Cancelado/Atendido):", tu.getEstado());
    String Nuevo_MotivoConsulta = JOptionPane.showInputDialog("Ingrese el motivo de la consulta:", tu.getMotivoConsulta());
    String Nuevo_TipoTurno = JOptionPane.showInputDialog("Ingrese el tipo de turno :", tu.getTipoTurno());


    tu.setCodigo_Paciente(Nuevo_Codigo_Paciente);
    tu.setNombre_completoMedico(Nuevo_nombre_completoMedico);
    tu.setFecha_Hora(Nuevo_Fecha_Hora);
    tu.setEspecialidad(Nuevo_Especialidad);
    tu.setSala(Nueva_sala);
    
    tu.setEstado(Nuevo_Estado);
    tu.setMotivoConsulta(Nuevo_MotivoConsulta);
    tu.setTipoTurno(Nuevo_TipoTurno);
}

    //ELIMINAR TURNO

    public void Eliminar_Turno(int IdTurno){
       Turno tu = buscar_Turno(IdTurno);
       
       if (tu !=null){
           Lista_Turno.remove(tu);
          JOptionPane.showMessageDialog(null, "Turno" + IdTurno + " Eliminado con exito.");
       }else{
          JOptionPane.showMessageDialog(null, "Turno con el ID " + IdTurno + " no encontrado.");
       }
   
       
    }  

  //BUSCAR TURNO

   public Turno buscar_Turno(int IdTurno){
        for(Turno tu : Lista_Turno){
            if(tu.getIdTurno() == IdTurno){
                tu.mostrarTurno();
                return tu;
            }
        }
   
        return null;
    }

 //MOSTRAR TURNO

    public void mostrarTodosLosTurnos() {
    if (Lista_Turno.isEmpty()) {
        JOptionPane.showMessageDialog(null, "No hay turnos registrados.");
        return;
    }
    for (Turno tu : Lista_Turno) {
        tu.mostrarTurno();
    }
}
    
}