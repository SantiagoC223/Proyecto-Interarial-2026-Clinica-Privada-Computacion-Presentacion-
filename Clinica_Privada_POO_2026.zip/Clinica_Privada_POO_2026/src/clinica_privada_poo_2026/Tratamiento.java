//Tratamiento
package clinica_privada_poo_2026;

public class Tratamiento {
    private int idTratamiento;
    private String nombre;
    private String tipo;
    private String area;
    private String detalles;
    private int diasDuracion;
    private int diasReposo; 
    private int cantidadSesiones;
    private int costo;
    private String requiereInternacion;
    private String estado;
    private String materiales;
    private String medicamentos;
    private String enfermedades;

    public Tratamiento( String nombre, String tipo, String area, String detalles, int diasDuracion, int diasReposo, int cantidadSesiones, int costo, String requiereInternacion, String estado, String materiales, String medicamentos, String enfermedades) {
        this.idTratamiento = idTratamiento;
        this.nombre = nombre;
        this.tipo = tipo;
        this.area = area;
        this.detalles = detalles;
        this.diasDuracion = diasDuracion;
        this.diasReposo = diasReposo;
        this.cantidadSesiones = cantidadSesiones;
        this.costo = costo;
        this.requiereInternacion = requiereInternacion;
        this.estado = estado;
        this.materiales = materiales;
        this.medicamentos = medicamentos;
        this.enfermedades = enfermedades;
    }

    Tratamiento() {
       
    }

    public int getIdTratamiento() {
        return idTratamiento;
    }

    public void setIdTratamiento(int idTratamiento) {
        this.idTratamiento = idTratamiento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDetalles() {
        return detalles;
    }

    public void setDetalles(String detalles) {
        this.detalles = detalles;
    }

    public int getDiasDuracion() {
        return diasDuracion;
    }

    public void setDiasDuracion(int diasDuracion) {
        this.diasDuracion = diasDuracion;
    }

    public int getDiasReposo() {
        return diasReposo;
    }

    public void setDiasReposo(int diasReposo) {
        this.diasReposo = diasReposo;
    }

    public int getCantidadSesiones() {
        return cantidadSesiones;
    }

    public void setCantidadSesiones(int cantidadSesiones) {
        this.cantidadSesiones = cantidadSesiones;
    }

    public int getCosto() {
        return costo;
    }

    public void setCosto(int costo) {
        this.costo = costo;
    }

    public String getRequiereInternacion() {
        return requiereInternacion;
    }

    public void setRequiereInternacion(String requiereInternacion) {
        this.requiereInternacion = requiereInternacion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMateriales() {
        return materiales;
    }

    public void setMateriales(String materiales) {
        this.materiales = materiales;
    }

    public String getMedicamentos() {
        return medicamentos;
    }

    public void setMedicamentos(String medicamentos) {
        this.medicamentos = medicamentos;
    }

    public String getEnfermedades() {
        return enfermedades;
    }

    public void setEnfermedades(String enfermedades) {
        this.enfermedades = enfermedades;
    }

    
    
    
   
}
