//Historial_Medico
package clinica_privada_poo_2026;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Historial_Medico {
    private int id_historial;
    private int DNI_Paciente; 
    private String id_medico;
    private String nombreDeLaEnfermedad;
    private String nombreMedicamento;    
    private String Fecha_Cita;
    private int Peso;
    private int Altura;
    private String Razon_Cita;
    private String Diagnostico;
    private String Lista_Sintomas;

    public  Historial_Medico(){
    }

    public Historial_Medico(int DNI_Paciente, String id_medico, String nombreDeLaEnfermedad, String nombreMedicamento, String Fecha_Cita, int Peso, int Altura, String Razon_Cita, String Diagnostico, String Lista_Sintomas) {
        this.DNI_Paciente = DNI_Paciente;
        this.id_medico = id_medico;
        this.nombreDeLaEnfermedad = nombreDeLaEnfermedad;
        this.nombreMedicamento = nombreMedicamento;
        this.Fecha_Cita = Fecha_Cita;
        this.Peso = Peso;
        this.Altura = Altura;
        this.Razon_Cita = Razon_Cita;
        this.Diagnostico = Diagnostico;
        this.Lista_Sintomas = Lista_Sintomas;
    }

    public String getNombreMedicamento() {
        return nombreMedicamento;
    }

    public void setNombreMedicamento(String nombreMedicamento) {
        this.nombreMedicamento = nombreMedicamento;
    }
    
    public int getId_historial() {
        return id_historial;
    }

    public void setId_historial(int id_historial) {
        this.id_historial = id_historial;
    }

    public int getDNI_Paciente() {
        return DNI_Paciente;
    }

    public void setDNI_Paciente(int DNI_Paciente) {
        this.DNI_Paciente = DNI_Paciente;
    }

    public String getId_medico() {
        return id_medico;
    }

    public void setId_medico(String id_medico) {
        this.id_medico = id_medico;
    }

    public String getNombreDeLaEnfermedad() {
        return nombreDeLaEnfermedad;
    }

    public void setNombreDeLaEnfermedad(String nombreDeLaEnfermedad) {
        this.nombreDeLaEnfermedad = nombreDeLaEnfermedad;
    }


    public String getFecha_Cita() {
        return Fecha_Cita;
    }

    public void setFecha_Cita(String Fecha_Cita) {
        this.Fecha_Cita = Fecha_Cita;
    }

    public int getPeso() {
        return Peso;
    }

    public void setPeso(int Peso) {
        this.Peso = Peso;
    }

    public int getAltura() {
        return Altura;
    }

    public void setAltura(int Altura) {
        this.Altura = Altura;
    }

    public String getRazon_Cita() {
        return Razon_Cita;
    }

    public void setRazon_Cita(String Razon_Cita) {
        this.Razon_Cita = Razon_Cita;
    }

    public String getDiagnostico() {
        return Diagnostico;
    }

    public void setDiagnostico(String Diagnostico) {
        this.Diagnostico = Diagnostico;
    }

    public String getLista_Sintomas() {
        return Lista_Sintomas;
    }

    public void setLista_Sintomas(String Lista_Sintomas) {
        this.Lista_Sintomas = Lista_Sintomas;
    }
   
    

    
    

    public void Mostrar_Historial() {
        JOptionPane.showMessageDialog(null, "------- Historial Médico -------\n" +
                                            "Peso : " + Peso + "\n" +
                                            "Altura : " + Altura + "\n" +
                                            "Fecha Cita : " + Fecha_Cita + "\n" +
                                            "Razón Cita : " + Razon_Cita + "\n" +
                                            "Diagnóstico : " + Diagnostico + "\n" +
                                            "Lista de Síntomas : " + Lista_Sintomas);
    }
}