//UsuarioDAO
package clinica_privada_poo_2026;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {
    public boolean validarLogin(String usuario,String Contraseña){
    
        String sql = "Select * from Usuarios WHERE Email = ? AND Contraseña = ?";
        
        try{
            Connection conexion = Conexion.conectar();
            
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            
            sentencia.setString(1, usuario);
            sentencia.setString(2, Contraseña);
            
            ResultSet resultado = sentencia.executeQuery();
            
            if (resultado.next()){
                return true;
            }
        
        
        }catch (SQLException ex) {
            System.out.println("Error AL VALIDAR EL LOGIN : " + ex.getMessage());
        }
        
        return false;
        
    }
    
    
}
