package clinica_privada_poo_2026;

import java.sql.Connection;

public class Clinica_Privada_POO_2026 {

    public static void main(String[] args) {

        Connection conexion = Conexion.conectar();

        if (conexion != null) {
            System.out.println("Conexion Exitosa !");

            VentanaBienvenida ventana1 = new VentanaBienvenida();
            ventana1.setVisible(true);
            ventana1.setLocationRelativeTo(null);

        } else {
            System.out.println("La conexion ha fallado, intentelo de nuevo.");
        }
    }
}
