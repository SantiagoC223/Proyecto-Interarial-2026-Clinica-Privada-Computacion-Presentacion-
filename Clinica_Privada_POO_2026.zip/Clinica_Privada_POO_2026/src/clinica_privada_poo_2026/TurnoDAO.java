
package clinica_privada_poo_2026;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.CallableStatement;

public class TurnoDAO {

    public void insertar(Turno t) {
        String consulta_sql = "call Turnos_Registrar(?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);


            sentencia_sql.setString(1, t.getCodigo_Paciente());
            sentencia_sql.setString(2, t.getNombre_completoMedico());
            sentencia_sql.setString(3, t.getFecha_Hora());
            sentencia_sql.setString(4, t.getMatricula_medico());
            sentencia_sql.setString(5, t.getEspecialidad());
            sentencia_sql.setInt(6, t.getSala());
            sentencia_sql.setString(7, t.getEstado());
            sentencia_sql.setString(8, t.getMotivoConsulta());
            sentencia_sql.setString(9, t.getTipoTurno());

            sentencia_sql.executeUpdate();
            System.out.println("Turno guardado exitosamente");

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        } catch (NumberFormatException ex) {
            System.out.println("ERROR: El DNI del paciente no tiene un formato numérico válido.");
        }
    }

    
    
    
  /*  public void insertar(Turno t) {
        String consulta_sql = "INSERT INTO turnos (codigo_paciente, nombre_completoMedico, matricula_medico, fecha_hora, Especialidad, sala, estado, motivoConsulta, tipoTurno) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, t.getCodigo_Paciente());
            sentencia_sql.setString(2, t.getNombre_completoMedico());
            sentencia_sql.setString(3, t.getMatricula_medico());
            sentencia_sql.setString(4, t.getFecha_Hora());
            sentencia_sql.setString(5, t.getEspecialidad());
            sentencia_sql.setInt(6, t.getSala());
            sentencia_sql.setString(7, t.getEstado());
            sentencia_sql.setString(8, t.getMotivoConsulta());
            sentencia_sql.setString(9, t.getTipoTurno());

            sentencia_sql.executeUpdate();
            System.out.println("Turno guardado exitosamente");

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }*/

    
    
    public ArrayList<Turno> listar() {
        ArrayList<Turno> lista_turnos = new ArrayList<>();
        String consulta_sql = "call Turnos_MostrarTodos()";

        try {            
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Turno t = new Turno();

                t.setIdTurno(resultado.getInt("id_turno"));
                t.setCodigo_Paciente(resultado.getString("codigo_paciente"));
                t.setNombre_completoMedico(resultado.getString("nombre_completoMedico"));
                t.setMatricula_medico(resultado.getString("matricula_medico"));
                t.setFecha_Hora(resultado.getString("fecha_hora"));
                t.setEspecialidad(resultado.getString("Especialidad"));
                t.setSala(resultado.getInt("sala"));
                t.setEstado(resultado.getString("estado"));
                t.setMotivoConsulta(resultado.getString("motivoConsulta"));
                t.setTipoTurno(resultado.getString("tipoTurno"));

                lista_turnos.add(t);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }

        return lista_turnos;
    }
    
    /*public ArrayList<Turno> listar() {
        ArrayList<Turno> lista_turnos = new ArrayList<>();
        String consulta_sql = "SELECT * FROM turnos";

        try {            
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Turno t = new Turno();

                t.setIdTurno(resultado.getInt("id_turno"));
                t.setCodigo_Paciente(resultado.getString("codigo_paciente"));
                t.setNombre_completoMedico(resultado.getString("nombre_completoMedico")); // Corregido a set
                t.setMatricula_medico(resultado.getString("matricula_medico")); // Agregado
                t.setFecha_Hora(resultado.getString("fecha_hora"));
                t.setEspecialidad(resultado.getString("Especialidad"));
                t.setSala(resultado.getInt("sala"));
                t.setEstado(resultado.getString("estado"));
                t.setMotivoConsulta(resultado.getString("motivoConsulta"));
                t.setTipoTurno(resultado.getString("tipoTurno"));

                lista_turnos.add(t);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
        return lista_turnos;
    }*/
    
    public void actualizar(Turno turno) {
        String consulta_sql = "call Turnos_Actualizar(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);


            sentencia_sql.setInt(1, turno.getIdTurno());
            sentencia_sql.setString(2, turno.getCodigo_Paciente());
            sentencia_sql.setString(3, turno.getNombre_completoMedico());
            sentencia_sql.setString(4, turno.getFecha_Hora());
            sentencia_sql.setString(5, turno.getMatricula_medico());
            sentencia_sql.setString(6, turno.getEspecialidad());
            sentencia_sql.setInt(7, turno.getSala());
            sentencia_sql.setString(8, turno.getEstado());
            sentencia_sql.setString(9, turno.getMotivoConsulta());
            sentencia_sql.setString(10, turno.getTipoTurno());

            sentencia_sql.executeUpdate();
            System.out.println("Datos del turno actualizados exitosamente");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        } catch (NumberFormatException ex) {
            System.out.println("ERROR: El código de paciente debe ser numérico.");
        }
    }
    
    
    

    /*public void actualizar(Turno turno) {
        String consulta_sql = "UPDATE turnos SET codigo_paciente = ?, nombre_completoMedico = ?, matricula_medico = ?, fecha_hora = ?, Especialidad = ?, sala = ?, estado = ?, motivoConsulta = ?, tipoTurno = ? WHERE id_turno = ?";

        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, turno.getCodigo_Paciente());
            sentencia_sql.setString(2, turno.getNombre_completoMedico());
            sentencia_sql.setString(3, turno.getMatricula_medico());
            sentencia_sql.setString(4, turno.getFecha_Hora());
            sentencia_sql.setString(5, turno.getEspecialidad());
            sentencia_sql.setInt(6, turno.getSala());
            sentencia_sql.setString(7, turno.getEstado());
            sentencia_sql.setString(8, turno.getMotivoConsulta());
            sentencia_sql.setString(9, turno.getTipoTurno());
            sentencia_sql.setInt(10, turno.getIdTurno());

            sentencia_sql.executeUpdate();
            System.out.println("Datos del turno actualizados exitosamente");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }
*/
    
    public void eliminar(int id) {
        String consulta_sql = "call Turnos_Eliminar(?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();

            System.out.println("Registro de turno eliminado exitosamente !");
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
    
   /* public void eliminar(int id) {
        String consulta_sql = "DELETE FROM turnos WHERE id_turno = ?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro de turno eliminado exitosamente !");
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }*/

    public ArrayList<Turno> buscarPorPaciente(String codigoPacienteBuscado) {
        ArrayList<Turno> turnos = new ArrayList<>();
        String consulta_sql = "call Turnos_mostrarPorCOdigo_PACIENTE(?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, Integer.parseInt(codigoPacienteBuscado));
            ResultSet resultado_sql = sentencia_sql.executeQuery();

            while (resultado_sql.next()) {
                Turno turno = new Turno();
                turno.setIdTurno(resultado_sql.getInt("id_turno"));
                turno.setCodigo_Paciente(resultado_sql.getString("codigo_paciente"));
                turno.setNombre_completoMedico(resultado_sql.getString("nombre_completoMedico"));
                turno.setMatricula_medico(resultado_sql.getString("matricula_medico"));
                turno.setFecha_Hora(resultado_sql.getString("fecha_hora"));
                turno.setEspecialidad(resultado_sql.getString("Especialidad"));
                turno.setSala(resultado_sql.getInt("sala"));
                turno.setEstado(resultado_sql.getString("estado"));
                turno.setMotivoConsulta(resultado_sql.getString("motivoConsulta"));
                turno.setTipoTurno(resultado_sql.getString("tipoTurno"));

                turnos.add(turno);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        } catch (NumberFormatException ex) {
            System.out.println("ERROR: El DNI debe ser numérico.");
        }

        return turnos;
    }

    
    
   /* public ArrayList<Turno> buscarPorPaciente(String codigoPacienteBuscado) {
        ArrayList<Turno> turnos = new ArrayList<>();
        String consulta_sql = "SELECT * FROM turnos WHERE codigo_paciente = ?";
        
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setString(1, codigoPacienteBuscado);
            ResultSet resultado_sql = sentencia_sql.executeQuery();

            while (resultado_sql.next()) {
                Turno turno = new Turno();
                turno.setIdTurno(resultado_sql.getInt("id_turno"));
                turno.setCodigo_Paciente(resultado_sql.getString("codigo_paciente"));
                turno.setNombre_completoMedico(resultado_sql.getString("nombre_completoMedico"));
                turno.setMatricula_medico(resultado_sql.getString("matricula_medico"));
                turno.setFecha_Hora(resultado_sql.getString("fecha_hora"));
                turno.setEspecialidad(resultado_sql.getString("Especialidad"));
                turno.setSala(resultado_sql.getInt("sala"));
                turno.setEstado(resultado_sql.getString("estado"));
                turno.setMotivoConsulta(resultado_sql.getString("motivoConsulta"));
                turno.setTipoTurno(resultado_sql.getString("tipoTurno"));

                turnos.add(turno);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
        return turnos;
    }*/
}