//Gestion del paciente
package clinica_privada_poo_2026;

import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GestionPaciente extends javax.swing.JFrame {
    private Clinica_Privada CP = new Clinica_Privada("Gestion Paciente");

    
    public GestionPaciente() {
        initComponents();
        this.CP = CP;
        getContentPane().setBackground(new Color(58, 130, 196));
        repaint();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jPasswordField1 = new javax.swing.JPasswordField();
        jLabel19 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaPacientes = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtNumeroAfiliado = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtSeguroMedico = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtGrupoSanguineo = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtListaHistoriales = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        txtGenero = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtDni = new javax.swing.JTextField();
        txtFechaNacimiento = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btnIngresar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        txtBuscarNumeroAfiliado = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Gestionar");

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel17.setText("Datos De La Cuenta");

        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });

        jLabel19.setText("Contraseña");

        jButton3.setText("jButton1");

        jButton1.setText("jButton1");

        jButton4.setText("jButton1");

        jButton5.setText("jButton1");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton2.setText("jButton1");

        jLabel4.setText("jLabel4");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tablaPacientes.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        tablaPacientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Apellido", "DNI", "Email", "F. Nac", "Direccion", "Genero", "Seguro Medico", "Numero Afiliado", "Grupo Sanguineo", "Lista historiales"
            }
        ));
        tablaPacientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaPacientesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaPacientes);

        jLabel14.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel14.setText("Seguro Medico");

        txtNumeroAfiliado.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        txtNumeroAfiliado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumeroAfiliadoActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel15.setText("Numero Afiliado");

        txtSeguroMedico.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        jLabel16.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel16.setText("Grupo Sanguineo");

        txtGrupoSanguineo.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        txtGrupoSanguineo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGrupoSanguineoActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel8.setText("Direccion");

        jLabel9.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel9.setText("Genero");

        txtListaHistoriales.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        txtListaHistoriales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtListaHistorialesActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel5.setText("Nombre");

        jLabel18.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel18.setText("Lista Historiales");

        jLabel6.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel6.setText("Apellido");

        jLabel7.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel7.setText("DNI");

        jLabel10.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel10.setText("Email");

        jLabel11.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel11.setText("F. Nac");

        txtDireccion.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtGenero.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtApellido.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        txtApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidoActionPerformed(evt);
            }
        });

        txtNombre.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtDni.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        txtDni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDniActionPerformed(evt);
            }
        });

        txtFechaNacimiento.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        jLabel12.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        jLabel12.setText("Personal");

        txtEmail.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        jLabel13.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        jLabel13.setText("Datos Como Paciente");

        jPanel1.setBackground(new java.awt.Color(58, 130, 196));

        btnIngresar.setBackground(new java.awt.Color(0, 71, 138));
        btnIngresar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnIngresar.setText("Ingresar");
        btnIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarActionPerformed(evt);
            }
        });

        btnBuscar.setBackground(new java.awt.Color(0, 71, 138));
        btnBuscar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnMostrar.setBackground(new java.awt.Color(0, 71, 138));
        btnMostrar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnLimpiar.setBackground(new java.awt.Color(0, 71, 138));
        btnLimpiar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnEliminar.setBackground(new java.awt.Color(0, 71, 138));
        btnEliminar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnEditar.setBackground(new java.awt.Color(0, 71, 138));
        btnEditar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnVolver.setBackground(new java.awt.Color(0, 71, 138));
        btnVolver.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        txtBuscarNumeroAfiliado.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnVolver, javax.swing.GroupLayout.DEFAULT_SIZE, 623, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(txtBuscarNumeroAfiliado)
                            .addGap(18, 18, 18)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnLimpiar, javax.swing.GroupLayout.DEFAULT_SIZE, 311, Short.MAX_VALUE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(btnIngresar, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnEditar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIngresar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBuscarNumeroAfiliado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(0, 71, 138));

        jLabel23.setFont(new java.awt.Font("Book Antiqua", 0, 36)); // NOI18N
        jLabel23.setText("Gestion De Paciente : Clinica Privada ");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(jLabel23)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel23)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel18)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel14)
                                            .addComponent(jLabel16)
                                            .addComponent(jLabel15))
                                        .addGap(43, 43, 43)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txtListaHistoriales, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtGrupoSanguineo, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtNumeroAfiliado, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtSeguroMedico, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jLabel13)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel10)
                                                    .addComponent(jLabel11)
                                                    .addComponent(jLabel9)
                                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(txtFechaNacimiento, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(txtDireccion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(txtGenero, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jLabel5)
                                                        .addComponent(jLabel7)
                                                        .addComponent(jLabel6))
                                                    .addGap(83, 83, 83)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                        .addComponent(txtApellido, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addComponent(jLabel12)
                                                .addComponent(txtEmail, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGap(44, 44, 44)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(jLabel2))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7))
                                .addGap(8, 8, 8)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel10)
                                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(9, 9, 9)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtFechaNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel11))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel8)
                                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel9)
                                    .addComponent(txtGenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtSeguroMedico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNumeroAfiliado, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtGrupoSanguineo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16)))
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtListaHistoriales, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNumeroAfiliadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNumeroAfiliadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNumeroAfiliadoActionPerformed

    private void txtGrupoSanguineoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGrupoSanguineoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGrupoSanguineoActionPerformed

    private void txtListaHistorialesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtListaHistorialesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtListaHistorialesActionPerformed

    private void txtApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidoActionPerformed

    private void txtDniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDniActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDniActionPerformed

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordField1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed
    
    public void mostrarPacienteEnTabla(Paciente P){
        DefaultTableModel modelo = (DefaultTableModel)tablaPacientes.getModel();
        modelo.setRowCount(0);
        
        Object[] fila = {
       
            P.getNombre(),
            P.getApellido(),
            P.getDNI(),
            P.getEmail(),
            P.getFecha_Nacimiento(),
            P.getDireccion(),
            P.getGenero(),

            P.getSeguro_Medico(),
            P.getNumero_Afiliado(),
            P.getGrupo_Sanguineo(),
            P.getLista_Historial()
        };
                
        modelo.addRow(fila);
        
    
    }
    
    
    private void tablaPacientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaPacientesMouseClicked
        int fila = tablaPacientes.getSelectedRow();
        
        System.out.println("Fila seleccionada : " + fila);
        
        int id = (int) tablaPacientes.getValueAt(fila,0);
        
        String Nombre = tablaPacientes.getValueAt(fila,1).toString();
        String Apellido = tablaPacientes.getValueAt(fila,2).toString();
        String DNI = tablaPacientes.getValueAt(fila,3).toString();
        String Email = tablaPacientes.getValueAt(fila,4).toString();
        String FNac = tablaPacientes.getValueAt(fila,5).toString();
        String Direccion = tablaPacientes.getValueAt(fila,6).toString();
        String Genero = tablaPacientes.getValueAt(fila,7).toString();
        
        String SegMed = tablaPacientes.getValueAt(fila,8).toString();
        String NumAf = tablaPacientes.getValueAt(fila,9).toString();
        String GruSan = tablaPacientes.getValueAt(fila,10).toString();
        String LisHis = tablaPacientes.getValueAt(fila,11).toString();
        
        
        txtNombre.setText(Nombre);
        txtApellido.setText(Apellido);
        txtDni.setText(DNI);
        txtEmail.setText(Email);
        txtFechaNacimiento.setText(FNac);
        txtDireccion.setText(Direccion);
        txtGenero.setText(Genero);
        
        txtSeguroMedico.setText(SegMed);
        txtNumeroAfiliado.setText(NumAf);
        txtGrupoSanguineo.setText(GruSan);
        txtListaHistoriales.setText(LisHis);
        System.out.println("ID seleccionado " + id);
    }//GEN-LAST:event_tablaPacientesMouseClicked

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        VentanaSeleccion ventanaSeleccion = new VentanaSeleccion();
        ventanaSeleccion.setVisible(true);
        ventanaSeleccion.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        int fila = tablaPacientes.getSelectedRow();
        if (fila == -1) {
            System.out.println("Debe seleccionar un paciente");
            return;
        }

        int id = (int) tablaPacientes.getValueAt(fila,0);

        String Nombre = txtNombre.getText();
        String Apellido = txtApellido.getText();
        int DNI = Integer.parseInt(txtDni.getText());
        String Email = txtEmail.getText();
        String Fecha_Nacimiento = txtFechaNacimiento.getText();
        String Direccion = txtDireccion.getText();
        String genero = txtGenero.getText();

        String seguroMedico = txtSeguroMedico.getText();
        String Numero_Afiliado = txtNumeroAfiliado.getText();
        String Grupo_Sanguineo = txtGrupoSanguineo.getText();
        String Lista_Historial = txtListaHistoriales.getText();

        Paciente paciente = new Paciente( seguroMedico,  Numero_Afiliado,  Grupo_Sanguineo,  Lista_Historial,  Nombre,  Apellido,  DNI,  Email,  Fecha_Nacimiento,  Direccion,  genero);

        paciente.setId_paciente(id);

        PacienteDAO dao = new PacienteDAO();

        dao.actualizarPaciente(paciente);
        System.out.println("Datos Modificados Correctamente.");
        JOptionPane.showMessageDialog(null,"Datos Modificados Correctamente.");
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = tablaPacientes.getSelectedRow();
        if (fila == -1) {
            System.out.println("Debe seleccionar un paciente");
            return;
        }

        int id = (int)tablaPacientes.getValueAt(fila,0);

        PacienteDAO dao = new PacienteDAO();
        int confirmar = JOptionPane.showConfirmDialog(null, "Seguro que querés eliminar este Paciente?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirmar != JOptionPane.YES_OPTION) {
            return;
        }
        dao.eliminarPaciente(id);

        JOptionPane.showMessageDialog(null,"Paciente eliminado Correctamente");
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        txtNombre.setText("");
        txtApellido.setText("");
        txtDni.setText("");
        txtEmail.setText("");
        txtFechaNacimiento.setText("");
        txtDireccion.setText("");
        txtGenero.setText("");

        txtSeguroMedico.setText("");
        txtNumeroAfiliado.setText("");
        txtGrupoSanguineo.setText("");
        txtListaHistoriales.setText("");
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
        PacienteDAO dao = new PacienteDAO();
        ArrayList<Paciente> Lista_Pacientes = dao.listarPaciente();
        DefaultTableModel modelo = (DefaultTableModel)tablaPacientes.getModel();

        modelo.setRowCount(0);

        for(Paciente paciente: Lista_Pacientes){
            modelo.addRow(new Object[] {
                paciente.getId_paciente(),
                paciente.getNombre(),
                paciente.getApellido(),
                paciente.getDNI(),
                paciente.getEmail(),
                paciente.getFecha_Nacimiento(),
                paciente.getDireccion(),
                paciente.getGenero(),

                paciente.getSeguro_Medico(),
                paciente.getNumero_Afiliado(),
                paciente.getGrupo_Sanguineo(),
                paciente.getLista_Historial()
            });

        }
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String numeroBuscado = txtBuscarNumeroAfiliado.getText();

        if (!numeroBuscado.matches("[a-zA-Z0-9\\-]+")) {
            JOptionPane.showMessageDialog(null, "ERROR - El número de afiliado tiene caracteres no permitidos");
            return;
        }

        PacienteDAO dao = new PacienteDAO();

        ArrayList<Paciente> listaPacientes = dao.buscarPorNumeroAfiliado(numeroBuscado);

        DefaultTableModel modelo = (DefaultTableModel)tablaPacientes.getModel();
        modelo.setRowCount(0);

        for(Paciente paciente : listaPacientes){
            modelo.addRow(new Object[] {
                paciente.getId_paciente(),
                paciente.getNombre(),
                paciente.getApellido(),
                paciente.getDNI(),
                paciente.getEmail(),
                paciente.getFecha_Nacimiento(),
                paciente.getDireccion(),
                paciente.getGenero(),

                paciente.getSeguro_Medico(),
                paciente.getNumero_Afiliado(),
                paciente.getGrupo_Sanguineo(),
                paciente.getLista_Historial()
            });

        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarActionPerformed
        String Nombre = txtNombre.getText();
        String Apellido = txtApellido.getText();
        String dniTexto = txtDni.getText();
        String Email = txtEmail.getText();
        String Fecha_Nacimiento = txtFechaNacimiento.getText();
        String Direccion = txtDireccion.getText();
        String genero = txtGenero.getText();

        String seguroMedico = txtSeguroMedico.getText();
        String Numero_Afiliado = txtNumeroAfiliado.getText();
        String Grupo_Sanguineo = txtGrupoSanguineo.getText();
        String Lista_Historial = txtListaHistoriales.getText();

        if (!Nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
            JOptionPane.showMessageDialog(null, "ERROR - El nombre solo puede tener letras");
            return;
        }

        if (!Apellido.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
            JOptionPane.showMessageDialog(null, "ERROR - El apellido solo puede tener letras");
            return;
        }

        if (!dniTexto.matches("[0-9]{8}")) {
            JOptionPane.showMessageDialog(null, "ERROR - El DNI debe ser solo numeros y tener exactamente 8 digitos");
            return;
        }

        if (!Email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            JOptionPane.showMessageDialog(null, "ERROR - Ingrese un correo electronico valido");
            return;
        }

        if (!Fecha_Nacimiento.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) {
            JOptionPane.showMessageDialog(null, "ERROR - La fecha de nacimiento debe tener el formato: año-mes-dia");
            return;
        }

        if (!Direccion.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0-9 .,#°-]+")) {
            JOptionPane.showMessageDialog(null, "ERROR - La dirección tiene caracteres no permitidos");
            return;
        }

        if (!genero.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
            JOptionPane.showMessageDialog(null, "ERROR - El género solo puede tener letras");
            return;
        }

        if (!seguroMedico.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0-9 ]+")) {
            JOptionPane.showMessageDialog(null, "ERROR - El seguro médico tiene caracteres no permitidos");
            return;
        }

        if (!Numero_Afiliado.matches("[a-zA-Z0-9\\-]+")) {
            JOptionPane.showMessageDialog(null, "ERROR - El número de afiliado tiene caracteres no permitidos");
            return;
        }

        if (!Grupo_Sanguineo.matches("[a-zA-Z0-9+-]+")) {
            JOptionPane.showMessageDialog(null, "ERROR - El grupo sanguíneo no es válido");
            return;
        }

        if (!Lista_Historial.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0-9 .,;:¿?¡!()-]*")) {
            JOptionPane.showMessageDialog(null, "ERROR - La lista de historial tiene caracteres no permitidos");
            return;
        }

        int DNI = Integer.parseInt(dniTexto);

        Paciente nuevoPaciente = new Paciente( seguroMedico,  Numero_Afiliado,  Grupo_Sanguineo,  Lista_Historial,  Nombre,  Apellido,  DNI,  Email,  Fecha_Nacimiento,  Direccion,  genero);

        //CP.Agregar_Persona(nuevoPaciente);
        PacienteDAO DAO = new PacienteDAO();

        DAO.insertarPaciente(nuevoPaciente);

        JOptionPane.showMessageDialog(null, "paciente registrado exitosamente !");
        txtNombre.setText("");
        txtApellido.setText("");
        txtDni.setText("");
        txtEmail.setText("");
        txtFechaNacimiento.setText("");
        txtDireccion.setText("");
        txtGenero.setText("");

        txtSeguroMedico.setText("");
        txtNumeroAfiliado.setText("");
        txtGrupoSanguineo.setText("");
        txtListaHistoriales.setText("");
    }//GEN-LAST:event_btnIngresarActionPerformed

    
    private void actualizarTabla(){
        DefaultTableModel modelo = (DefaultTableModel)tablaPacientes.getModel();
        modelo.setRowCount(0);
        
        for(Persona P : CP.getLista_Personas()){
            
            if (P instanceof Paciente ){
                
                Paciente PA = (Paciente) P;
            
                Object[] fila = {
                    PA.getNombre(),
                    PA.getApellido(),
                    PA.getDNI(),
                    PA.getEmail(),
                    PA.getFecha_Nacimiento(),
                    PA.getDireccion(),
                    PA.getGenero(),

                    PA.getSeguro_Medico(),
                    PA.getNumero_Afiliado(),
                    PA.getGrupo_Sanguineo(),
                    PA.getLista_Historial()
                };
                
                modelo.addRow(fila); 
            }
            
        }
    }
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnIngresar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaPacientes;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBuscarNumeroAfiliado;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtDni;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtFechaNacimiento;
    private javax.swing.JTextField txtGenero;
    private javax.swing.JTextField txtGrupoSanguineo;
    private javax.swing.JTextField txtListaHistoriales;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNumeroAfiliado;
    private javax.swing.JTextField txtSeguroMedico;
    // End of variables declaration//GEN-END:variables
}
