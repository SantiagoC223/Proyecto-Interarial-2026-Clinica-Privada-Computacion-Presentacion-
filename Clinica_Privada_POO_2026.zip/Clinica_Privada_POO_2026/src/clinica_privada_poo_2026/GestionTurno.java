//Gestion turno
package clinica_privada_poo_2026;

import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GestionTurno extends javax.swing.JFrame {
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GestionSintoma.class.getName());
    private Clinica_Privada CP = new Clinica_Privada("Gestion Turno");
    public GestionTurno() {
        initComponents();
        this.CP = CP;
        getContentPane().setBackground(new Color(58, 130, 196));
        repaint();
    }
    //NG

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtCodigoPaciente = new javax.swing.JTextField();
        txtNombreMedico = new javax.swing.JTextField();
        txtFecha_Hora = new javax.swing.JTextField();
        txtEspecialidad = new javax.swing.JTextField();
        txtSala = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaTurno = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtEstado = new javax.swing.JTextField();
        txtMotivoConsulta = new javax.swing.JTextField();
        txtTipoTurno = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtMatriculaMedico = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        btnEditar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        txtDniBuscar = new javax.swing.JTextField();
        Ingresar = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel2.setText("DNI del Paciente");

        jLabel3.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel3.setText("Fecha y Hora");

        jLabel4.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel4.setText("Especialidad");

        jLabel5.setText("Sala");

        jLabel6.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel6.setText("Nombre del Medico");

        txtCodigoPaciente.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        txtCodigoPaciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodigoPacienteActionPerformed(evt);
            }
        });

        txtNombreMedico.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtFecha_Hora.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtEspecialidad.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        txtEspecialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEspecialidadActionPerformed(evt);
            }
        });

        txtSala.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        tablaTurno.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        tablaTurno.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Paciente DNI", "Medico", "Matricula Medico", "Fecha y Hora", "Especialidad", "Sala", "Estado", "Motivo de la Consulta", "Tipo de Turno"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, true, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaTurno.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaTurnoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaTurno);
        if (tablaTurno.getColumnModel().getColumnCount() > 0) {
            tablaTurno.getColumnModel().getColumn(0).setResizable(false);
        }

        jLabel1.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel1.setText("Estado");

        jLabel8.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel8.setText("Motivo de la Consulta");

        jLabel9.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel9.setText("Tipo de Turno");

        txtEstado.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtMotivoConsulta.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtTipoTurno.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel7.setText("Matricula Del Medico");

        txtMatriculaMedico.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        jPanel2.setBackground(new java.awt.Color(0, 71, 138));

        jLabel11.setFont(new java.awt.Font("Book Antiqua", 0, 36)); // NOI18N
        jLabel11.setText("Gestion De Turnos : Clinica Privada ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(jLabel11)
                .addContainerGap(247, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel11)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        btnEditar.setBackground(new java.awt.Color(0, 71, 138));
        btnEditar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnBuscar.setBackground(new java.awt.Color(0, 71, 138));
        btnBuscar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        txtDniBuscar.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        txtDniBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDniBuscarActionPerformed(evt);
            }
        });

        Ingresar.setBackground(new java.awt.Color(0, 71, 138));
        Ingresar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        Ingresar.setText("Ingresar");
        Ingresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IngresarActionPerformed(evt);
            }
        });

        btnMostrar.setBackground(new java.awt.Color(0, 71, 138));
        btnMostrar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnEliminar.setBackground(new java.awt.Color(0, 71, 138));
        btnEliminar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnVolver.setBackground(new java.awt.Color(0, 71, 138));
        btnVolver.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        btnLimpiar.setBackground(new java.awt.Color(0, 71, 138));
        btnLimpiar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(40, 40, 40)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtMotivoConsulta, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE)
                                    .addComponent(txtEstado, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtSala, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtTipoTurno)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4))
                                .addGap(101, 101, 101)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtFecha_Hora, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                                    .addComponent(txtEspecialidad)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(txtMatriculaMedico, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel6)
                                        .addComponent(jLabel2))
                                    .addGap(58, 58, 58)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtCodigoPaciente, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                                        .addComponent(txtNombreMedico)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 84, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtDniBuscar)
                                .addGap(18, 18, 18)
                                .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(Ingresar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnEditar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnLimpiar, javax.swing.GroupLayout.DEFAULT_SIZE, 288, Short.MAX_VALUE)))
                            .addComponent(btnVolver, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(14, 14, 14)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtCodigoPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNombreMedico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtMatriculaMedico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtFecha_Hora, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtSala, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtMotivoConsulta, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(txtTipoTurno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 4, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Ingresar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtDniBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)
                        .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtEspecialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEspecialidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEspecialidadActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
    txtCodigoPaciente.setText("");
    txtNombreMedico.setText("");
    txtMatriculaMedico.setText("");
    txtFecha_Hora.setText("");
    txtEspecialidad.setText("");
    txtSala.setText("");
    txtEstado.setText("");
    txtMotivoConsulta.setText("");
    txtTipoTurno.setText("");
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
   int fila = tablaTurno.getSelectedRow();
    if (fila == -1) {
        System.out.println("Debe seleccionar un turno.");
        return;
    }

    int idTurno = (int) tablaTurno.getValueAt(fila, 0);
    String codigoPaciente = txtCodigoPaciente.getText();
    String nombreMedico = txtNombreMedico.getText();
    String matriculaMedico = txtMatriculaMedico.getText();
    String fechaHora = txtFecha_Hora.getText();
    String especialidad = txtEspecialidad.getText();
    int sala = Integer.parseInt(txtSala.getText());
    String estado = txtEstado.getText();
    String motivoConsulta = txtMotivoConsulta.getText();
    String tipoTurno = txtTipoTurno.getText();

    Turno turno = new Turno();
    turno.setIdTurno(idTurno);
    turno.setCodigo_Paciente(codigoPaciente);
    turno.setNombre_completoMedico(nombreMedico);
    turno.setMatricula_medico(matriculaMedico);
    turno.setFecha_Hora(fechaHora);
    turno.setEspecialidad(especialidad);
    turno.setSala(sala);
    turno.setEstado(estado);
    turno.setMotivoConsulta(motivoConsulta);
    turno.setTipoTurno(tipoTurno);

    TurnoDAO dao = new TurnoDAO();
    dao.actualizar(turno);
    JOptionPane.showMessageDialog(null, "Datos modificados correctamente.");
    }//GEN-LAST:event_btnEditarActionPerformed

    private void IngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IngresarActionPerformed
    String codigoPaciente = txtCodigoPaciente.getText();
    String nombreMedico = txtNombreMedico.getText();
    String matriculaMedico = txtMatriculaMedico.getText();
    String fechaHora = txtFecha_Hora.getText();
    String especialidad = txtEspecialidad.getText();
    int sala = Integer.parseInt(txtSala.getText());
    String estado = txtEstado.getText();
    String motivoConsulta = txtMotivoConsulta.getText();
    String tipoTurno = txtTipoTurno.getText();
        
        if(!codigoPaciente.matches("[0-9]{8}")){
            JOptionPane.showMessageDialog(null, "ERROR - El DNI del paciente debe tener solo numeros y no mayor a 8 caracteres");
            return;
        }
        if(!nombreMedico.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")){
            JOptionPane.showMessageDialog(null, "ERROR - El campo nombre solo puede contener letras");
            return;
        }
       
        if(!fechaHora.matches("[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}")){
            JOptionPane.showMessageDialog(null, "ERROR - El campo fecha y hora debe tener el formato: año-mes-dia 00:00:00");
            return;
        }
       
        if(!especialidad.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")){
            JOptionPane.showMessageDialog(null, "ERROR - El campo especialidad solo puede contener letras");
            return;
        }
       
        if(!txtSala.getText().matches("[0-9]+")){
            JOptionPane.showMessageDialog(null, "ERROR - El Codigo de la sala debe tener solo numeros");
            return;
        }
       
        if(!estado.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")){
            JOptionPane.showMessageDialog(null, "ERROR - El campo estado solo puede contener letras");
            return;
        }
        if(!motivoConsulta.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0-9 .,;:¿?¡!()-]+")){
            JOptionPane.showMessageDialog(null, "ERROR - El motivo de consulta contiene caracteres no permitidos");
            return;
        }
        if(!tipoTurno.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")){
            JOptionPane.showMessageDialog(null, "ERROR - El campo tipo de turno solo puede contener letras");
            return;
        }
        
    
    Turno nuevoTurno = new Turno(codigoPaciente, nombreMedico, matriculaMedico, fechaHora, especialidad, sala, estado, motivoConsulta, tipoTurno);

    TurnoDAO dao = new TurnoDAO();
    dao.insertar(nuevoTurno);

    JOptionPane.showMessageDialog(null, "Turno registrado exitosamente");


    txtCodigoPaciente.setText("");
    txtNombreMedico.setText("");
    txtMatriculaMedico.setText("");
    txtFecha_Hora.setText("");
    txtEspecialidad.setText("");
    txtSala.setText("");
    txtEstado.setText("");
    txtMotivoConsulta.setText("");
    txtTipoTurno.setText("");
    
    
    }//GEN-LAST:event_IngresarActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
    
    TurnoDAO dao = new TurnoDAO();
    ArrayList<Turno> lista_turnos = dao.listar();
    DefaultTableModel modelo = (DefaultTableModel) tablaTurno.getModel();

    modelo.setRowCount(0);

    for (Turno turno : lista_turnos) {
        modelo.addRow(new Object[]{
            turno.getIdTurno(),
            turno.getCodigo_Paciente(),
            turno.getNombre_completoMedico(),
            turno.getMatricula_medico(),     
            turno.getFecha_Hora(),
            turno.getEspecialidad(),
            turno.getSala(),
            turno.getEstado(),
            turno.getMotivoConsulta(),
            turno.getTipoTurno()
        });
    }
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
    int fila = tablaTurno.getSelectedRow();
    
    if (fila == -1) {
        JOptionPane.showMessageDialog(null, "Debe seleccionar un turno");
        return;
    }

    int idTurno = Integer.parseInt(tablaTurno.getValueAt(fila, 0).toString());
    
    TurnoDAO dao = new TurnoDAO();
     int confirmar = JOptionPane.showConfirmDialog(null, "Seguro que querés eliminar este Turno?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirmar != JOptionPane.YES_OPTION) {
          return;
        }
    dao.eliminar(idTurno);

    JOptionPane.showMessageDialog(null, "Registro eliminado exitosamente");    
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
    String buscarTurno = txtDniBuscar.getText();
    if (!buscarTurno.matches("[0-9]{8}")) {
    JOptionPane.showMessageDialog(null, "ERROR - El DNI que trata de buscar contiene algún signo no vàlido o es demasiado largo");
    return;
    }
    
    
    TurnoDAO dao = new TurnoDAO();

    ArrayList<Turno> turnos = dao.buscarPorPaciente(buscarTurno);

    DefaultTableModel modelo = (DefaultTableModel) tablaTurno.getModel();

    modelo.setRowCount(0);

    for (Turno turno : turnos) {
        modelo.addRow(new Object[]{
            turno.getIdTurno(),
            turno.getCodigo_Paciente(),
            turno.getNombre_completoMedico(),
            turno.getMatricula_medico(),
            turno.getFecha_Hora(),
            turno.getEspecialidad(),
            turno.getSala(),
            turno.getEstado(),
            turno.getMotivoConsulta(),
            turno.getTipoTurno()
        });
    }    
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void txtCodigoPacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoPacienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodigoPacienteActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        VentanaSeleccion ventanaSeleccion = new VentanaSeleccion();
        ventanaSeleccion.setVisible(true);
        ventanaSeleccion.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnVolverActionPerformed

    private void tablaTurnoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaTurnoMouseClicked
    int fila = tablaTurno.getSelectedRow();

        System.out.println("Fila seleccionada: "+ fila);
        int idTurno = Integer.parseInt(tablaTurno.getValueAt(fila, 0).toString());

    String codigoPaciente = tablaTurno.getValueAt(fila, 1).toString();
    String nombreMedico = tablaTurno.getValueAt(fila, 2).toString();
    String matriculaMedico = tablaTurno.getValueAt(fila, 3).toString();
    String fechaHora = tablaTurno.getValueAt(fila, 4).toString();
    String especialidad = tablaTurno.getValueAt(fila, 5).toString();
    String sala = tablaTurno.getValueAt(fila, 6).toString();
    String estado = tablaTurno.getValueAt(fila, 7).toString();
    String motivoConsulta = tablaTurno.getValueAt(fila, 8).toString();
    String tipoTurno = tablaTurno.getValueAt(fila, 9).toString();

    txtCodigoPaciente.setText(codigoPaciente);
    txtNombreMedico.setText(nombreMedico);
    txtMatriculaMedico.setText(matriculaMedico);
    txtFecha_Hora.setText(fechaHora);
    txtEspecialidad.setText(especialidad);
    txtSala.setText(sala);
    txtEstado.setText(estado);
    txtMotivoConsulta.setText(motivoConsulta);
    txtTipoTurno.setText(tipoTurno);

    System.out.println("ID seleccionado: " + idTurno); 
    }//GEN-LAST:event_tablaTurnoMouseClicked

    private void txtDniBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDniBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDniBuscarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Ingresar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaTurno;
    private javax.swing.JTextField txtCodigoPaciente;
    private javax.swing.JTextField txtDniBuscar;
    private javax.swing.JTextField txtEspecialidad;
    private javax.swing.JTextField txtEstado;
    private javax.swing.JTextField txtFecha_Hora;
    private javax.swing.JTextField txtMatriculaMedico;
    private javax.swing.JTextField txtMotivoConsulta;
    private javax.swing.JTextField txtNombreMedico;
    private javax.swing.JTextField txtSala;
    private javax.swing.JTextField txtTipoTurno;
    // End of variables declaration//GEN-END:variables
}
