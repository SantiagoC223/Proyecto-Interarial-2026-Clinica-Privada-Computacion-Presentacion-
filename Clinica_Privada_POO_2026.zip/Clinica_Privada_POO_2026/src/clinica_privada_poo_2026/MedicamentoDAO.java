
package clinica_privada_poo_2026;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.CallableStatement;
public class MedicamentoDAO {
       
    public void insertar(Medicamento m) {
        String consulta_sql = "call Medicamentos_Registrar(?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setString(1, m.getNombre());
            sentencia_sql.setString(2, m.getGrupo_Anatomico());
            sentencia_sql.setString(3, m.getTipo());
            sentencia_sql.setString(4, m.getCondicion_Venta());
            sentencia_sql.setString(5, m.getForma_Farmaceutica());
            sentencia_sql.setString(6, m.getCategoria_Subtipo());
            sentencia_sql.setString(7, m.getVia_Administracion());
            sentencia_sql.setString(8, m.getDosis_Unidad());
            sentencia_sql.setInt(9, m.getDosis_Cantidad());

            sentencia_sql.executeUpdate();
            System.out.println("Medicamento guardado exitosamente");

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
    
    
    /* public void insertar(Medicamento m){
        String consulta_sql = "INSERT INTO medicamentos (Nombre, Grupo_Anatomico, Tipo, Condicion_Venta, Forma_Farmaceutica, Categoria_Subtipo, Via_Administracion, Dosis_Unidad, Dosis_Cantidad) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, m.getNombre());
            sentencia_sql.setString(2, m.getGrupo_Anatomico());
            sentencia_sql.setString(3, m.getTipo());
            sentencia_sql.setString(4, m.getCondicion_Venta());
            sentencia_sql.setString(5, m.getForma_Farmaceutica());
            sentencia_sql.setString(6, m.getCategoria_Subtipo());
            sentencia_sql.setString(7, m.getVia_Administracion());
            sentencia_sql.setString(8, m.getDosis_Unidad());
            sentencia_sql.setInt(9, m.getDosis_Cantidad());

            sentencia_sql.executeUpdate();

            System.out.println("Medicamento guardado exitosamente");

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
      }*/
    
    public ArrayList<Medicamento> listar() {
        ArrayList<Medicamento> lista_medicamentos = new ArrayList<>();
        String consulta_sql = "call Medicamentos_MostrarTodos()";

        try {            
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while(resultado.next()){
                Medicamento m = new Medicamento();
                m.setId_medicamento(resultado.getInt("id_medicamento"));
                m.setNombre(resultado.getString("Nombre"));
                m.setGrupo_Anatomico(resultado.getString("Grupo_Anatomico"));
                m.setTipo(resultado.getString("Tipo"));
                m.setCondicion_Venta(resultado.getString("Condicion_Venta"));
                m.setForma_Farmaceutica(resultado.getString("Forma_Farmaceutica"));
                m.setCategoria_Subtipo(resultado.getString("Categoria_Subtipo"));
                m.setVia_Administracion(resultado.getString("Via_Administracion"));
                m.setDosis_Unidad(resultado.getString("Dosis_Unidad"));
                m.setDosis_Cantidad(resultado.getInt("Dosis_Cantidad"));

                lista_medicamentos.add(m);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR "+ ex.getMessage());
        }
        return lista_medicamentos;
    }
    
    
    
     /* public ArrayList<Medicamento> listar(){
        ArrayList<Medicamento> lista_medicamentos = new ArrayList<>();

        String consulta_sql = "SELECT * FROM medicamentos";

        try {            
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while(resultado.next()){
                Medicamento m = new Medicamento();

                m.setId_medicamento(resultado.getInt("id_medicamento"));
                m.setNombre(resultado.getString("Nombre"));
                m.setGrupo_Anatomico(resultado.getString("Grupo_Anatomico"));
                m.setTipo(resultado.getString("Tipo"));
                m.setCondicion_Venta(resultado.getString("Condicion_Venta"));
                m.setForma_Farmaceutica(resultado.getString("Forma_Farmaceutica"));
                m.setCategoria_Subtipo(resultado.getString("Categoria_Subtipo"));
                m.setVia_Administracion(resultado.getString("Via_Administracion"));
                m.setDosis_Unidad(resultado.getString("Dosis_Unidad"));
                m.setDosis_Cantidad(resultado.getInt("Dosis_Cantidad"));

                lista_medicamentos.add(m);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR "+ ex.getMessage());
        }
        return lista_medicamentos;
    }*/      

    public void actualizar(Medicamento medicamento) {
        String consulta_sql = "call Medicamentos_Actualizar(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, medicamento.getId_medicamento());
            sentencia_sql.setString(2, medicamento.getNombre());
            sentencia_sql.setString(3, medicamento.getGrupo_Anatomico());
            sentencia_sql.setString(4, medicamento.getTipo());
            sentencia_sql.setString(5, medicamento.getCondicion_Venta());
            sentencia_sql.setString(6, medicamento.getForma_Farmaceutica());
            sentencia_sql.setString(7, medicamento.getCategoria_Subtipo());
            sentencia_sql.setString(8, medicamento.getVia_Administracion());
            sentencia_sql.setString(9, medicamento.getDosis_Unidad());
            sentencia_sql.setInt(10, medicamento.getDosis_Cantidad());

            sentencia_sql.executeUpdate();
            System.out.println("Datos actualizados exitosamente");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }
    
    
    
     /* public void actualizar(Medicamento medicamento) {
        String consulta_sql = "UPDATE medicamentos SET Nombre = ?, Grupo_Anatomico = ?, Tipo = ?, Condicion_Venta = ?, Forma_Farmaceutica = ?, Categoria_Subtipo = ?, Via_Administracion = ?, Dosis_Unidad = ?, Dosis_Cantidad = ? WHERE id_medicamento = ?";

        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, medicamento.getNombre());
            sentencia_sql.setString(2, medicamento.getGrupo_Anatomico());
            sentencia_sql.setString(3, medicamento.getTipo());
            sentencia_sql.setString(4, medicamento.getCondicion_Venta());
            sentencia_sql.setString(5, medicamento.getForma_Farmaceutica());
            sentencia_sql.setString(6, medicamento.getCategoria_Subtipo());
            sentencia_sql.setString(7, medicamento.getVia_Administracion());
            sentencia_sql.setString(8, medicamento.getDosis_Unidad());
            sentencia_sql.setInt(9, medicamento.getDosis_Cantidad());
            sentencia_sql.setInt(10, medicamento.getId_medicamento());

            sentencia_sql.executeUpdate();

            System.out.println("Datos actualizados exitosamente");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }*/
    
    public void eliminar(int id) {
        String consulta_sql = "call Medicamentos_Eliminar(?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();

            System.out.println("Registro eliminado exitosamente !");
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
    
    
    
      /*public void eliminar(int id) {
        String consulta_sql = "DELETE FROM medicamentos WHERE id_medicamento = ?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro eliminado exitosamente !");
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }*/

    public ArrayList<Medicamento> buscarPorNombre(String nombre_buscado) {
        ArrayList<Medicamento> medicamentos = new ArrayList<>();
        String consulta_sql = "call Medicamentos_BuscarPorNombre(?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setString(1, nombre_buscado);
            ResultSet resultado_sql = sentencia_sql.executeQuery();

            while (resultado_sql.next()) {
                Medicamento medicamento = new Medicamento();
                medicamento.setId_medicamento(resultado_sql.getInt("id_medicamento"));
                medicamento.setNombre(resultado_sql.getString("Nombre"));
                medicamento.setGrupo_Anatomico(resultado_sql.getString("Grupo_Anatomico"));
                medicamento.setTipo(resultado_sql.getString("Tipo"));
                medicamento.setCondicion_Venta(resultado_sql.getString("Condicion_Venta"));
                medicamento.setForma_Farmaceutica(resultado_sql.getString("Forma_Farmaceutica"));
                medicamento.setCategoria_Subtipo(resultado_sql.getString("Categoria_Subtipo"));
                medicamento.setVia_Administracion(resultado_sql.getString("Via_Administracion"));
                medicamento.setDosis_Unidad(resultado_sql.getString("Dosis_Unidad"));
                medicamento.setDosis_Cantidad(resultado_sql.getInt("Dosis_Cantidad"));

                medicamentos.add(medicamento);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
        return medicamentos;
    }

    
    
      /*public ArrayList<Medicamento> buscarPorNombre(String nombre_buscado) {
            ArrayList<Medicamento> medicamentos = new ArrayList<>();
            String consulta_sql = "select * from medicamentos WHERE Nombre = ?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setString(1, nombre_buscado);
            ResultSet resultado_sql = sentencia_sql.executeQuery();

            while (resultado_sql.next()) {
                Medicamento medicamento = new Medicamento();
                medicamento.setId_medicamento(resultado_sql.getInt("id_medicamento"));
                medicamento.setNombre(resultado_sql.getString("Nombre"));
                medicamento.setGrupo_Anatomico(resultado_sql.getString("Grupo_Anatomico"));
                medicamento.setTipo(resultado_sql.getString("Tipo"));
                medicamento.setCondicion_Venta(resultado_sql.getString("Condicion_Venta"));
                medicamento.setForma_Farmaceutica(resultado_sql.getString("Forma_Farmaceutica"));
                medicamento.setCategoria_Subtipo(resultado_sql.getString("Categoria_Subtipo"));
                medicamento.setVia_Administracion(resultado_sql.getString("Via_Administracion"));
                medicamento.setDosis_Unidad(resultado_sql.getString("Dosis_Unidad"));
                medicamento.setDosis_Cantidad(resultado_sql.getInt("Dosis_Cantidad"));

                medicamentos.add(medicamento);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
        return medicamentos;
    }*/
}