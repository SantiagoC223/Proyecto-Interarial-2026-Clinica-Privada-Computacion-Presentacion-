
package clinica_privada_poo_2026;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.CallableStatement;

public class TratamientoDAO {
    
    public void insertar(Tratamiento t) {
        String consulta_sql = "call tratamientos_registrar(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setString(1, t.getNombre());
            sentencia_sql.setString(2, t.getTipo());
            sentencia_sql.setString(3, t.getArea());
            sentencia_sql.setString(4, t.getDetalles());
            sentencia_sql.setInt(5, t.getDiasDuracion());
            sentencia_sql.setInt(6, t.getDiasReposo());
            sentencia_sql.setInt(7, t.getCantidadSesiones());
            sentencia_sql.setInt(8, t.getCosto());
            sentencia_sql.setString(9, t.getRequiereInternacion());
            sentencia_sql.setString(10, t.getEstado());
            sentencia_sql.setString(11, t.getMateriales());
            sentencia_sql.setString(12, t.getMedicamentos());
            sentencia_sql.setString(13, t.getEnfermedades());

            sentencia_sql.executeUpdate();
            System.out.println("Tratamiento guardado");

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
    
    /*public void insertar(Tratamiento t) {
    String consulta_sql = "insert into Tratamiento (nombre, tipo, area, detalles, dias_duracion, dias_reposo, cantidad_sesiones, costo, requiere_internacion, estado, materiales, medicamento, enfermedad) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

        sentencia_sql.setString(1, t.getNombre());
        sentencia_sql.setString(2, t.getTipo());
        sentencia_sql.setString(3, t.getArea());
        sentencia_sql.setString(4, t.getDetalles());
        sentencia_sql.setInt(5, t.getDiasDuracion());
        sentencia_sql.setInt(6, t.getDiasReposo());
        sentencia_sql.setInt(7, t.getCantidadSesiones());
        sentencia_sql.setInt(8, t.getCosto());
        sentencia_sql.setString(9, t.getRequiereInternacion());
        sentencia_sql.setString(10, t.getEstado());
        sentencia_sql.setString(11, t.getMateriales());
        sentencia_sql.setString(12, t.getMedicamentos());
        sentencia_sql.setString(13, t.getEnfermedades());

        sentencia_sql.executeUpdate();

        System.out.println("Tratamiento guardado");

    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
}*/
    
    
    public ArrayList<Tratamiento> listar() {
        ArrayList<Tratamiento> lista_tratamientos = new ArrayList<>();
        String consulta_sql = "call tratamientos_mostrartodos()";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Tratamiento t = new Tratamiento();

                t.setIdTratamiento(resultado.getInt("id_tratamiento"));
                t.setNombre(resultado.getString("nombre"));
                t.setTipo(resultado.getString("tipo"));
                t.setArea(resultado.getString("area"));
                t.setDetalles(resultado.getString("detalles"));
                t.setDiasDuracion(resultado.getInt("dias_duracion"));
                t.setDiasReposo(resultado.getInt("dias_reposo"));
                t.setCantidadSesiones(resultado.getInt("cantidad_sesiones"));
                t.setCosto(resultado.getInt("costo"));
                t.setRequiereInternacion(resultado.getString("requiere_internacion"));
                t.setEstado(resultado.getString("estado"));
                t.setMateriales(resultado.getString("materiales"));
                t.setMedicamentos(resultado.getString("medicamento"));  
                t.setEnfermedades(resultado.getString("enfermedad"));

                lista_tratamientos.add(t);
            }

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }

        return lista_tratamientos;
    }
    
    
    /*public ArrayList<Tratamiento> listar() {
    ArrayList<Tratamiento> lista_tratamientos = new ArrayList<>();

    String consulta_sql = "select * from Tratamiento";

    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

        ResultSet resultado = sentencia_sql.executeQuery();

        while (resultado.next()) {
            Tratamiento t = new Tratamiento();

            t.setIdTratamiento(resultado.getInt("id_tratamiento"));
            t.setNombre(resultado.getString("nombre"));
            t.setTipo(resultado.getString("tipo"));
            t.setArea(resultado.getString("area"));
            t.setDetalles(resultado.getString("detalles"));
            t.setDiasDuracion(resultado.getInt("dias_duracion"));
            t.setDiasReposo(resultado.getInt("dias_reposo"));
            t.setCantidadSesiones(resultado.getInt("cantidad_sesiones"));
            t.setCosto(resultado.getInt("costo"));
            t.setRequiereInternacion(resultado.getString("requiere_internacion"));
            t.setEstado(resultado.getString("estado"));
            t.setMateriales(resultado.getString("materiales"));
            t.setMedicamentos(resultado.getString("medicamento"));  
            t.setEnfermedades(resultado.getString("enfermedad"));

            lista_tratamientos.add(t);
        }

    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }

    return lista_tratamientos;
}*/
    
    
    public void actualizar(Tratamiento t) {
        String consulta_sql = "call tratamientos_actualizar(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, t.getIdTratamiento());
            sentencia_sql.setString(2, t.getNombre());
            sentencia_sql.setString(3, t.getTipo());
            sentencia_sql.setString(4, t.getArea());
            sentencia_sql.setString(5, t.getDetalles());
            sentencia_sql.setInt(6, t.getDiasDuracion());
            sentencia_sql.setInt(7, t.getDiasReposo());
            sentencia_sql.setInt(8, t.getCantidadSesiones());
            sentencia_sql.setInt(9, t.getCosto());
            sentencia_sql.setString(10, t.getRequiereInternacion());
            sentencia_sql.setString(11, t.getEstado());
            sentencia_sql.setString(12, t.getMateriales());
            sentencia_sql.setString(13, t.getMedicamentos());
            sentencia_sql.setString(14, t.getEnfermedades());

            sentencia_sql.executeUpdate();
            System.out.println("Datos actualizados exitosamente");

        } catch (SQLException ex) {
            System.out.println("error: " + ex.getMessage());
        }
    }
    
    /*public void actualizar(Tratamiento t) {
    String consulta_sql = "update Tratamiento set nombre = ?, tipo = ?, area = ?, detalles = ?, dias_duracion = ?, dias_reposo = ?, cantidad_sesiones = ?, costo = ?, requiere_internacion = ?, estado = ?, materiales = ?, medicamento = ?, enfermedad = ? where id_tratamiento = ?";

    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

        sentencia_sql.setString(1, t.getNombre());
        sentencia_sql.setString(2, t.getTipo());
        sentencia_sql.setString(3, t.getArea());
        sentencia_sql.setString(4, t.getDetalles());
        sentencia_sql.setInt(5, t.getDiasDuracion());
        sentencia_sql.setInt(6, t.getDiasReposo());
        sentencia_sql.setInt(7, t.getCantidadSesiones());
        sentencia_sql.setInt(8, t.getCosto());
        sentencia_sql.setString(9, t.getRequiereInternacion());
        sentencia_sql.setString(10, t.getEstado());
        sentencia_sql.setString(11, t.getMateriales());
        sentencia_sql.setString(12, t.getMedicamentos());
        sentencia_sql.setString(13, t.getEnfermedades());
        sentencia_sql.setInt(14, t.getIdTratamiento());

        sentencia_sql.executeUpdate();

        System.out.println("Datos actualizados exitosamente");

    } catch (SQLException ex) {
        System.out.println("error: " + ex.getMessage());
    }
}*/
    
    public void eliminar(int id) {
        String consulta_sql = "call tratamientos_eliminar(?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();

            System.out.println("Tratamiento eliminado exitosamente");

        } catch (SQLException ex) {
            System.out.println("error: " + ex.getMessage());
        }
    }
    
    /*public void eliminar(int id) {
    String consulta_sql = "delete from Tratamiento where id_tratamiento = ?";

    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

        sentencia_sql.setInt(1, id);
        sentencia_sql.executeUpdate();

        System.out.println("Tratamiento eliminado exitosamente");

    } catch (SQLException ex) {
        System.out.println("error: " + ex.getMessage());
    }
}*/
    
    public ArrayList<Tratamiento> buscarTratamiento(String Nombre) {
        ArrayList<Tratamiento> tratamientos = new ArrayList<>();
        String consulta_sql = "call tratamientos_buscarpornombre(?)";

        try {
            Connection conexion = Conexion.conectar();
            CallableStatement sentencia_sql = conexion.prepareCall(consulta_sql);
            sentencia_sql.setString(1, Nombre);
            ResultSet resultado_sql = sentencia_sql.executeQuery();

            while (resultado_sql.next()) {
                Tratamiento t = new Tratamiento();
                t.setIdTratamiento(resultado_sql.getInt("id_tratamiento"));
                t.setNombre(resultado_sql.getString("nombre"));
                t.setTipo(resultado_sql.getString("tipo"));
                t.setArea(resultado_sql.getString("area"));
                t.setDetalles(resultado_sql.getString("detalles"));
                t.setDiasDuracion(resultado_sql.getInt("dias_duracion"));
                t.setDiasReposo(resultado_sql.getInt("dias_reposo"));
                t.setCantidadSesiones(resultado_sql.getInt("cantidad_sesiones"));
                t.setCosto(resultado_sql.getInt("costo"));
                t.setRequiereInternacion(resultado_sql.getString("requiere_internacion"));
                t.setEstado(resultado_sql.getString("estado"));
                t.setMateriales(resultado_sql.getString("materiales"));
                t.setMedicamentos(resultado_sql.getString("medicamento"));
                t.setEnfermedades(resultado_sql.getString("enfermedad"));

                tratamientos.add(t);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
        return tratamientos;
    }
    
    /*public ArrayList<Tratamiento> buscarTratamiento(String Nombre) {
    ArrayList<Tratamiento> tratamientos = new ArrayList<>();
    String consulta_sql = "select * from Tratamiento where nombre = ?";

    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
        sentencia_sql.setString(1, Nombre);
        ResultSet resultado_sql = sentencia_sql.executeQuery();

        while (resultado_sql.next()) {
            Tratamiento t = new Tratamiento();
            t.setIdTratamiento(resultado_sql.getInt("id_tratamiento"));
            t.setNombre(resultado_sql.getString("nombre"));
            t.setTipo(resultado_sql.getString("tipo"));
            t.setArea(resultado_sql.getString("area"));
            t.setDetalles(resultado_sql.getString("detalles"));
            t.setDiasDuracion(resultado_sql.getInt("dias_duracion"));
            t.setDiasReposo(resultado_sql.getInt("dias_reposo"));
            t.setCantidadSesiones(resultado_sql.getInt("cantidad_sesiones"));
            t.setCosto(resultado_sql.getInt("costo"));
            t.setRequiereInternacion(resultado_sql.getString("requiere_internacion"));
            t.setEstado(resultado_sql.getString("estado"));
            t.setMateriales(resultado_sql.getString("materiales"));
            t.setMedicamentos(resultado_sql.getString("medicamento"));
            t.setEnfermedades(resultado_sql.getString("enfermedad"));

            tratamientos.add(t);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR: " + ex.getMessage());
    }
    return tratamientos;
}*/
    
}

