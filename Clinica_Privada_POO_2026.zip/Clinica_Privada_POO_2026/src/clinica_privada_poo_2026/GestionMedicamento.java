//GEstion MEdicamento
package clinica_privada_poo_2026;

import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import java.util.logging.Level;
import java.util.logging.Logger;

public class GestionMedicamento extends javax.swing.JFrame {
    private static final Logger logger = Logger.getLogger(GestionMedicamento.class.getName());
    private Clinica_Privada CP = new Clinica_Privada("Gestion Medico");
   
    public GestionMedicamento() {
        initComponents();
        this.CP = CP;
        getContentPane().setBackground(new Color(58, 130, 196));
        repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaMedicamentos = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        btnIngresar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        txtbuscarNombre = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtGrupoAnatomico = new javax.swing.JTextField();
        txtTipo = new javax.swing.JTextField();
        txtCondicionVenta = new javax.swing.JTextField();
        txtFormaFarmaceutica = new javax.swing.JTextField();
        txtDosisUnidad = new javax.swing.JTextField();
        txtDosisCantidad = new javax.swing.JTextField();
        txtCategoriaSubtipo = new javax.swing.JTextField();
        txtViaAdministracion = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();

        jLabel11.setText("jLabel2");

        jLabel12.setText("jLabel2");

        jLabel13.setText("jLabel2");

        jLabel14.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jScrollPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jScrollPane1MouseClicked(evt);
            }
        });

        tablaMedicamentos.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        tablaMedicamentos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "id_medicamento", "Nombre", "Grupo Anatomico", "Tipo", "Condicion Venta", "Forma Farmaceutica", "Categoria Subtipo", "Via administracion", "Dosis unidad", "Dosis Cantidad"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, true, true, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaMedicamentos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMedicamentosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaMedicamentos);
        if (tablaMedicamentos.getColumnModel().getColumnCount() > 0) {
            tablaMedicamentos.getColumnModel().getColumn(0).setResizable(false);
        }

        jPanel1.setBackground(new java.awt.Color(58, 130, 196));

        btnIngresar.setBackground(new java.awt.Color(0, 71, 138));
        btnIngresar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnIngresar.setText("Ingresar");
        btnIngresar.addActionListener(this::btnIngresarActionPerformed);

        btnBuscar.setBackground(new java.awt.Color(0, 71, 138));
        btnBuscar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(this::btnBuscarActionPerformed);

        btnMostrar.setBackground(new java.awt.Color(0, 71, 138));
        btnMostrar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(this::btnMostrarActionPerformed);

        btnLimpiar.setBackground(new java.awt.Color(0, 71, 138));
        btnLimpiar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(this::btnLimpiarActionPerformed);

        btnEliminar.setBackground(new java.awt.Color(0, 71, 138));
        btnEliminar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(this::btnEliminarActionPerformed);

        btnEditar.setBackground(new java.awt.Color(0, 71, 138));
        btnEditar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(this::btnEditarActionPerformed);

        btnVolver.setBackground(new java.awt.Color(0, 71, 138));
        btnVolver.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnVolver.setText("Volver");
        btnVolver.addActionListener(this::btnVolverActionPerformed);

        txtbuscarNombre.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        txtbuscarNombre.addActionListener(this::txtbuscarNombreActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnVolver, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(txtbuscarNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnIngresar, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(14, 14, 14))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnEditar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnIngresar, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnLimpiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtbuscarNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addGap(18, 18, 18)
                .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66))
        );

        jLabel2.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel2.setText("Nombre");

        jLabel3.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel3.setText("Grupo Anatomico");

        jLabel4.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel4.setText("Tipo");

        jLabel5.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel5.setText("Condicion de venta");

        jLabel6.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel6.setText("Forma Farmaceutica");

        jLabel7.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel7.setText("Categoria De Subtipo");

        jLabel8.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel8.setText("Via Administracion");

        jLabel9.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel9.setText("Dosis Unidad");

        jLabel10.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel10.setText("Dosis Cantidad");

        txtTipo.addActionListener(this::txtTipoActionPerformed);

        jPanel3.setBackground(new java.awt.Color(0, 71, 138));

        jLabel23.setFont(new java.awt.Font("Book Antiqua", 0, 36)); // NOI18N
        jLabel23.setText("Gestion De Medico : Clinica Privada ");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(jLabel23)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel23)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel10)
                            .addComponent(jLabel9)
                            .addComponent(jLabel3))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtCategoriaSubtipo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 253, Short.MAX_VALUE)
                                    .addComponent(txtDosisUnidad, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtDosisCantidad)
                                    .addComponent(txtViaAdministracion, javax.swing.GroupLayout.Alignment.TRAILING)))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNombre))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtFormaFarmaceutica, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtCondicionVenta, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtTipo)
                                    .addComponent(txtGrupoAnatomico, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addGap(127, 127, 127)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtGrupoAnatomico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCondicionVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(txtFormaFarmaceutica, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtCategoriaSubtipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txtViaAdministracion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(txtDosisUnidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(txtDosisCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 22, Short.MAX_VALUE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarActionPerformed
        String nombre = txtNombre.getText();
        String grupoAnatomico = txtGrupoAnatomico.getText();
        String tipo = txtTipo.getText();
        String condicionVenta = txtCondicionVenta.getText();
        String formaFarmaceutica = txtFormaFarmaceutica.getText();
        String categoriaSubtipo = txtCategoriaSubtipo.getText();
        String viaAdministracion = txtViaAdministracion.getText();
        String dosisUnidad = txtDosisUnidad.getText();
        String dosisCantidadTexto = txtDosisCantidad.getText();
        
        if (!nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0 ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - El nombre tiene caracteres no permitidos");
        return;
        }

        if (!grupoAnatomico.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0 ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - El grupo anatómico tiene caracteres no permitidos");
        return;
        }


        if (!tipo.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0 ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - El tipo tiene caracteres no permitidos");
        return;
        }


        if (!condicionVenta.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0 ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - La condición de venta tiene caracteres no permitidos");
        return;
        }


        if (!formaFarmaceutica.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0 ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - La forma farmacéutica tiene caracteres no permitidos");
        return;
        }


        if (!categoriaSubtipo.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0 ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - La categoría/subtipo tiene caracteres no permitidos");
        return;
        }

        if (!viaAdministracion.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0 ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - La vía de administración tiene caracteres no permitidos");
        return;
        }


        if (!dosisUnidad.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0 ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - La unidad de dosis tiene caracteres no permitidos");
        return;
        }


        if (!dosisCantidadTexto.matches("[0-9]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - La cantidad de dosis tiene que ser un número válido");
        return;
        }
        
        int dosisCantidad = Integer.parseInt(dosisCantidadTexto);
        

        Medicamento nuevoMedicamento = new Medicamento( nombre,  grupoAnatomico,  tipo,  condicionVenta,  formaFarmaceutica,  categoriaSubtipo,  viaAdministracion,  dosisUnidad,  dosisCantidad);

        //CP.AgregarMedicamento(nuevoMedicamento);
        
        MedicamentoDAO dao = new MedicamentoDAO();
        
        dao.insertar(nuevoMedicamento);
        
        
        JOptionPane.showMessageDialog(null, "¡Medicamento registrado exitosamente!");

        txtNombre.setText("");
        txtGrupoAnatomico.setText("");
        txtTipo.setText("");
        txtCondicionVenta.setText("");
        txtFormaFarmaceutica.setText("");
        txtCategoriaSubtipo.setText("");
        txtViaAdministracion.setText("");
        txtDosisUnidad.setText("");
        txtDosisCantidad.setText("");

    }//GEN-LAST:event_btnIngresarActionPerformed

    public void mostrarMedicamentoEnTabla(Medicamento M){
        DefaultTableModel modelo = (DefaultTableModel)tablaMedicamentos.getModel();
        modelo.setRowCount(0);
        
        Object[] fila = {
            M.getNombre(),
            M.getGrupo_Anatomico(),
            M.getTipo(),
            M.getCondicion_Venta(),
            M.getForma_Farmaceutica(),
            M.getCategoria_Subtipo(),
            M.getVia_Administracion(),

            M.getDosis_Unidad(),
            M.getDosis_Cantidad()
        };
                
        modelo.addRow(fila); 
    }
    
    private void ActualizarTabla(){
        DefaultTableModel modelo = (DefaultTableModel)tablaMedicamentos.getModel();
        modelo.setRowCount(0);
        
        for(Medicamento M: CP.getLista_Medicamentos()){
            Object[] fila = {
                M.getNombre(),
                M.getGrupo_Anatomico(),
                M.getTipo(),
                M.getCondicion_Venta(),
                M.getForma_Farmaceutica(),
                M.getCategoria_Subtipo(),
                M.getVia_Administracion(),

                M.getDosis_Unidad(),
                M.getDosis_Cantidad()
            };
        
            modelo.addRow(fila); 
        
        }
    
    
    }
    
    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
    String nombreBuscado = txtbuscarNombre.getText();
    
    if (!nombreBuscado.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0 ]+")) {
    JOptionPane.showMessageDialog(null, "ERROR - El nombre tiene caracteres no permitidos");
    return;
    }
    
    MedicamentoDAO dao = new MedicamentoDAO();
    
    ArrayList<Medicamento> medicamentos = dao.buscarPorNombre(nombreBuscado);
    
    DefaultTableModel modelo = (DefaultTableModel) tablaMedicamentos.getModel();
    
    modelo.setRowCount(0);
    
    for (Medicamento medicamento : medicamentos) {
        modelo.addRow(new Object[]{
            medicamento.getId_medicamento(),
            medicamento.getNombre(),
            medicamento.getGrupo_Anatomico(),
            medicamento.getTipo(),
            medicamento.getCondicion_Venta(),
            medicamento.getForma_Farmaceutica(),
            medicamento.getCategoria_Subtipo(),
            medicamento.getVia_Administracion(),
            medicamento.getDosis_Unidad(),
            medicamento.getDosis_Cantidad()
        });
    }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
    MedicamentoDAO dao = new MedicamentoDAO();
        ArrayList <Medicamento> lista_medicamentos = dao.listar();
        DefaultTableModel modelo = (DefaultTableModel)tablaMedicamentos.getModel();

        modelo.setRowCount(0);

    for (Medicamento medicamento : lista_medicamentos) {
        modelo.addRow(new Object[]{
            medicamento.getId_medicamento(),
            medicamento.getNombre(),
            medicamento.getGrupo_Anatomico(),
            medicamento.getTipo(),
            medicamento.getCondicion_Venta(),
            medicamento.getForma_Farmaceutica(),
            medicamento.getCategoria_Subtipo(),
            medicamento.getVia_Administracion(),
            medicamento.getDosis_Unidad(),
            medicamento.getDosis_Cantidad()
        });
    }

    }//GEN-LAST:event_btnMostrarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        txtNombre.setText("");
        txtGrupoAnatomico.setText("");
        txtTipo.setText("");
        txtCondicionVenta.setText("");
        txtFormaFarmaceutica.setText("");
        txtCategoriaSubtipo.setText("");
        txtViaAdministracion.setText("");
        txtDosisUnidad.setText("");
        txtDosisCantidad.setText("");
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
    int fila = tablaMedicamentos.getSelectedRow();
    
    if (fila == -1) {
        JOptionPane.showMessageDialog(null, "Debe seleccionar un medicamento");
        return;
    }
    
    int id = (int) tablaMedicamentos.getValueAt(fila, 0);
    
    MedicamentoDAO dao = new MedicamentoDAO();
    int confirmar = JOptionPane.showConfirmDialog(null, "Seguro que querés eliminar este Medicamento?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirmar != JOptionPane.YES_OPTION) {
          return;
        }
    dao.eliminar(id);
    
    JOptionPane.showMessageDialog(null, "Registro eliminado exitosamente");
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
    int fila = tablaMedicamentos.getSelectedRow();
    if (fila == -1) {
        System.out.println("Debe seleccionar un medicamento.");
        return;
    }
    
    int id = (int) tablaMedicamentos.getValueAt(fila, 0);
    String nombre = txtNombre.getText();
    String grupoAnatomico = txtGrupoAnatomico.getText();
    String tipo = txtTipo.getText();
    String condicionVenta = txtCondicionVenta.getText();
    String formaFarmaceutica = txtFormaFarmaceutica.getText();
    String categoriaSubtipo = txtCategoriaSubtipo.getText();
    String viaAdministracion = txtViaAdministracion.getText();
    String dosisUnidad = txtDosisUnidad.getText();
    int dosisCantidad = Integer.parseInt(txtDosisCantidad.getText());

        Medicamento medicamento = new Medicamento();
        medicamento.setId_medicamento(id);
        medicamento.setNombre(nombre);  
        medicamento.setGrupo_Anatomico(grupoAnatomico);
        medicamento.setTipo(tipo);
        medicamento.setCondicion_Venta(condicionVenta);
        medicamento.setForma_Farmaceutica(formaFarmaceutica);
        medicamento.setCategoria_Subtipo(categoriaSubtipo);
        medicamento.setVia_Administracion(viaAdministracion);
        medicamento.setDosis_Unidad(dosisUnidad);
        medicamento.setDosis_Cantidad(dosisCantidad);

        MedicamentoDAO dao = new MedicamentoDAO();
        dao.actualizar(medicamento);
        JOptionPane.showMessageDialog(null, "Datos modificados correctamente.");
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        VentanaSeleccion ventanaSeleccion = new VentanaSeleccion();
        ventanaSeleccion.setVisible(true);
        ventanaSeleccion.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnVolverActionPerformed

    private void txtTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTipoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTipoActionPerformed

    private void tablaMedicamentosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMedicamentosMouseClicked
    int fila = tablaMedicamentos.getSelectedRow();
    
        System.out.println("Fila seleccioanda: "+ fila);
        int id = (int) tablaMedicamentos.getValueAt(fila, 0);

    String nombre = tablaMedicamentos.getValueAt(fila, 1).toString();
    String grupoAnatomico = tablaMedicamentos.getValueAt(fila, 2).toString();
    String tipo = tablaMedicamentos.getValueAt(fila, 3).toString();
    String condicionVenta = tablaMedicamentos.getValueAt(fila, 4).toString();
    String formaFarmaceutica = tablaMedicamentos.getValueAt(fila, 5).toString();
    String categoriaSubtipo = tablaMedicamentos.getValueAt(fila, 6).toString();
    String viaAdministracion = tablaMedicamentos.getValueAt(fila, 7).toString();
    String dosisUnidad = tablaMedicamentos.getValueAt(fila, 8).toString();
    String dosisCantidad = tablaMedicamentos.getValueAt(fila, 9).toString();

    txtNombre.setText(nombre);
    txtGrupoAnatomico.setText(grupoAnatomico);
    txtTipo.setText(tipo);
    txtCondicionVenta.setText(condicionVenta);
    txtFormaFarmaceutica.setText(formaFarmaceutica);
    txtCategoriaSubtipo.setText(categoriaSubtipo);
    txtViaAdministracion.setText(viaAdministracion);
    txtDosisUnidad.setText(dosisUnidad);
    txtDosisCantidad.setText(dosisCantidad);

    System.out.println("ID seleccionado: " + id);
    }//GEN-LAST:event_tablaMedicamentosMouseClicked

    private void jScrollPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jScrollPane1MouseClicked

    private void txtbuscarNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbuscarNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtbuscarNombreActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GestionMedicamento().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnIngresar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaMedicamentos;
    private javax.swing.JTextField txtCategoriaSubtipo;
    private javax.swing.JTextField txtCondicionVenta;
    private javax.swing.JTextField txtDosisCantidad;
    private javax.swing.JTextField txtDosisUnidad;
    private javax.swing.JTextField txtFormaFarmaceutica;
    private javax.swing.JTextField txtGrupoAnatomico;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTipo;
    private javax.swing.JTextField txtViaAdministracion;
    private javax.swing.JTextField txtbuscarNombre;
    // End of variables declaration//GEN-END:variables
}
