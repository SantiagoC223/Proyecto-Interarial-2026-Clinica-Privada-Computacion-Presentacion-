//Turno
package clinica_privada_poo_2026;

import javax.swing.JOptionPane;

public class Turno {
    private int IdTurno;
    private String Codigo_Paciente;
    private String nombre_completoMedico;
    private String matricula_medico;
    private String Fecha_Hora;
    private String Especialidad ;
    private int Sala;
    private String estado;
    private String motivoConsulta;
    private String tipoTurno;


    public Turno(String Codigo_Paciente, String nombre_completoMedico, String matricula_medico, String Fecha_Hora, String Especialidad, int Sala, String estado, String motivoConsulta, String tipoTurno) {
        this.IdTurno = IdTurno;
        this.Codigo_Paciente = Codigo_Paciente;
        this.nombre_completoMedico = nombre_completoMedico;
        this.matricula_medico = matricula_medico;
        this.Fecha_Hora = Fecha_Hora;
        this.Especialidad = Especialidad;
        this.Sala = Sala;
        this.estado = estado;
        this.motivoConsulta = motivoConsulta;
        this.tipoTurno = tipoTurno;

    }

    Turno() {
        
    }
    
    

    public String getEspecialidad() {
        return Especialidad;
    }

    public void setEspecialidad(String Especialidad) {
        this.Especialidad = Especialidad;
    }

    public int getSala() {
        return Sala;
    }

    public void setSala(int Sala) {
        this.Sala = Sala;
    }


    public int getIdTurno() {
        return IdTurno;
    }

    public void setIdTurno(int IdTurno) {
        this.IdTurno = IdTurno;
    }

    public String getCodigo_Paciente() {
        return Codigo_Paciente;
    }

    public void setCodigo_Paciente(String Codigo_Paciente) {
        this.Codigo_Paciente = Codigo_Paciente;
    }

    public String getFecha_Hora() {
        return Fecha_Hora;
    }

    public void setFecha_Hora(String Fecha_Hora) {
        this.Fecha_Hora = Fecha_Hora;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMotivoConsulta() {
        return motivoConsulta;
    }

    public void setMotivoConsulta(String motivoConsulta) {
        this.motivoConsulta = motivoConsulta;
    }

    public String getTipoTurno() {
        return tipoTurno;
    }

    public void setTipoTurno(String tipoTurno) {
        this.tipoTurno = tipoTurno;
    }

    public String getNombre_completoMedico() {
        return nombre_completoMedico;
    }

    public void setNombre_completoMedico(String nombre_completoMedico) {
        this.nombre_completoMedico = nombre_completoMedico;
    }

    public String getMatricula_medico() {
        return matricula_medico;
    }

    public void setMatricula_medico(String matricula_medico) {
        this.matricula_medico = matricula_medico;
    }

    
    public void mostrarTurno(){

    }
}
