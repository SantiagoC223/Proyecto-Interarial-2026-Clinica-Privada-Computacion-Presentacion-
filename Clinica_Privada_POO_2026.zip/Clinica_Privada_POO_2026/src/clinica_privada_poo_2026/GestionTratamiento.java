
package clinica_privada_poo_2026;

import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GestionTratamiento extends javax.swing.JFrame {


    public GestionTratamiento() {
        initComponents();
        
        getContentPane().setBackground(new Color(58, 130, 196));
        repaint();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaTratamientos = new javax.swing.JTable();
        btnIngresar = new javax.swing.JButton();
        btnbuscar = new javax.swing.JButton();
        btneliminar = new javax.swing.JButton();
        btneditar = new javax.swing.JButton();
        btnmostrar = new javax.swing.JButton();
        btnlimpiar = new javax.swing.JButton();
        btnvolver = new javax.swing.JButton();
        txtNombreaBuscar = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtTipo = new javax.swing.JTextField();
        txtArea = new javax.swing.JTextField();
        txtDetalles = new javax.swing.JTextField();
        txtDuracion = new javax.swing.JTextField();
        txtDReposo = new javax.swing.JTextField();
        txtCtSesiones = new javax.swing.JTextField();
        txtCosto = new javax.swing.JTextField();
        txtRequiere = new javax.swing.JTextField();
        txtEstado = new javax.swing.JTextField();
        txtMateriales = new javax.swing.JTextField();
        txtMedicamentos = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtEnfermedad = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel1.setText("Nombre");

        tablaTratamientos.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        tablaTratamientos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nombre", "Tipo", "Área", "Detalles", "Duracion del Tratamiento", "Dias de reposo", "Cantidad de Sesiones", "Costo", "¿Requiere internarción?", "Estado", "Materiales", "Medicamentos", "Enfermedades"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, true, true, true, true, true, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaTratamientos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaTratamientosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaTratamientos);
        if (tablaTratamientos.getColumnModel().getColumnCount() > 0) {
            tablaTratamientos.getColumnModel().getColumn(0).setResizable(false);
        }

        btnIngresar.setBackground(new java.awt.Color(0, 71, 138));
        btnIngresar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnIngresar.setText("Ingresar");
        btnIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarActionPerformed(evt);
            }
        });

        btnbuscar.setBackground(new java.awt.Color(0, 71, 138));
        btnbuscar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnbuscar.setText("Buscar");
        btnbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbuscarActionPerformed(evt);
            }
        });

        btneliminar.setBackground(new java.awt.Color(0, 71, 138));
        btneliminar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btneliminar.setText("Eliminar");
        btneliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneliminarActionPerformed(evt);
            }
        });

        btneditar.setBackground(new java.awt.Color(0, 71, 138));
        btneditar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btneditar.setText("Editar");
        btneditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneditarActionPerformed(evt);
            }
        });

        btnmostrar.setBackground(new java.awt.Color(0, 71, 138));
        btnmostrar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnmostrar.setText("Mostrar");
        btnmostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmostrarActionPerformed(evt);
            }
        });

        btnlimpiar.setBackground(new java.awt.Color(0, 71, 138));
        btnlimpiar.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnlimpiar.setText("Limpiar");
        btnlimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlimpiarActionPerformed(evt);
            }
        });

        btnvolver.setBackground(new java.awt.Color(0, 71, 138));
        btnvolver.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        btnvolver.setText("Volver");
        btnvolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnvolverActionPerformed(evt);
            }
        });

        txtNombreaBuscar.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel2.setText("Tipo");

        jLabel3.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel3.setText("Area");

        jLabel4.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel4.setText("Detalles");

        jLabel5.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel5.setText("Duracion de tratamiento");

        jLabel6.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel6.setText("Cantidad de sesiones");

        jLabel7.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel7.setText("¿Requiere Internar?");

        jLabel8.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel8.setText("Estado");

        jLabel9.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel9.setText("Medicamentos");

        jLabel10.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel10.setText("Materiales");

        jLabel12.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel12.setText("Dias de reposo");

        jLabel13.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel13.setText("Costo");

        txtNombre.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtTipo.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtArea.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtDetalles.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtDuracion.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtDReposo.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtCtSesiones.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtCosto.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtRequiere.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtEstado.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtMateriales.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        txtMedicamentos.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        jLabel14.setFont(new java.awt.Font("Book Antiqua", 0, 14)); // NOI18N
        jLabel14.setText("Enfermedad");

        txtEnfermedad.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N

        jPanel1.setBackground(new java.awt.Color(0, 71, 138));

        jLabel11.setFont(new java.awt.Font("Book Antiqua", 0, 36)); // NOI18N
        jLabel11.setText("Gestion De Tratamientos : Clinica Privada ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(197, 197, 197)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 686, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addGap(27, 27, 27))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel12)
                                    .addComponent(jLabel6)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(3, 3, 3)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel5)
                                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addComponent(jLabel10)
                                            .addComponent(jLabel9)
                                            .addComponent(jLabel14)
                                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtMateriales)
                                            .addComponent(txtRequiere)
                                            .addComponent(txtDReposo)
                                            .addComponent(txtDuracion)
                                            .addComponent(txtCtSesiones)
                                            .addComponent(txtCosto)
                                            .addComponent(txtEstado)
                                            .addComponent(txtMedicamentos, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(txtEnfermedad))))
                                .addGap(126, 126, 126))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4))
                                .addGap(109, 109, 109)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtArea)
                                    .addComponent(txtTipo)
                                    .addComponent(txtNombre)
                                    .addComponent(txtDetalles, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 125, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(btnIngresar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnmostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(btneliminar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(btnlimpiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(btneditar, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(btnvolver, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtNombreaBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 439, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(6, 6, 6))
                    .addComponent(jScrollPane1))
                .addContainerGap())
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnIngresar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnmostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btneditar, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtArea, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(txtDetalles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtDuracion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(txtDReposo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtCtSesiones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btneliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnlimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtCosto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombreaBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtRequiere, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnvolver, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtMateriales, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtMedicamentos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(txtEnfermedad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarActionPerformed
    String Nombre = txtNombre.getText();
    String Tipo = txtTipo.getText();
    String Area = txtArea.getText();
    String Detalles = txtDetalles.getText();
    String duracionTexto = txtDuracion.getText();
    String reposoTexto = txtDReposo.getText();
    String sesionesTexto = txtCtSesiones.getText();
    String costoTexto = txtCosto.getText();
    String RequiereInternacion = txtRequiere.getText();
    String Estado = txtEstado.getText();
    String Materiales = txtMateriales.getText();
    String Medicamento = txtMedicamentos.getText();
    String Enfermedad = txtEnfermedad.getText();
    
    if (!Nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0 ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - El nombre tiene caracteres no permitidos");
        return;
    }

    if (!Tipo.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - El tipo solo puede tener letras");
        return;
    }

    if (!Area.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - El área solo puede tener letras");
        return;
    }

    if (!Detalles.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0-9 .,;:¿?¡!()-]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - Los detalles tienen caracteres no permitidos");
        return;
    }

    if (!duracionTexto.matches("[0-9]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - Los días de duración tiene que ser un número válido");
        return;
    }

    if (!reposoTexto.matches("[0-9]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - Los días de reposo tiene que ser un número válido");
        return;
    }

    if (!sesionesTexto.matches("[0-9]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - La cantidad de sesiones tiene que ser un número válido");
        return;
    }

    if (!costoTexto.matches("[0-9]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - El costo tiene que ser un número válido");
        return;
    }

    if (!RequiereInternacion.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - El campo requiere internación solo puede tener letras");
        return;
    }

    if (!Estado.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - El estado solo puede tener letras");
        return;
    }

    if (!Materiales.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0-9 .,-]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - Los materiales tienen caracteres no permitidos");
        return;
    }

    if (!Medicamento.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0-9 ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - El medicamento tienen caracteres no permitidos");
        return;
    }

    if (!Enfermedad.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0-9 ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - La enfermedad tiene caracteres no permitidos");
        return;
    }
    
    int DiasDuracion = Integer.parseInt(duracionTexto);
    int DiasReposo = Integer.parseInt(reposoTexto);
    int CantidadSesiones = Integer.parseInt(sesionesTexto);
    int Costo = Integer.parseInt(costoTexto);
    
    Tratamiento Trat = new Tratamiento(Nombre, Tipo, Area, Detalles, DiasDuracion, DiasReposo, CantidadSesiones, Costo, RequiereInternacion, Estado, Materiales, Medicamento, Enfermedad);
    TratamientoDAO dao = new TratamientoDAO();
    dao.insertar(Trat);

    JOptionPane.showMessageDialog(null, "Tratamiento registrado exitosamente !");

    txtNombre.setText("");
    txtTipo.setText("");
    txtArea.setText("");
    txtDetalles.setText("");
    txtDuracion.setText("");
    txtDReposo.setText("");
    txtCtSesiones.setText("");
    txtCosto.setText("");
    txtRequiere.setText("");
    txtEstado.setText("");
    txtMedicamentos.setText("");
    txtMedicamentos.setText("");
    txtEnfermedad.setText("");
    }//GEN-LAST:event_btnIngresarActionPerformed

    private void btnbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbuscarActionPerformed
    String nombreBuscado = txtNombreaBuscar.getText();

    if (!nombreBuscado.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ0 ]+")) {
        JOptionPane.showMessageDialog(null, "ERROR - El nombre tiene caracteres no permitidos");
        return;
    }
    
    
    TratamientoDAO dao = new TratamientoDAO();
    ArrayList<Tratamiento> Lista_Tratamientos = dao.buscarTratamiento(nombreBuscado);

    DefaultTableModel modelo = (DefaultTableModel) tablaTratamientos.getModel();
    modelo.setRowCount(0);
    if (Lista_Tratamientos.isEmpty()) {
        JOptionPane.showMessageDialog(null, "No se encontraron tratamientos con ese nombre");
        return;
    }

    for (Tratamiento trat : Lista_Tratamientos) {
        modelo.addRow(new Object[]{
            trat.getIdTratamiento(),
            trat.getNombre(),
            trat.getTipo(),
            trat.getArea(),
            trat.getDetalles(),
            trat.getDiasDuracion(),
            trat.getDiasReposo(),
            trat.getCantidadSesiones(),
            trat.getCosto(),
            trat.getRequiereInternacion(),
            trat.getEstado(),
            trat.getMateriales(),
            trat.getMedicamentos(),
            trat.getEnfermedades()
        });
    }
    }//GEN-LAST:event_btnbuscarActionPerformed

    private void btneliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneliminarActionPerformed
    int fila = tablaTratamientos.getSelectedRow();

    if (fila == -1) {
        JOptionPane.showMessageDialog(null, "Debe seleccionar un tratamiento");
        return;
    }

    int idTratamiento = Integer.parseInt(tablaTratamientos.getValueAt(fila, 0).toString());

    TratamientoDAO dao = new TratamientoDAO();
     int confirmar = JOptionPane.showConfirmDialog(null, "Seguro que querés eliminar este Tratamiento?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirmar != JOptionPane.YES_OPTION) {
          return;
        }
    dao.eliminar(idTratamiento);

    JOptionPane.showMessageDialog(null, "Registro eliminado exitosamente");

    }//GEN-LAST:event_btneliminarActionPerformed

    private void btneditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneditarActionPerformed
    int fila = tablaTratamientos.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(null, "Tiene seleccionar un tratamiento.");
        return;
    }

    int idTratamiento = (int) tablaTratamientos.getValueAt(fila, 0);
    String Nombre = txtNombre.getText();
    String Tipo = txtTipo.getText();
    String Area = txtArea.getText();
    String Detalles = txtDetalles.getText();
    int DiasDuracion = Integer.parseInt(txtDuracion.getText());
    int DiasReposo = Integer.parseInt(txtDReposo.getText());
    int CantidadSesiones = Integer.parseInt(txtCtSesiones.getText());
    int Costo = Integer.parseInt(txtCosto.getText());
    String RequiereInternacion = txtRequiere.getText();
    String Estado = txtEstado.getText();
    String Materiales = txtMateriales.getText();
    String Medicamento = txtMedicamentos.getText();
    String Enfermedad = txtEnfermedad.getText();

    Tratamiento trat = new Tratamiento();
    trat.setIdTratamiento(idTratamiento);
    trat.setNombre(Nombre);
    trat.setTipo(Tipo);
    trat.setArea(Area);
    trat.setDetalles(Detalles);
    trat.setDiasDuracion(DiasDuracion);
    trat.setDiasReposo(DiasReposo);
    trat.setCantidadSesiones(CantidadSesiones);
    trat.setCosto(Costo);
    trat.setRequiereInternacion(RequiereInternacion);
    trat.setEstado(Estado);
    trat.setMateriales(Materiales);
    trat.setMedicamentos(Medicamento);
    trat.setEnfermedades(Enfermedad);

    TratamientoDAO dao = new TratamientoDAO();
    dao.actualizar(trat);
    JOptionPane.showMessageDialog(null, "Tratamiento modificado correctamente.");
    
    }//GEN-LAST:event_btneditarActionPerformed

    private void btnmostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmostrarActionPerformed
    TratamientoDAO dao = new TratamientoDAO();
    ArrayList<Tratamiento> Lista_Tratamientos = dao.listar();
    DefaultTableModel modelo = (DefaultTableModel) tablaTratamientos.getModel();

    modelo.setRowCount(0);

    for (Tratamiento trat : Lista_Tratamientos) {
        modelo.addRow(new Object[]{
            trat.getIdTratamiento(),
            trat.getNombre(),
            trat.getTipo(),
            trat.getArea(),
            trat.getDetalles(),
            trat.getDiasDuracion(),
            trat.getDiasReposo(),
            trat.getCantidadSesiones(),
            trat.getCosto(),
            trat.getRequiereInternacion(),
            trat.getEstado(),
            trat.getMateriales(),
            trat.getMedicamentos(),
            trat.getEnfermedades()
        });
    }
    }//GEN-LAST:event_btnmostrarActionPerformed

    private void btnlimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimpiarActionPerformed
    txtNombre.setText("");
    txtTipo.setText("");
    txtArea.setText("");
    txtDetalles.setText("");
    txtDuracion.setText("");
    txtDReposo.setText("");
    txtCtSesiones.setText("");
    txtCosto.setText("");
    txtRequiere.setText("");
    txtEstado.setText("");
    txtMateriales.setText("");
    txtMedicamentos.setText("");
    txtEnfermedad.setText("");
    }//GEN-LAST:event_btnlimpiarActionPerformed

    private void btnvolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnvolverActionPerformed
        VentanaSeleccion ventanaSeleccion = new VentanaSeleccion();
        ventanaSeleccion.setVisible(true);
        ventanaSeleccion.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnvolverActionPerformed

    private void tablaTratamientosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaTratamientosMouseClicked
    int fila = tablaTratamientos.getSelectedRow();

    if (fila == -1) {
        return;
    }

    txtNombre.setText(tablaTratamientos.getValueAt(fila, 1).toString());
    txtTipo.setText(tablaTratamientos.getValueAt(fila, 2).toString());
    txtArea.setText(tablaTratamientos.getValueAt(fila, 3).toString());
    txtDetalles.setText(tablaTratamientos.getValueAt(fila, 4).toString());
    txtDuracion.setText(tablaTratamientos.getValueAt(fila, 5).toString());
    txtDReposo.setText(tablaTratamientos.getValueAt(fila, 6).toString());
    txtCtSesiones.setText(tablaTratamientos.getValueAt(fila, 7).toString());
    txtCosto.setText(tablaTratamientos.getValueAt(fila, 8).toString());
    txtRequiere.setText(tablaTratamientos.getValueAt(fila, 9).toString());
    txtEstado.setText(tablaTratamientos.getValueAt(fila, 10).toString());
    txtMateriales.setText(tablaTratamientos.getValueAt(fila, 11).toString());
    txtMedicamentos.setText(tablaTratamientos.getValueAt(fila, 12).toString());
    txtEnfermedad.setText(tablaTratamientos.getValueAt(fila, 13).toString());

    }//GEN-LAST:event_tablaTratamientosMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionTratamiento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionTratamiento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionTratamiento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionTratamiento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GestionTratamiento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnIngresar;
    private javax.swing.JButton btnbuscar;
    private javax.swing.JButton btneditar;
    private javax.swing.JButton btneliminar;
    private javax.swing.JButton btnlimpiar;
    private javax.swing.JButton btnmostrar;
    private javax.swing.JButton btnvolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaTratamientos;
    private javax.swing.JTextField txtArea;
    private javax.swing.JTextField txtCosto;
    private javax.swing.JTextField txtCtSesiones;
    private javax.swing.JTextField txtDReposo;
    private javax.swing.JTextField txtDetalles;
    private javax.swing.JTextField txtDuracion;
    private javax.swing.JTextField txtEnfermedad;
    private javax.swing.JTextField txtEstado;
    private javax.swing.JTextField txtMateriales;
    private javax.swing.JTextField txtMedicamentos;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNombreaBuscar;
    private javax.swing.JTextField txtRequiere;
    private javax.swing.JTextField txtTipo;
    // End of variables declaration//GEN-END:variables
}
