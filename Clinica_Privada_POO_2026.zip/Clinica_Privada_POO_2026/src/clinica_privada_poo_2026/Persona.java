//Persona
package clinica_privada_poo_2026;

public abstract class Persona {
    protected String Nombre ;
    protected String Apellido ;
    protected int DNI ;
    protected String Email ;
    protected String Fecha_Nacimiento ;
    protected String Direccion ;
    protected String Genero ;

    public Persona(String Nombre, String Apellido, int DNI, String Email, String Fecha_Nacimiento, String Direccion, String Genero) {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.DNI = DNI;
        this.Email = Email;
        this.Fecha_Nacimiento = Fecha_Nacimiento;
        this.Direccion = Direccion;
        this.Genero = Genero;
    }

    public Persona() {
    }

    
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getFecha_Nacimiento() {
        return Fecha_Nacimiento;
    }

    public void setFecha_Nacimiento(String Fecha_Nacimiento) {
        this.Fecha_Nacimiento = Fecha_Nacimiento;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getGenero() {
        return Genero;
    }

    public void setGenero(String Genero) {
        this.Genero = Genero;
    }
    
    
    public abstract void Mostrar_Persona();
    
}
