document.addEventListener('DOMContentLoaded', () => {
    const turnoForm = document.getElementById('turnoForm');
    if (!turnoForm) {
        return;
    }

    turnoForm.addEventListener('submit', (evento) => {
        evento.preventDefault();

        const dni = document.getElementById('dni')?.value.trim() || '';
        const fechaHora = document.getElementById('fechaHora')?.value.trim() || '';
        const especialidad = document.getElementById('especialidad')?.value.trim() || '';
        const motivo = document.getElementById('motivo')?.value.trim() || '';

        if (!dni || !fechaHora || !especialidad || !motivo) {
            alert('Completa todos los campos para sacar un turno.');
            return;
        }

        alert('Turno solicitado correctamente.');
    });
});
