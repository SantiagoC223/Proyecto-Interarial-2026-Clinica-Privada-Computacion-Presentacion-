document.addEventListener('DOMContentLoaded', () => {
    const API_BASE_URL = 'http://localhost:8080/api';
    const formulario = document.getElementById('formulario-perfil');
    const mensaje = document.getElementById('mensaje-perfil');
    const botonGuardar = document.getElementById('guardar-perfil');
    const botonMenu = document.getElementById('btn-paciente');
    const menu = document.getElementById('menu-opciones');
    const enlaceCerrarSesion = document.getElementById('cerrar-sesion');

    function mostrarMensaje(texto, tipo) {
        mensaje.textContent = texto;
        mensaje.className = `perfil-mensaje visible ${tipo}`;
    }

    async function solicitarPerfil(opciones = {}) {
        const respuesta = await fetch(`${API_BASE_URL}/pacientes/perfil`, {
            credentials: 'include',
            headers: opciones.body ? { 'Content-Type': 'application/json' } : {},
            ...opciones
        });

        if (respuesta.status === 401) {
            window.location.href = 'InicioSesion.html';
            throw new Error('Tu sesión venció. Iniciá sesión nuevamente.');
        }

        const texto = await respuesta.text();
        let contenido = {};
        if (texto.trim()) {
            try {
                contenido = JSON.parse(texto);
            } catch {
                throw new Error('El servidor respondió con un formato no válido.');
            }
        }
        if (!respuesta.ok) {
            throw new Error(contenido.mensaje || contenido.message || contenido.error || 'No se pudo completar la operación.');
        }
        return contenido;
    }

    function cargarCampos(perfil) {
        document.getElementById('dni').value = perfil.dni || '';
        document.getElementById('fechaNacimiento').value = perfil.fechaNacimiento || '';
        document.getElementById('nombre').value = perfil.nombre || '';
        document.getElementById('apellido').value = perfil.apellido || '';
        document.getElementById('telefono').value = perfil.telefono || '';
        document.getElementById('correo').value = perfil.correo || '';
        document.getElementById('direccion').value = perfil.direccion || '';
        document.getElementById('obraSocial').value = perfil.obraSocial || '';
        document.getElementById('numeroAfiliado').value = perfil.numeroAfiliado || '';
    }

    async function cargarPerfil() {
        botonGuardar.disabled = true;
        try {
            const perfil = await solicitarPerfil();
            cargarCampos(perfil);
        } catch (error) {
            mostrarMensaje(error.message || 'No se pudieron cargar tus datos.', 'error');
        } finally {
            botonGuardar.disabled = false;
        }
    }

    if (botonMenu && menu) {
        botonMenu.addEventListener('click', () => {
            const abierto = menu.classList.toggle('show');
            botonMenu.setAttribute('aria-expanded', String(abierto));
        });

        document.addEventListener('click', (evento) => {
            if (!menu.contains(evento.target) && !botonMenu.contains(evento.target)) {
                menu.classList.remove('show');
                botonMenu.setAttribute('aria-expanded', 'false');
            }
        });
    }

    if (enlaceCerrarSesion) {
        enlaceCerrarSesion.addEventListener('click', async (evento) => {
            evento.preventDefault();
            try {
                const respuesta = await fetch(`${API_BASE_URL}/auth/logout`, {
                    method: 'POST',
                    credentials: 'include'
                });
                if (!respuesta.ok) throw new Error('No se pudo cerrar la sesión.');
                window.location.href = 'InicioSesion.html';
            } catch (error) {
                mostrarMensaje(error.message || 'No se pudo cerrar la sesión.', 'error');
            }
        });
    }

    formulario.addEventListener('submit', async (evento) => {
        evento.preventDefault();
        if (!formulario.reportValidity()) return;

        const datos = {
            fechaNacimiento: document.getElementById('fechaNacimiento').value,
            nombre: document.getElementById('nombre').value.trim(),
            apellido: document.getElementById('apellido').value.trim(),
            telefono: document.getElementById('telefono').value.trim(),
            correo: document.getElementById('correo').value.trim().toLowerCase(),
            direccion: document.getElementById('direccion').value.trim(),
            obraSocial: document.getElementById('obraSocial').value.trim(),
            numeroAfiliado: document.getElementById('numeroAfiliado').value.trim()
        };
        const contrasenaNueva = document.getElementById('contrasenaNueva').value;
        if (contrasenaNueva) datos.contrasenaNueva = contrasenaNueva;

        botonGuardar.disabled = true;
        mostrarMensaje('Guardando cambios...', 'exito');
        try {
            const perfilActualizado = await solicitarPerfil({
                method: 'PUT',
                body: JSON.stringify(datos)
            });
            if (perfilActualizado.dni) cargarCampos(perfilActualizado);
            document.getElementById('contrasenaNueva').value = '';
            mostrarMensaje('Los cambios se guardaron correctamente.', 'exito');
        } catch (error) {
            mostrarMensaje(error.message || 'No se pudieron guardar los cambios.', 'error');
        } finally {
            botonGuardar.disabled = false;
        }
    });

    cargarPerfil();
});
