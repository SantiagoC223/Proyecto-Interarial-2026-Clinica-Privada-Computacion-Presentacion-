document.addEventListener('DOMContentLoaded', () => {
    let usuario;
    try {
        usuario = ClinicaSesion.obtenerPacienteActual();
    } catch (error) {
        alert('No se pudieron cargar los datos.');
        window.location.href = 'index.html';
        return;
    }

    if (!usuario) {
        alert('Iniciá sesión o registrate para continuar.');
        window.location.href = 'index.html';
        return;
    }

    document.querySelectorAll('.usuario-paciente').forEach((elemento) => {
        elemento.textContent = `Perfil ${usuario.nombre}`;
    });

    const datos = {
        nombre: `${usuario.nombre} ${usuario.apellido}`.trim(),
        dni: usuario.dni,
        numeroAfiliado: usuario.numeroAfiliado || '—'
    };
    document.querySelectorAll('[data-dato-paciente]').forEach((elemento) => {
        elemento.textContent = datos[elemento.dataset.datoPaciente] || '—';
    });

    const botonMenu = document.getElementById('btn-paciente');
    const menu = document.getElementById('menu-opciones');
    if (botonMenu && menu) {
        botonMenu.addEventListener('click', () => menu.classList.toggle('show'));
        document.addEventListener('click', (evento) => {
            if (!menu.contains(evento.target) && evento.target !== botonMenu) {
                menu.classList.remove('show');
            }
        });
    }

    document.querySelectorAll('a[href="#historial"]').forEach((enlace) => {
        enlace.addEventListener('click', (evento) => {
            evento.preventDefault();
            ClinicaSesion.cerrarSesion();
            window.location.href = 'index.html';
        });
    });

    function irATurnos() {
        window.location.href = 'Turnos.html';
    }

    function irAEstudios() {
        window.location.href = 'Estudios.html';
    }

    function irAAtenciones() {
        window.location.href = 'Atenciones.html';
    }

    const formulario = document.querySelector('.perfil-formulario');
    if (!formulario) return;

    ['dni', 'fechaNacimiento', 'nombre', 'apellido', 'telefono', 'obraSocial', 'numeroAfiliado']
        .forEach((id) => {
            const campo = document.getElementById(id);
            const dato = id === 'fechaNacimiento' ? 'fecha' : id;
            if (campo) campo.value = usuario[dato] || '';
        });

    formulario.addEventListener('submit', (evento) => {
        evento.preventDefault();
        const usuarios = ClinicaSesion.obtenerUsuarios();
        const indice = usuarios.findIndex((cuenta) => cuenta.dni === usuario.dni);
        if (indice < 0) {
            alert('No se encontró la cuenta.');
            return;
        }

        usuarios[indice] = {
            ...usuarios[indice],
            fecha: document.getElementById('fechaNacimiento').value,
            nombre: document.getElementById('nombre').value.trim(),
            apellido: document.getElementById('apellido').value.trim(),
            telefono: document.getElementById('telefono').value.trim(),
            obraSocial: document.getElementById('obraSocial').value.trim(),
            numeroAfiliado: document.getElementById('numeroAfiliado').value.trim()
        };

        const nuevaContrasena = document.getElementById('contrasenaNueva').value;
        if (nuevaContrasena) {
            if (nuevaContrasena.length < 8) {
                alert('La contraseña debe tener al menos 8 caracteres.');
                return;
            }
            usuarios[indice].contrasena = nuevaContrasena;
        }

        ClinicaSesion.guardarUsuarios(usuarios);
        alert('Datos guardados.');
        window.location.reload();
    });
});
