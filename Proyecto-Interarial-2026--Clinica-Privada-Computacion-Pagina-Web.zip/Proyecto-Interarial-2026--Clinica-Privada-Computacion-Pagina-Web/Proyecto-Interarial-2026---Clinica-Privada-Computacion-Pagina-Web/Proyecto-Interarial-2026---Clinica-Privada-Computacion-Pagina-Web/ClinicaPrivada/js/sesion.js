window.ClinicaSesion = {
    obtenerUsuarios() {
        return JSON.parse(localStorage.getItem('clinicaUsuarios') || '[]');
    },

    guardarUsuarios(usuarios) {
        localStorage.setItem('clinicaUsuarios', JSON.stringify(usuarios));
    },

    obtenerPacienteActual() {
        const dni = localStorage.getItem('clinicaPacienteActual');
        return this.obtenerUsuarios().find((usuario) => usuario.dni === dni);
    },

    iniciarSesion(dni) {
        localStorage.setItem('clinicaPacienteActual', dni);
    },

    cerrarSesion() {
        localStorage.removeItem('clinicaPacienteActual');
    }
};
