function Registrarse() {
    window.location.href = 'registro.html';
}

function IniciarSesion() {
    window.location.href = 'InicioSesion.html';
}

function navegar(direccion) {
    const track = document.getElementById('carruselTrack');
    if (!track) return;

    const anchoImagen = track.clientWidth;
    track.scrollBy({ left: direccion * anchoImagen, behavior: 'smooth' });
}
