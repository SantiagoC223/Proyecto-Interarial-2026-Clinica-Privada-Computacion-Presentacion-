function Atras() {
    window.location.href = 'index.html';
}

function IniciarSesion(event) {
    event.preventDefault();

    const dni = document.getElementById('documento').value.trim();
    const contrasena = document.getElementById('contrasena').value;
    if (!dni || !contrasena) {
        alert('Completá el DNI y la contraseña.');
        return;
    }
    if (!/^\d{7,8}$/.test(dni)) {
        alert('Revisá el DNI.');
        document.getElementById('documento').focus();
        return;
    }

    try {
        const usuario = ClinicaSesion.obtenerUsuarios().find((cuenta) => cuenta.dni === dni);
        if (!usuario || usuario.contrasena !== contrasena) {
            alert('El DNI o la contraseña no coinciden.');
            return;
        }

        ClinicaSesion.iniciarSesion(dni);
        window.location.href = 'Gestion.html';
    } catch (error) {
        alert('No se pudo iniciar sesión. Probá de nuevo.');
    }
}
